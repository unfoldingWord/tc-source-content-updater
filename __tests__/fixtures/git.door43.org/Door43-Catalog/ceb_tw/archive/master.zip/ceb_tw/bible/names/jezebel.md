# Jesabel

Si Jesabel usa ka dautan nga asawa sa hari sa Israel nga si Ahab.

* Gi-inpluwensyahan ni Jesabel si Ahab ug uban pang taga Israel sa pagsimba ug mga diosdiosan.
* Daghan sad siyang gipapatay nga mga propeta sa Dios
* Si Jesabel ang hinungdan sa pagpapatay sa inosenteng tawo nga si Nabot aron maangkon ni Ahab ang ubasan ni Nabot.
* Sa ulahi, napatay si Jesabel tungod sa tanan niyang nahimo nga dautan. Gitagna ni Elijah kung unsaon niya pagkamatay ug nahitabo gyud sumala sa iyang giingon.


# Gad

Ang Gad ngalan nga gihatag sa usa sa mga anak nga lalaking anak ni Jacob o Israel. Ang pamilya ni Gad nahimong usa sa dose nga tribo sa Israel.

* Ang lain nga tawo sa Biblia nga Gad ang ngalan mao ang usa ka propeta nga miatubang kang Haring David aron siya badlongon sa iyang sala sa pag-ihap sa katawhan nga Israelita.
* Aduna say "kapatagan nga Gad" nga gihisgotan sa Biblia.


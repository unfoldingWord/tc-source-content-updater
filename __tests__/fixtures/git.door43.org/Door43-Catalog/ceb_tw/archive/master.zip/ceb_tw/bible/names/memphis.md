# Memfis

Ang Memfis usa ka karaang kapital nga siyudad sa Ehipto nga subay sa Suba sa Nilo.

* Ang Memfis makita sa ubos nga bahin sa Ehipto, ubos sa wawa sa Suba sa Nilo diin tabunok kaayo ang yuta ug daghang  mga tanom nga makaon.
* Tungod niini nga halangdong nahimutangan, ang Memfis nahimong importanteng siyudad sa negosyo.


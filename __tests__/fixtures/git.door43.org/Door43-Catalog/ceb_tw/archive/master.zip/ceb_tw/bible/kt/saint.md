# Mga balaan

Ang pulong nga "mga balaan" nagtumong sa mga tumutuo kang Jesus.

* Sa kadugayan sa kaagi sa iglesia, ang mga tawo nga nailhan sa iyang maayo nga binuhatan gihatagan ug titulo nga "santo" apan dili kini ang pamaagi nga pulong nga gigamit sa Bag-ong Kasabotan.
* Ang mga tumutuo kang Jesus gitawag nga mga balaan o mga santo, dili tungod sa ilang nahimo, apan pinaagi sa pagtuo sa gibuhat ni Cristo Jesus sa pagluwas sa mga tawo. Siya ang naghimo kanila nga balaan.

Mga Sugyot sa Paghubad:

* Ang pamaagi sa pahubad sa "mga balaan" pwede ang "balaang mga tawo" o "tumutuo kang Jesus" o "mga gigahin."


# pagkamatinumanon sa kasabotan

Gigamit kini nga pulong aron ihulagway ang Dios nga matinumanon sa  iyang mga saad sa iyang katawhan. 

* Naghimo ug mga saad ang Dios sa mga Israelita pinaagi sa pormal nga mga panagsabot nga gitawag nga mga "kasabotan."
* Ang "pagkamatinud-anon sa kasabotan" o "pagkamatinumanon  sa kasabotan" ni Yahweh nagtumong sa kamatuoran nga iyang tumanon ang iyang mga saad sa iyang katawhan.
* Ang pagkamatinud-anon sa Dios nga tumanon ang iyang mga saad sa kasabotan usa ka pagpahayag sa iyang grasya ngadto sa iyang katawhan.
* Ang pulong nga "maunongon” lain nga pulong nga nagtumong sa kasaligan nga mobuhat ug mosulti sa unsay gisaad aron maghatag ug kaayohan sa ubang tawo.

Mga Sugyot sa Paghubad:

* Ang pamaagi sa paghubad niini nga pulong nagdepende sad sa paghubad sa mga pulong nga "kasabotan" ug "pagkamatinud-anon."
* Ang laing mga pamaagi sa paghubad niini nga pulong pwede nga "matinud-anon nga gugma" o "maunongon, mapasaligon nga gugma" o “gugma nga masaligan.”


# Jose (sa Bag-ong Kasabotan)

Si Jose yutan-on nga amahan ni Jesus ug nagpadako kaniya isip iyang anak.

* Kaliwat ni Haring David si Jose.
* Si Jose gisabot nga makigminyo sa usa ka berhin nga Maria ang ngalan, nga maoy gipili sa Dios nga mahimong inahan ni Jesus nga Mesias.
* Gisultihan sa anghel si Jose nga pinaagi sa Balaan nga Espiritu magmabdos si Maria ug ang iyang anak mao ang Anak sa Dios.
* Mituo si Jose sa anghel ug mituman sa Dios pinaagi sa pagminyo kang Maria nga iyang asawa.
* Wala hilabti ni Jose si Maria hangtod nga siya nanganak kang Jesus.


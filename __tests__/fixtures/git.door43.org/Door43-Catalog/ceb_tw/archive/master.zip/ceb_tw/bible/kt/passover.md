# Kasaulugan sa Pagsaylo

Ang "Kasaulugan sa Pagsaylo" usa ka relihiyoso nga kapistahan nga gisaulog sa mga Judio kada tuig aron hinumduman ang pagluwas sa Dios sa ilang mga katigulangan, nga ang mga Israelita, gikan sa ilang pagkaulipon sa Ehipto.

* Ang ngalan niini nga kapistahan gikan sa kamatuoran nga ang Dios "nagsaylo" sa balay sa mga Israelita ug wala gipatay ang ilang mga anak nga lalaki niadtong gipatay sa Dios ang mga kamagwangang anak nga lalaki sa mga taga-Ehipto.
* Ang Kasaulugan sa Pagsaylo nag-apil sa pinasahi nga pagkaon sa walay depekto nga nating karnero nga ilang gipatay ug gisugba, ug pan nga walay libadora. Kini nga mga pagkaon nagpahinumdom kanila sa gikaon sa mga Israelita niadtong gabii usa sila niikyas gikan sa Ehipto.
* Nag-ingon ang Dios sa mga Israelita nga kaunon kini nga mga pagkaon sa matag tuig aron hinumduman ug saulogon kung giunsa sa Dios "pagsaylo" sa ilang mga balay ug kung giunsa niya sila gipagawas gikan sa pagkaulipon sa Ehipto.

Mga Sugyot sa Paghubad:

* Ang pulong nga "Kasaulugan sa Pagsaylo" pwede hubaron pinaagi sa paghiusa sa mga pulong sa Ingles nga "pass" ug "over" o ubang kombinasyon sa mga pulong nga adunay sama niini nga pasabot.
* Makatabang kung ang ngalan niini nga kapistahan adunay klaro nga koneksyon sa mga pulong nga gigamit sa pagpatin-aw kung unsa ang gibuhat sa anghel sa Dios sa paglabay sa mga balay sa mga Israelita ug pagpalingkawas sa ilang mga anak nga lalaki.


# Mardoqueo

Si Mardoqueo usa ka lalaking Judio nga nagpuyo sa nasod sa Persia. Siya ang nag-alima sa iyang ig-agaw nga si Ester nga kadugayan nahimong asawa sa Persiahanong hari nga si Ahasuero.

* Samtang nagtrabaho siya sa palasyo sa hari, nadunggan ni Mardoqueo ang mga lalaki nga nagplano nga patyon nila si Haring Ahasuero. Gisugid niya kini sa hari ug naluwas ang kinabuhi sa hari.
* Paglabay sa panahon, nahibaw-an sad ni Mardoqueo mahitungod sa plano nga patyon ang tanang Judio sa gingharian sa Persia. Gitambagan niya si Ester nga hangyoon ang hari nga luwason ang mga Judio.


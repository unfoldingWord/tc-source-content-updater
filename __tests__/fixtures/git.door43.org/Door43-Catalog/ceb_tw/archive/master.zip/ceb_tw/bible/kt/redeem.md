# tubos, katubsanan, manunubos

Ang pulong nga "tubos" ug ang "katubsanan" nagtumong sa pagpalit pag-usab sa usa ka butang nga iyaha o nabihag niya kaniadto. Ang "manunubos" usa ka tawo nga nagtubos sa usa ka butang o usa ka tawo.

* Ang Dios naghatag ug mga sugo sa mga Israelita mahitungod sa pamaagi sa pagtubos sa mga tawo o mga butang.
* Pananglitan, ang usa ka tawo pwede magtubos ug ulipon pinaagi sa pagbayad sa bili niini aron ang ulipon makagawas. Ang pulong nga "lukat" nagtumong sad niini nga binuhatan.
* Kung ang yuta sa usa ka tawo nabaligya na, ang paryente niadto nga tawo pwede "motubos" o "mopalit pag-usab" niadto nga yuta aron kini magpabilin sa ilang pamilya. 
* Kini nga mga binuhatan nagpakita kung giunsa pagtubos sa Dios sa mga tawo nga naulipon sa sala. Sa dihang si Jesus namatay sa krus, gibayaran niya ang kinatibuk-an nga bayad sa mga sala sa mga tawo ug gitubos niya ang tanan nga misalig kaniya alang sa kaluwasan. Ang mga tawo nga natubos na sa Dios gipagawas gikan sa sala ug sa silot niini.

Mga Sugyot sa Paghubad
Depende sa konteksto, ang pulong nga “tubos” pwede sad hubaron nga “paliton pag-usab o “bayaran aron buhian.”


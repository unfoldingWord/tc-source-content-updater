# Antioquia

Sa Bag-ong Kasabotan adunay duha ka siyudad nga gitawag ug Antioquia; ang usa mao ang kapital nga siyudad sa daan nga nasod sa Siria ug makit-an kini mga 24 kilometro gikan sa kabaybayonan sa Dagat sa Medeteraneo. Ang usa ka Antioquia naa sa Pisidia (sa Asya Minor o sa karon mao ang Turkey) dili layo sa karaan nga siyudad sa Colosas.

* Sa siyudad sa Syria nga Antioquia nga mga 800 kilometro amihanan sa Jerusalem, mao ang unang lugar diin ang mga tumutuo kang Jesus gitawag nga mga Kristiyano.
* Ang Antioquia sa Siria usa ka importante gyud nga siyudad ug ang lokal nga Iglesia didto nagpadala ug mga misyonaryo ngadto sa mga Gentil.
* Si Pablo, Barnabas ug si Juan Marcos mibiyahe didto sa Antioquia sa Pisidia, aron isangyaw ang maayong balita sa mga tawo didto.


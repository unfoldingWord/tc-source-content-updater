# Nahum

Si Nahum usa ka propeta nga nagwali sa panahon niadtong naghari si Haring Manase nga usa ka dautan nga hari sa Juda.

* Si Nahum gikan sa lungsod sa Elcos, mga 20 ka milya gikan sa Jerusalem.
* Ang libro nga Nahum nagtala sa iyang mga pagtagna mahitungod sa paglaglag sa Neniva nga siyudad sa Asiria.


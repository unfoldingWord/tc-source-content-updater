# Abimelek

Si Abimelek usa ka haring Filistihanon sa dapit sa Gerar niadtong panahon nga tua sa Canaan si Abraham ug si Isaac.

* Gilimbongan ni Abraham si Haring Abimelek pinaagi sa pagsulti nga igsoon niya si Sara, imbes nga iyang asawa.
* Gidala ni Abimelek si Sara sa iyang panimalay, apan gibalik dayon niya siya niadtong nagpakita ang Dios kaniya sa damgo ug gibadlong siya.
* Nagsabot si Abraham ug Abimelek bahin sa giilogan  nga mga balon sa Beerseba kung kinsa ang manag-iya sa mga balon. 
* Human ang daghang katuigan, nagpuyo ang anak ni Abraham nga si Isaac ug ang iyang pamilya didto sa dapit nga giharian ni Abimelek.
* Aduna pay lalaki nga ang ngalan Abimelek nga anak ni Gideon ug igsoon ni Jotam. Ang uban nga paghubad mogamit ug lain nga ispeling sa ngalan niya aron maklaro nga dili siya si Haring Abimelek.


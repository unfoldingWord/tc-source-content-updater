# Asdod, Azotos

Ang Asdod usa sa lima nga labing importante nga siyudad sa mga Filistihanon. Kini naa sa habagatang kasadpan sa Canaan duol sa dagat sa Mediterranean, naa sa tunga tunga taliwala sa mga siyudad sa Gaza ug Joppa.

* Ang templo sa dili tinuod nga dios sa mga Filistihanon nga si Dagon naa sa Asdod.
* Adunay usa ka higayon nga ang mga Filistihanon gikawat ang arka sa pakigsaad ug gidala kini sa siyudad sa Asdod ug gibutang sa ilang templo. Gisilotan sila kaayo sa Dios hangtod nga gibalik nila kini sa mga Israelita.
* Sa Griego ang ngalan niini nga siyudad mao ang Azotos. Kini usa sa mga siyudad diin ang ebanghilista nga si Filepe nagsangyaw sa maayong balita.


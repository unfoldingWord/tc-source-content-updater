# Filipos

Ang Filipos usa ka siyudad nga makita sa amihanang dapit sa karaan nga Gresya.

* Si Pablo ug si Silas mibiyahe sa Filipos aron magwali mahitungod kang Jesus sa mga tawo didto.
* Naaresto silang duha sa Filipos, apan ang Dios milagroso nga nagpagawas kanila.
* Sa Biblia adunay sulat si Pablo sa mga Kristohanon nga taga-Filipos.


# Ezequiel

Si Ezequiel usa ka propeta sa Dios sa panahon sa pagkabihag sa mga Judio nga
gidala sa Babilonia.

* Pari si Ezequiel nga nagpuyo sa gingharian sa Judah sa dihang siya ug ang ubang mga Judio nadakpan sa mga sundalo sa Babilonia.
* Sa sulod sa 20 ka mga tuig, siya ug ang iyang asawa nagpuyo sa Babilonia duol sa suba, ug ang mga Judio miadto kaniya aron makahibalo sa kaalam mahitungod sa propesiya.
* Usa sa mga gitagna ni Ezequiel mao ang pagkaguba ug pagtukod usab sa Jerusalem ug sa templo. 
* Gitagna sad niya ang mahitungod sa umaabot nga gingharian sa Mesias.


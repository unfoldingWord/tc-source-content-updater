# Barnabas

Si Barnabas usa sa mga unang Kristohanon nga nabuhi sa panahon sa mga apostoles. Ang ngalan niya nagpasabot nga "anak sa pagdasig".

* Si Barnabas gikan sa Israelita nga tribu ni Levi ug gikan siya sa isla sa Cyprus.
* Sa dihang si Saulo (Pablo) nahimong Kristohanon si Barnabas nag-awhag sa uban nga mga tumutuo nga dawaton siya ingon nga ilang kaubanan nga tumutuo.
* Si Barnabas ug si Pablo dungan nga nagbiyahe aron iwali ang maayong balita mahitungod kang Jesus sa lainlaing mga siyudad.


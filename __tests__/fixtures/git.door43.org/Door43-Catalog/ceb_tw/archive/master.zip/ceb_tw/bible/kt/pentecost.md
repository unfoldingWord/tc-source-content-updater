# Pentecostes, kasaulugan sa semana

Ang pentecostes mao ang Griego nga pulong sa Kasaulugan sa Semana diin gisaulog sa mga Judio sulod sa 50 ka mga adlaw human ang Kasaulogan sa Pagsaylo.

* Ang Adlaw sa Pentecostes mao ang una nga adlaw sa Kasaulugan sa Semana.
* Ang Kasaulugan sa Semana gisaulog human ang pag-ani sa lugas. Kini sad ang panahon aron hinumdumon ang unang paghatag sa Dios sa Balaod sa mga Israelita pinaagi kang Moises.
* Sa Bag-ong Kasabotan ang Adlaw sa Pentecostes hilabihan kaimportante tungod kay mao kini ang adalw nga gihatag sa Dios ang Balaang Espiritu sa mga misunod kay Jesus human nga nabanhaw si Jesus ug mibalik sa langit.


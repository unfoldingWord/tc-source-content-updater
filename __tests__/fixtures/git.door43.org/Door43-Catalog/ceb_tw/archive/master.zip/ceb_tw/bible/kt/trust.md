# Pagsalig, Kasaligan, Pagkamasaligan

Ang pulong nga "pagsalig" nagtumong sa pagtuo sa usa ka butang o tawo nga tinuod ug kasandigan. Ang "Kasaligan" nga tawo masaligan sa pagbuhat ug 
nag-ingon kung unsa ang sakto ug tinuod.

* Ang pagsalig parehas ra sa pagtuo. Kung nagsalig ka sa usa ka tawo, aduna kay pagtuo niadto nga tawo sa pagbuhat sa ilang gisaad nga buhaton.
* Ang pagsalig sa usa ka tawo nagpasabot sad sa nagsalig siya niadto nga tawo.
* Ang pagsalig kang Jesus nagpasabot sa pagtuo nga siya Dios, pagtuo nga ang iyang sakripisyo sa pagkamatay sa krus bayad sa atong mga sala, ug nagasalig kaniya sa pagluwas kanato.
* Ang "pagkamasaligan nga panultihon" nagtumong sa usa ka butang nga gisulti nga giisip nga tinuod.

Mga Sugyot sa Paghubad

* Ang pamaagi sa paghubad sa "pagsalig" pwede sad, "pagtuo" o "adunay pagtuo" o "adunay pasalig" o "nagdepende sa." 
* Ang pulong nga "pagkamasaligan" pwede hubaron nga, " kasaligan " o "kanunay nga masaligan."


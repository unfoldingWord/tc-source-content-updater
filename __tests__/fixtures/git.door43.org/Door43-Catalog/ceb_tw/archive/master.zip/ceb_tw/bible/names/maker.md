# magbubuhat

Kasagaran ang "magbubuhat" usa ka tawo nga naghimo o nagbuhat ug mga butang.

* Sa Biblia, ang pulong nga "Magbubuhat" usahay gigamit nga ngalan o titulo sa Yahweh, tungod kay gilalang niya ang tanan nga butang.
* Kasagaran kini nga pulong gihiusa sa "sa iyang" o "akong" o "sa imong."

Mga Sugyot sa Paghubad:

* Ang pulong nga "magbubuhat" pwede hubaron nga "Manlalalang" o "Dios nga manlalang" o "ang nagbuhat sa tanang butang."
* Ang mga pulong nga "ang iyang Magbubuhat" pwede sad hubaron nga "ang nagbuhat kaniya" o "Dios nga nagbuhat kaniya."
* Ang mga pulong nga "ang imong magbubuhat" ug "ang akong magbubuhat" pwede sad hubaron sa sama nga paagi sa "ang iyang magbubuhat" ilisan lang ang pronombre.


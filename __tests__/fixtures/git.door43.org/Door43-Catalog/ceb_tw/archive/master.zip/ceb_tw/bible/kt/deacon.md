# diacono

Ang diacono usa ka tawo nga nag-alagad sa mga kaubanan sa pagtuo sa praktikal nga pamaagi, sama sa pagdumala sa kwarta ug pag-atiman sa mga kabos.

* Ang pulong nga "diacono" gikuha gikan sa pulong nga Griego nga nagpasabot nga "alagad" o "ministro."
* Gikan pa sa panahon sa mga unang Kristohanon, ang pagka-diacono usa ka pinasahi nga buluhaton ug ministeryo sa lawas sa Iglesia.
* Pananglitan, sa Bag-ong Kasabotan, siguradohon sa mga diacono nga bisan unsang kwarta o pagkaon nga giambitan sa mga tumutuo angay gyud nga bahinbahinon pag-ayo sa mga biyuda.
* Ang pulong nga "diacono" pwede hubaron nga "ministro sa iglesia," "nagtrabaho sa iglesia," "alagad sa iglesia" o uban pang mga pulong nga nagpakita nga kini nga tawo pormal nga gipili nga magbuhat ug mga tahas nga makatabang sa lokal nga Kristohanong komyunidad.


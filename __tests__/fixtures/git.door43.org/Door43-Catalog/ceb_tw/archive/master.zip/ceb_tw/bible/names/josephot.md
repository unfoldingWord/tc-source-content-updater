# Jose (sa Daang Kasabotan)

Si Jose ang ika onse nga anak ni Jacob ug unang anak ni Raquel.

* Paborito nga anak si Jose sa iyang amahan mao nga ang iyang mga igsoon nangabugho kaniya; mao nga gibaligya siya isip ulipon.
* Miagi si Jose ug kalisdanan nga panahon, apil ang pagkahimo niya ug suluguon ug piniriso sa Ehipto, apan nagpadayon siya nga matinud-anon sa Dios.
* Gihimo siya sa Dios nga ikaduha sa labing taas nga nagmando sa Ehipto ug gigamit siya sa Dios sa pagluwas sa Ehipto ug iyang pamilya sa pagkagutom.


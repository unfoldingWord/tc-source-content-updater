# Edom, taga-Edom, Idumea, Seir, Teman

Edom ang lain nga ngalan ni Esau; Edomhanon ang tawag sa iyang mga kaliwat. Ang nasod nga Edom nahibal-an sad sa ngalan nga "Idumea" o "Sier".

* Kabungturan ang Edom nga makita sa habagatang silangan sa Israel.
* Ang pulong nga Edom nagpasabot nga "pula," nga nagtumong sa kamatuoran nga si Esau natabonan ug pula nga buhok kaniadtong gipanganak siya. O pwede nga nagtumong kini sa pula nga batong nga gibaylo ni Esau sa iyang katungod sa pagkamagulang.
* Sa Daang Kasabotan, ang nasod nga Edom kasagaran nga gihisgotan nga kaaway sa Israel.
* Sa Daang Kasabotan gihatagan sa Dios ang mga propeta ug mga negatibo nga propesiya aron mosulti batok sa Edom. Ang tibuok nga libro nga gitawag nga Abdias mahitungod kini sa kalaglagan sa Edom.


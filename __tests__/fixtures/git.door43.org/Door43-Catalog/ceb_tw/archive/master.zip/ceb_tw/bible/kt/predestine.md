# gitakda na daan

Ang pulong nga "gitakda na daan" nagtumong sa pagdisisyon o sa pagplano una pa mahitabo ang panghitabo.

* Kini nga pulong nagtumong gyud sa pagtakda na daan sa Dios sa mga tawo nga makadawat sa kinabuhing walay katapusan.
* Usahay ang pulong nga "tinakda" gigamit nga nagpasabot sad nga sa pagdisisyon niadto pa.

Mga Sugyot sa Paghubad

* Ang mga pulong nga "gitakda na daan" pwede sad hubaron nga "pagdisisyon kaniadto" o "nakadisisyon na daan."
* Ang pulong nga "gitakda na daan" pwede hubaron nga "nakadisisyon sa una pa" o "naplano na daan" o " nakadisisyon kaniadto pa."
* Ang mga pulong sama sa, "gitakda na kita" pwede hubaron nga "nadisisyonan na nga kita" o "nakadisisyonan na sa wala pa ang panahon nga kita."
* Timan-i nga ang paghubad niini nga pulong lahi gyud sa hubad sa pulong nga "nahibal-an."


# Laban

Sa Daang Kasabotan, si Laban uyoan ug ugangan ni Jacob.

* Nagpuyo si Jacob sa panimalay ni Laban sa Padan Aram ug tig-atiman siya sa iyang mga karnero ug mga kanding aron maminyo niya ang mga anak ni Laban.
* Mas gusto ni Jacob minyoan ang anak ni Laban nga si Raquel.
* Gilimbungan ni Laban si Jacob ug gipaminyoan niya ang iyang kamagulangang anak nga si Lea una pa niya gihatag si Raquel kang Jacob nga mahimong asawa.


# Neptali

Si Neptali mao ang ika-unom nga anak nga lalaki ni Jacob. Ang iyang mga kaliwat mao ang nahimong tribo ni Neptali nga usa sa mga dose ka tribo sa Israel.

* Ang Neptali mao ang tribo nga nagpuyo sa labing amihanang dapit sa yuta sa Israel.
* Kini nga tribo gihisgotan sa Daan ug Bag-ong Kasabotan sa Biblia.
* Ang ngalan nga Neptali gigamit sad aron magtumong sa teritoryo diin nagpuyo kini nga tribo. Pwede sad kini hubaron nga "ang yuta nga iya sa tribo nga Neptali" o "ang yuta diin nagpuyo ang mga kaliwat ni Neptali."
* Ang ngalan nga Neptali nagpasabot nga "pagpakigbisog."


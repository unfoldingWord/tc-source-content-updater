# Pabor, Gahatag ug kaayuhan, palabi

Ang pulong nga "pabor" nagtumong sa pagbuhat ug usa ka maayong butang alang sa kaayuhan sa usa ka tawo nga giisip nga maayo. Kung ang usa ka butang "gahatag ug kaayuhan" positibo ug gi-uyonan kini.

* Ang pulong nga "pinalabi" nagtumong sa pagbuhat ug maayo ngadto sa mga pinili nga mga tawo. Kasagaran, ang pagpalabi gipakita sa ubang mga tawo ngadto sa mga adunahan.
* Midako si Jesus nga "gihatagan ug pabor" sa Dios ug mga tawo. Nagpasabot kini nga miuyon sila sa iyang batasan ug kinaiya.
* Ang sumbingay nga "nahatagan ug pabor" nagpasabot nga ang usa ka tawo giuyonan sa lain nga tawo.
* Kung ang hari magpakita ug pabor sa usa ka tawo, kasagarang gipasabot kini nga miuyon siya sa gihangyo sa tawo ug iya kining ihatag.

Mga Sugyot sa Paghubad

* Ang ubang pamaagi sa paghubad sa pulong nga "pabor" pwede nga, "panalangin" o "kaayuhan."
* Ang "ang tuig ni Yahweh nga gahatag ug kaayuhan " pwede hubaron nga, "ang tuig nga ang Dios nga naghatag ug kaayuhan."


# Andres

Si Andres usa sa mga doseng lalaki nga gipili ni Jesus aron mahimong usa sa  iyang disipulo (kadugayang ginganlan nga apostoles).

* Ang igsoong lalaki ni Andres mao si Simon Pedro. Parehas silang mangingisda.
* Si Pedro ug Andres ang mga unang disipulo ni Jesus nga gihisgotan sa Biblia. Nangisda sila sa Lawa sa Galilea sa dihang gitawag sila ni Jesus nga mahimong iyang mga disipulo.
* Sila Pedro ug Andres, mga disipulo na kini sila ni Juan Bautista, una pa sila nagkita ni Jesus.


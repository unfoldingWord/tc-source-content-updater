# Juan

Si Juan usa sa mga dose ka mga apostoles ni Jesus ug usa siya sa mga suod nga higala ni Jesus.

* Si Juan ug ang iyang igsoon mga anak nga Zebedee.
* Lahi nga tawo si Juan kang Juan nga magbabautismo.
* Paghuman ni Jesus mibalik sa langit, si Juan (ang apostol) nagtudlo sa mga tawo mahitungod kang Jesus.
* Nagsulat sad si Juan ug duha ka libro ug pipila ka mga sulat mahitungod kang Jesus nga naapil sa Biblia.


# Isakar

Si Isakar mao ang ika-siyam nga anak nga lalaki ni Jacob nga si Israel.

* Siya ang anak nga lalaki sa ulipon nga babaye ni Leah nga nahimong puyopuyo ni Jacob.
* Ang tribu ni Isakar usa sa dose ka mga tribu sa Israel.


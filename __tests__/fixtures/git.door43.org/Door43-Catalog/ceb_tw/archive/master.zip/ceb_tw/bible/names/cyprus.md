# Cipre

Ang Cipre usa ka isla sa Dagat sa Mediteraneo nga mga 40 ka milya sa habagatan sa baybayon sa nasod nga nailhan karong panahona nga Turkey.

* Si Pablo ug Barnabas kauban nga nagwali sa isla sa Cipre sa sinugdanan sa ilang unang byahe isip mga misyonero. Niuban kanila si Juan Marcos aron tabangan sila niadto nga byahe.
* Kadugayan, nibisita sila Barnabas ug Marcos sa Cipre pag-usab.
* Sa Daang Kasabotan, gihisgotan ang Cipre nga maayo kakuhaan sa mga kahoy nga cipres.


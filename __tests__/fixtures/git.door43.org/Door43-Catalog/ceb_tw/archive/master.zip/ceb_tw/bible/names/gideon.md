# Gideon

Si Gideon usa ka Israelita nga gipili sa Dios aron luwason ang Israel sa iyang mga kaaway.

* Si Gideon nabuhi sa panahon, nga daghang tuig na ang miagi diin nga ang mga Israelita mipuyo na sa Canaan, mao sad kini ang panahon nga ang mga Midianihanon sige ug atake kanila.
* Si Gideon nahadlok pag-ayo sa mga Midianihanon, apan gigamit siya sa Dios aron panguluhan ang mga Israelita sa pakig-away batok sa mga Midianihanon ug napildi nila sila.


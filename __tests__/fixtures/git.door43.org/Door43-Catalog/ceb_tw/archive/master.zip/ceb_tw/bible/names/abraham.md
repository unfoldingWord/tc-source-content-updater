# Abraham, Abram

Si Abraham mao ang tawo nga gipili sa Dios nga magsugod ug usa ka pamilya nga modaghan ug mahimo nga usa ka katawhan nga nailhan nga mga Israelita.

* Nagsaad ang Dios kang Abraham nga makabaton siya ug daghan kaayong mga kaliwat ug mahimo silang dako nga nasod.
* Nakigsabot ang Dios kang Abraham ug nagsaad siya nga padayonon niya kini sa iyang mga kaliwat hangtod sa kahangtoran.
* Mitoo si Abraham sa Dios ug mituman siya kaniya.
* Ang una nga ngalan ni Abraham mao ang "Abram," apan giilisan kini sa Dios ug Abraham.
* Ang pasabot sa Abram "gidayeg nga amahan" ug ang Abraham nagpasabot nga "amahan sa daghang mga tawo."


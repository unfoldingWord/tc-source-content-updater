# Anak sa Dios, ang Anak

Ang Anak sa Dios nga si Jesus mianhi sa kalibutan ingon nga usa ka tawo aron magluwas ug mangulo sa kalibutan.

* Ang Anak sa Dios adunay sama nga kinaiya sa Dios nga Amahan, busa bug-os siya nga Dios.
* Ang Dios nga Amahan, Dios nga Anak, ug Dios nga Balaang Espiritu usa lang silang tanan.
* Dili pareho sa anak sa tawo, ang Anak sa Dios kanunay na nga anaa.
* Sa sinugdanan, ang Anak sa Dios kauban sa paglalang sa kalibutan uban ang Amahan ug ang Balaan nga Espiritu.
* Tungod kay si Jesus Anak sa Dios, gihigugma ug gituman niya ang iyang Amahan, ug gihigugma sad siya sa iyang Amahan.

  Mga Sugyot sa Paghubad:

* Alang sa mga pulong nga "Anak sa Dios," mas maayo nga hubaron ang "Anak" sa parehas nga pulong nga natural nga gigamit sa pinulungan nga hubaron aron magtumong sa usa ka "anak" sa tawhanong amahan.
* Siguraduha nga ang pulong nga gigamit sa paghubad sa "anak" mohaom sa pulong nga gigamit sa paghubad sa "amahan" ug kini nga mga pulong mao ang natural nga nagpahayag sa tinuod nga relasyon sa anak ug amahan.


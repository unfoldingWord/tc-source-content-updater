# Nehemias

Si Nehemias usa ka Israelita nga nagpuyo sa imperyo sa Babilonia niadtong panahon nga ang mga katawhan sa Israel ug Juda gibihag sa mga taga-Babilonia. Adunay libro sa Daang Kasabotan nga ginganlan sumala niya nga nag-istorya bahin kaniya.

* Gipangulohan ni Nehemias ang mga Israelita sa pagtukod pag-usab sa mga paril sa Jerusalem.
* Sulod sa 12 ka tuig, siya ang gobernador sa Jerusalem usa siya nibalik sa palasyo sa hari.
* Adunay pay duha ka tawo sa Daang Kasabotan nga Nehemias ang mga ngalan .


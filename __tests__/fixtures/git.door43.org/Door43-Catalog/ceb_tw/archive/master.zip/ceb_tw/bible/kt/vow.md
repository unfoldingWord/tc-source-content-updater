# saad

Ang saad usa ka panaad nga gihimo ngadto sa Dios. Ang tawo manaad sa pagbuhat ug pipila ka mga butang aron magpasidungog sa Dios o sa pagpakita sa iyang gugma ngadto kaniya.

* Ang saad pwede ihatag aron sa pagpahayag sa pagmahal ug gugma ngadto sa Dios nga dili mangayo ug bisan unsa gikan kaniya isip ganti.
* Ang tawo pwede maghimo ug saad aron sa pagpangayo sa Dios sa iyang pinasahi nga pagpanalipod, paghatag sa mga kinahanglanon, o iyang presensiya isip ganti sa paghimo sa saad.
* Dili kinahangalan nga tumanon sa Dios ang gipangayo sa tawo isip baylo sa iyang saad.
* Inig human sa tawo manaad, kinahanglan nga tumanon niya ang gisaad niya.
* Ang pagpakyas sa pagtuman sa saad mahimong silotan sa Dios

.
Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "saad" pwede hubaron nga "balaan nga panaad" o "panaad nga gihimo ngadto sa Dios." 
* Kini nga pulong hubaron gyud nga lain sa "panumpa."


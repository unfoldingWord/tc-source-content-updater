# anaa kang Cristo, kang Jesus, sa Ginoo

Ang pulong nga " anaa kang Cristo" ug mga pulong nga sama niini nagtumong sa estado o kahimtang sa usa ka tawo nga adunay relasyon kang Jesu Cristo pinaagi sa pagtuo kaniya.

* Ang ubang mga pulong nga sama niini mao ang, "kang Cristo Jesus, kang Jesu Cristo, sa Ginoong Jesus, sa Ginoong Jesu Cristo."
* Ang mga buot ipasabot niini nga mga pulong nga, " anaa kang Cristo" pwede ang, "tungod kay nahiusa ka kang Cristo" o "pinaagi sa relasyon nimo kang Cristo" o "sumala sa imong pagtuo kang Cristo."
* Kining tanan nga mga pulong adunay parehas nga pasabot sa estado sa pagtuo kang Jesus ug pagkadisipulo niya.
* Timan-i: Usahay ang pulong nga "kang" kauban ang usa ka berbo. Pananglitan, "makig-ambit kang Cristo" nagpasabot nga "makig-ambit" sa kaayohan nga gikan sa pagkahibalo kang Cristo. Ang "maghimaya kang" Cristo nagpasabot nga magmalipayon ug maghatag ug pagdayeg sa Dios kung kinsa si Jesus ug kung unsa ang iyang gibuhat. Ang "motuo kang" Cristo nagpasabot sa pagsalig kaniya ingon nga Manluluwas ug makaila kaniya.


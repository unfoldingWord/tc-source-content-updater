# Gat

Ang Gat usa sa lima sa mga dagkong siyudad sa mga Filistihanon. Makita kini sa amihanan sa Ekron ug sa sidlakan sa Ashdod ug Ashkelon.

* Ang Filistihanon nga hawod nga sundalo nga si Goliat gikan sa siyudad nga Gat.
* Sa panahon ni Samuel, gikawat sa mga Filistihanon ang arka sa pakig-saad gikan sa Israel ug gidala nila kini sa pagano nilang templo sa Ashdod unya gidala sad sa Gat. Apan gisilutan sa Dios ug mga sakit ang mga tawo ani nga mga siyudad, mao nga gipadala nila kini pabalik sa Israel. 
* Kaniadtong miikyas si David gikan kang Haring Saul, mikalagiw siya ngadto sa Gat ug dugay-dugay nga mipuyo didto kauban ang iyang duha ka asawa.


# Gerar

Ang Gerar usa ka syudad ug rehiyon sa Canaan, makit-an kini sa habagatang-kasadpan sa Hebron ug amihanan-kasadpan sa Beerseba.

* Si Haring Abimelek mao ang naghari sa Gerar kaniadtong nagpuyo didto si Abraham ug si Sara. 
* Ang Filistihanon ang naggahum sa rehiyon sa Gerar adtong panahon nga ang mga Israelta nagpuyo sa Canaan.


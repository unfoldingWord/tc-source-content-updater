# Listra

Ang Listra usa ka ngalan sa siyudad sa karaan nga Asia Minor nga naduaw ni Pablo sa usa sa iyang mga biyahe isip misyunaryo.  Makit-an kini sa rehiyon sa Lycaonia nga sa bag-ong panahon mao karon ang nasod sa Turkey.

* Niini nga biyahe sa Listra, nahimamat ni Pablo si Timoteo, nga sama kaniya nahimo sad nga ebenghelista ug taga tukod ug Iglesia.
* Pagkahuman sa pag-ayo ni Pablo sa tawo nga bakol, ang mga tawo sa Listra mosimba unta kang Pablo ug kang Barnabas isip nga mga dios, apan gipugngan sila nila pinaagi sa pagbadlong ug pagdumili sa ilang pagsimba.


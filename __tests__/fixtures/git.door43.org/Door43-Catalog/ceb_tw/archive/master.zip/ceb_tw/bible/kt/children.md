# mga anak, anak

Sa Biblia, ang pulong nga "anak" kasagaran gigamit kini nga nagtumong sa bata pa ang edad, apil na ang mga bag-ong gipanganak. Ang pulong nga "mga anak" gigamit sad sa pipila ka sumbingay.

* Sa Biblia, ang mga disipulo ug mga tagasunod ni Jesus gitawag usahay nga "mga anak"
* Kasagaran ang pulong nga "mga anak" gigamit nga nagtumong sa mga kaliwat sa tawo.
* Ang pulong nga "mga anak sa” pwede gamiton sa pag-atiman o paghulagway sa usa ka butang. Ang mga ehemplo niini mao ang:
* mga anak sa kahayag
* mga anak sa pagtuman
* mga anak sa yawa
* Kini nga pulong pwede sad nga nagtumong sa mga tawo sama sa espirituhanon nga mga anak. Pananglitan,"ang anak sa Dios" nagtumong sa mga tawo nga iya sa Dios pinaagi sa pagtuo kang Jesus.

Mga Sugyot sa Paghubad:

* Ang pulong nga "mga anak" pwede hubaron nga "mga kaliwat" kung kini nagtumong sa mga apo sa usa ka tawo o kaapu-apohan niya, ug uban pa.
* Depende sa konteksto, "mga anak ni" pwede hubaron nga, "mga tawo nga adunay kinaiya ni " o "mga tawo nga sama ug pamatasan ni."
* Kung pwedee, ang mga pulong nga, "mga anak sa Dios" kinahanglan hubaron nga literal tungod kay ang Dios nga atong langitnong Amahan usa ka importante nga tema sa Biblia. Ang pwede sad nga hubad mao, "ang mga tawo nga iya sa Dios" o "mga espirituhanong mga anak sa Dios."
* Sa dihang gitawag ni Jesus ang iyang mga disipulo nga "mga anak" pwede sad kini nga hubaron nga "hinigugma nga mga higala" o " hinigugma ko nga mga disipulo."
* Sa dihang si Pablo ug si Juan nagtumong sa mga tumutuo kang Jesus nga "mga anak," pwede sad kini nga hubaron nga " hinigugma nga mga kauban nga tumutuo."
* Ang pulong nga, "mga anak sa saad" pwede hubaron nga, "mga tawo nga nakadawat sa mga gisaad sa Dios kanila."


# Iglesia

Sa Bag-ong Kasabotan, ang pulong nga "iglesia" nagtumong sa lokal nga pundok nga mga tumutuo kang Jesus nga kanunay nga gatigom aron mag-ampo ug maminaw sa pulong sa Dios nga iwali kanila. Ang pulong nga "ang Iglesia" kasagaran nagtumong sa tanan nga mga Kristohanon.

* Kini nga pulong literal nga nagtumong sa "mga gitawag" nga katigoman o kongregasyon sa mga tawo nga nagtigom sa  pinasahi nga katuyu-an.
* Kung gamiton kini nga pulong nga nagtumong sa mga tumutuo sa bisan diin sa kinatibok-an sa lawas ni Cristo, sa ubang hubad sa Biblia dako ang unang litra nga gigamit nila sa "Iglesia" aron makita ang kalainan sa lokal nga iglesia.
* Kasagaran ang mga tumutuo sa usa ka siyudad magtigom sa usa ka balay. Kini nga mga lokal nga mga iglesia gihatagan ug ngalan sa siyudad sama sa "iglesia sa Efeso." 
* Sa Biblia, ang "iglesia" wala magtumong sa tinukod nga simbahan.

Mga Sugyot sa Paghubad:

* Ang pulong nga "iglesia" pwede sad hubaron nga "pagtigumtigom" o "katigoman" o "kongregasyon" o "mga tawo nga nagtigom."
* Ang pulong o mga pulong nga gigamit sa paghubad niini nga pulong kinahanglan sad nga nagtumong sa tanan nga mga tumutuo, dili lang sa usa ka gamay nga pundok.
* Siguraduhon gyud nga ang hubad sa "iglesia" dili lang nagtumong sa tinukod.
* Ang pulong nga gigamit sa paghubad sa "katigoman" sa Daang Kasabotan pwede sad gamiton sa paghubad niini nga pulong.
* Hunahunaa sad kung giunsa kini paghubad sa lokal o nasodnong hubad sa Biblia.


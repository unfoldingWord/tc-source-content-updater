# Asa

Si Asa usa ka hari nga nangulo sa gingharian sa Juda sulod sa kuwarenta ka tuig, gikan sa ika 913-873 nga mga tuig sa wala pa gipanganak si Cristo.

* Si Haring Asa usa ka maayo nga hari nga nagtangtang sa daghan nga mga diosdiosan ug nagpaundang sa pagsimba sa dili tinuod nga dios. Siya ang nagpabalik sa mga tawo sa pagsimba kang Yahweh.
* Gihatagan ni Yahweh si Haring Asa ug kalampusan sa iyang pakiggiyera batok sa ubang mga nasod.
* Sa ulahi nga mga tuig sa iyang pagkahari, nakipag-alyansa siya kang Aram aron matabangan siya sa giyera batok sa Israel, imbes nga magsalig kang Yahweh.
* Tungod kay miundang siya sa pagsalig kang Yahweh, nagkasakit siya ug grabe hangtod nga namatay siya.


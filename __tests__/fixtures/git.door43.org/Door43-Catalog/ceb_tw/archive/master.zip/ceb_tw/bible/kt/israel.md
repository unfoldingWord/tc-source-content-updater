# Israel, mga Israelita, nasod sa Israel

Israel ang ngalan nga gihatag sa Dios kang Jacob. Nagpasabot kini nga "nakigbisog siya sa Dios."

* Ang mga kaliwat ni Jacob nailhan nga katawhan sa Israel, nasod sa Israel, o mga Israelita.
* Naghimo ang Dios ug kasabotan sa mga tawo sa Israel. Sila ang mga tawo nga napili niya.
* Israel ang ngalan sa ilang nasod.
* Ang nasod sa Israel adunay dose ka mga tribu.
* Kadtong namatay na si haring Solomon, ang nasod nga Israel natunga sa duha ka mga gingharian: ang gingharian sa Juda nga makita sa habagatang dapit, ug ang gingharian sa Israel nga makita sa amihanang dapit.


# Moises

Si Moises usa ka propeta ug pangulo sa mga Israelitang katawhan sulod sa labaw sa 40 ka tuig.

* Gipili sa Dios si Moises nga mao mopagawas sa mga Israelita sa pagka-ulipon didto sa Ehipto ug pangulohan sila ngadto sa Yutang Gisaad.
* Gihatag sa Dios kang Moises ang mga papan nga bato diin gibutang ang iyang mga sugo alang sa mga Israelita.
* Sa dihang hapit na matapos ang iyang kinabuhi, wala mituman si Moises sa Dios mao nga wala siya makapuyo sa Yutang Gisaad nga Canaan.


# Filistia

Ang Filistia ngalan sa dako nga rehiyon sa lugar sa Canaan nga makita sa kabaybayonan sa Dagat sa Mediteraneo.

* Kini nga rehiyon makita sa tabunok kaayo nga baybayon gikan sa amihanan sa Jopa hangtod sa habagatan sa Gaza. Kini adunay mga 64 kilometro sa katas-on ug 16 kilometro ang kalapdon.
* Ang Filistia mao ang gipuy-an sa mga "Filistihanon," ang gamhanan nga mga grupo sa mga tawo nga kanunay nga kaaway sa mga Israelita.


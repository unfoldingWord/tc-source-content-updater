# Ascalon

Sa Biblia, ang Ascalon usa ka daku nga Filistihanon nga siyudad. Naa kini sa kabaybayonan sa Dagat sa Mediterraneo. Naa pa gihapon kini sa Israel hangtod karon.  

* Daghan na nga mga tuig nga nagpuyo ang mga Israelita sa Canaan apan wala gyud nila malupig ang Ascalon.
* Sa panahon ni Samson, kini nga siyudad gipuy-an sa mga Filistihanon.
* Nagpuyo ang mga Filistihanon sa Ascalon sulod sa pila ka gatus ka tuig.
* Usa ni sa lima nga pinakaimportante nga Filistihanon nga siyudad: Ang  Asdod, Ascalon, Ekron, Gath, ug Gaza.


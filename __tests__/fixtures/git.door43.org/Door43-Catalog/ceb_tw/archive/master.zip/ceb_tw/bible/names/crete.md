# Creta, taga-Creta

Ang Creta usa ka isla nga anaa sa habagatan sa kabaybayonan sa Gresya. Ang mga nagpuyo niini nga isla gitwag nga taga Creta.

* Ang apostol Pablo nibyahe sa isla sa Creta sa iyang mga byahe isip misyonero.
* Gibilin ni Pablo ang iyang isig-alagad nga si Tito sa Creta aron tudluan ang mga Kristohanon ug magpili ug mga pangulo alang sa iglesia didto.


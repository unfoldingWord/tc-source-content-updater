# tulion, tuli

Ang pulong nga "tulion" buot ipasabot pagputol sa yamis sa lalaki nga idaran na o sa lalaki nga bata pa. Ang seremonya sa tuli gihimo nga adunay koneksyon niini:

* Gisugo sa Dios si Abraham nga tulion ang matag-usa nga lalaki sa iyang pamilya ug mga ulipon ingon nga timaan kini sa kasabotan nila sa Dios.
* Gisugo sad sa Dios ang mga kaliwat ni Abraham nga ipadayon kini sa pagbuhat sa matag lalalki nga ipanganak sa ilang mga panimalay.
* Ang mga pulong nga "pagtuli sa kasingkasing" nagtumong sa hulagway sa "pagputol" o pagtangtang sa sala sa tawo.
* Sa espirituhanong bahin, "ang natuli" nagtumong sa mga tawo nga gihimo ng putli sa Dios sa ilang mga kasal-anan pinaagi sa dugo ni Jesus nga mao ang iyang mga katawhan.
* Ang pulong nga "dili tuli" nagtumong sa mga dili pa tuli sa lawas. Pwede sad kini nagtumong sa sumbingay alang adtong mga wala pa natuli sa spiritual nga bahin, ug wala pay relasyon sa Dios.

Mga Sugyot sa Paghubad:

* Kung ang kultura sa pinulongan nga hubaron nga gatuli sa ilang mga lalaki, ang pulong nga gigamit nila kinahanglan maoy gamiton niini nga pulong.
* Uban nga paagi sa paghubad niini nga pulong mao ang "pagputol sa palibot" o "pagputol patuyok" o "putlon ang yamis."
* Sa kultura nga wala kahibalo sa pagtuli, maayo siguro nga ipasabot kini sa gamay nga katin-awan o talastas.
* Siguraduhon nga ang pulong nga gamiton sa paghubad dili magtumong sa mga babaye. Maayo nga hubaron kini uban sa pulong o mga pulong nga apil ang "lalaki."


# anghel, arcanghel

Ang anghel usa ka makagagahom nga espirituhanong nilalang nga gihimo sa Dios. Nabuhi ang mga anghel aron mag-alagad sa Dios pinaagi sa pagbuhat sa bisan unsa nga iyang isulti kanila nga buhaton. Ang pulong nga "arcanghel" nagtumong sa anghel nga nagmando o nangulo sa uban pang mga anghel.

* Ang pulong nga "anghel" literal nga nagpasabot nga "mensahero."
* Ang pulong nga "arcanghel" literal nga nagpasabot nga "kinatas-ang mensahero." Ang bugtong nga anghel nga gitumong sa Biblia nga "arcanghel" mao si Miguel.
* Sa Biblia, ang mga anghel naghatag ug mga mensahe sa mga tawo gikan sa Dios. Kini nga mga mensahe naglakip ug mga katugunan mahitungod sa unsay buot sa Dios nga buhaton sa mga tawo.
* Ang mga anghel nagsulti sad sa mga tawo mahitungod sa mga panghitabo nga umaabot o mga panghitabo nga nilabay na.
* Ang mga anghel adunay awtoridad gikan sa Dios ingon nga iyang mga representante, ug usahay sa Biblia, nagsulti sila nga sama nga ang Dios mismo ang nagsulti.
* Ang uban nga mga pamaagi nga nag-alagad ang mga anghel sa Dios mao ang pagpanalipod ug pagpabaskog sa mga tawo.
* Ang usa ka pinasahi nga grupo sa mga pulong nga ang "anghel ni Yahweh," pwedeng adunay daghan nga pasabot: 1) Mahimo kining nagpasabot sa "angel nga nagrepresentar kang Yahweh" o "mensanghero nga nag-alagad kang Yahweh." 2) Mahimo kining magtumong kang Yahweh mismo, nga sama sa daghway ug anghel  samtang makig-istorya siya sa tawo. Bisan asa niining duha ang magpasabot sa paggamit sa anghel ug "Ako" nga sama ra nga si Yahweh mismo ang nagsulti.

Mga Sugyot sa Paghubad:

* Ang mga pamaagi sa paghubad sa "anghel" pwede nga "mensahero gikan sa Dios" o "ang langitnong alagad sa Dios" o "ang espirituhanong mensahero sa Dios."
* Ang pulong nga "arcanghel" mahimong hubaron nga "kinatas-ang anghel" o "kinatas-ang nagmando nga anghel" o "pangulo sa mga anghel."
* Hunahunaa sad kung giunsa paghubad niining mga pulong sa nasudnong pinulongan o sa ubang lokal nga pinulongan.
* Kinahanglan ang mga pulong nga "anghel ni Yahweh" hubaron nga gigamit ang mga pulong alang sa "anghel" ug "Yahweh" aron pwede kini siya masabtan sa iyang kalainlaing pagsabot. Ang posible nga paghubad pwede sad "anghel gikan ni Yahweh" o "anghel nga gipadala ni Yahweh" o "ang hitsura ni Yahweh sama sa anghel."


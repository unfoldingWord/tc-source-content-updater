# pagtabon sa sala, ula

Ang mga pulong nga "ula" o "pagtabon sa sala" nagtumong sa gihatag sa Dios nga sakripisyo aron mabayran ang mga sala sa mga tawo ug aron tagbawon ang iyang kapungot sa sala.

* Sa panahon sa Daang Kasabotan, gitugtan sa Dios ang temporaryo nga pagtabon sa sala sa mga Israelita pinaagi sa paghalad ug dugo, diin magpatay sila ug mananap.
* Sa nakatala sa Bag-ong Kasabotan, ang pagkamatay ni Cristo diha sa krus mao lang ang tinuod ug permamente nga pagtabon sa sala.
* Sa dihang namatay na si Jesus giangkon niya ang silot nga alang unta sa mga tawo tungod sa ilang mga sala. Nabayaran ang pagtabon sa sala tungod sa pagsakripisyo sa iyang kinabuhi.

Mga Sugyot sa Paghubad

* Ang pulong nga "ula" pwede mahubad sa pulong o mga pulong nga nagpasabot, "bayad alang" o "gihatag nga bayad alang" o "aron mapasaylo ang sala sa usa ka tawo" o "magtarong sa usa ka krimen."
* Mga lain nga paghubad sa "pagtabon sa sala": "bayad" o "sakripisyo aron mabayran ang sala" o "naghatag sa paagi sa kapasayloan."
* Siguraduha nga ang paghubad niini nga pulong dili nagtumong sa bayad sa kuwarta.


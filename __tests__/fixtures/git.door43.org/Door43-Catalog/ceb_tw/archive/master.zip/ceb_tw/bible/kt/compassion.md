# kaluoy, maluloy-on

Ang pulong nga "kaluoy" nagtumong sa pagbati ug kabalaka alang sa ubang mga tawo, hilabi na sa mga nag-antos. Ang "maluloy-on" nga tawo nag-atiman sa ubang tawo ug nagtabang kanila.

* Ang pulong nga "kaluoy" kasagaran dili lang pagbati kung dili apil sad ang pag-atiman sa mga tawong nanginahanglan ug pagtabang kanila.
* Ang Biblia nag-ingon nga ang Dios maluloy-on, nga puno siya ug gugma ug kaluoy.
* Sa sulat ni Pablo sa mga taga-Colosas, giingnan niya sila nga "sul-ubon ang kaluoy." Gitudluan niya sila nga mag-atiman sa mga tawo ug magtabang gyud sa uban nga nanginahanglan.

Mga Sugyot sa Paghubad:

* Ang literal nga pasabot sa "kaluoy" mao ang "kaluoy gikan sa tinai." Usa kini ka sumbingay nga nagpasabot sa "naluoy gyud kaayo." Ang ubang mga pinulongan mahimong adunay sumbingay nga parehas ug pasabot niini.
* Ang ubang paghubad sa "kaluoy" mao ang "pag-atiman pag-ayo kang" o "kaluoy nga motabang."
* Ang pulong nga "maluloy-on" mahimong hubaron nga "maatimanon ug matinabangon" o "adunay dakong paghigugma ug kaluoy."


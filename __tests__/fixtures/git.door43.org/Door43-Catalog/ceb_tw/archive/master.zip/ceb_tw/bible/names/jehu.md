# Jehu

Ang Jehu mao ang ngalan sa duha ka tawo sa Daang Kasabotan.

* Ang usa nga ginganlang Jehu mao ang propeta sa panahon nga naghari si Haring Ahab sa Israel ug si Haring Josaphat sa Juda.
* Aduna sad usa ka heneral nga ginganlang Jehu ug nahimong hari sa Juda ug naghari sulod sa bente-otso ka mga tuig.
* Gipatay ni Jehu ang tanang paryente ni haring Ahab apil ang daotan nga rayna nga si Jezebel.
* Gipatay sad niya ang duha ka mga daotan nga hari nga paryente ni Ahab: Si Joram sa Israel ug Ahasias sa Juda.


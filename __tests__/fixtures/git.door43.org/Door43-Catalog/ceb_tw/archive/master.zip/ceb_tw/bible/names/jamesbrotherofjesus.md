# Santiago (igsoon ni Jesus)

Si Santiago usa sa mga anak ni Maria ug Jose, ug usa siya sa mga igsoon ni Jesus.

* Sa panahon ni Jesus, si Santiago ug ang iyang mga igsoon wala motuo nga si Jesus mao ang Mesias.
* Kadugayan, pagkahuman sa pagkabanhaw ni Jesus, mituo si Santiago kaniya ug nahimong usa sa mga pangulo sa Iglesia sa Jerusalem.
* Nagsulat si Santiago sa mga Kristuhanon nga nagpuyo sa ubang mga nasod. Ug kini nga sulat naa sa Biblia ug gitawag nga "Santiago."


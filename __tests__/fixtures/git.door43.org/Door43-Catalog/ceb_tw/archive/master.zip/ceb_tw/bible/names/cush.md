# Cush

Si Cush ang anak nga lalaki ni Ham nga anak nga lalaki ni Noe. Mao nga si Cush apo ni Noe.

* Sa panahon sa Daang Kasabotan, adunay dapit nga gitawag nga Cush, nga tingali ginganlan sa apo ni Noe.
* Ang Etiopia mao ang Griego nga ngalan sa dapit nga gitawag sa mga Hebreo nga Cush.


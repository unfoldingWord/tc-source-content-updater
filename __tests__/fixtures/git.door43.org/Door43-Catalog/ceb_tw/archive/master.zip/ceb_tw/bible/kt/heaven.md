# langit, kalangitan, langitnong

Ang pulong sa Ingles nga "heaven" (langit) nagtumong sa kung asa nagpuyo ang Dios. Ang sama nga pulong pwede sad magpasabot sa Ingles nga "sky" (langit) depende sa konteksto.

* Ang mga pulong nga "mga kalangitan" nagtumong sa tanang makita nga sa ibabaw sa yuta, apil ang adlaw, buwan, ug mga bitoon. Apil sad niini ang mga layo kaayo nga mga planeta nga dili na makita sa mga tawo gikan sa kalibotan.
* Ang pulong nga "langit" nga "sky" sa Ingles nagtumong sad sa asul nga hawan sa taas sa yuta nga adunay panganod ug hangin nga atong giginhawa. Kasagaran, ang adlaw ug buwan giingon nga "tua sa langit."
* Sa ubang konteksto sa Biblia, ang pulong nga "langit" pwede magtumong sa hawan ibabaw sa yuta o sa lugar diin nagpuyo ang Dios.
* Kung gigamit nga sumbingay ang "langit," nagtumong kini sa Dios. Pananglitan, niadtong nagsulat si Mateo mahitungod sa "gingharian sa langit," nagtumong siya sa gingharian sa Dios.

Mga Sugyot sa Paghubad:

* Kung gigamit ang "langit" nga sumbingay, pwede kini hubaron nga "Dios."
* Ang "gingharian sa langit’ sa libro ni Mateo, labing maayo nga ipabilin ang pulong nga "langit" tungod kay timailhan kini sa pamaagi sa pagsulat ni Mateo sa maayong balita.
* Ang mga pulong nga "kalangitan" o "mga butang sa kalangitan" pwede hubaron nga "adlaw, buwan, ug mga bitoon" o "tanang mga bitoon sa mga kalibotan."
* Ang mga pulong nga "mga bitoon sa langit" pwede hubaron nga "mga bitoon sa kalangitan" o "mga bitoon sa tanang kalibotan."


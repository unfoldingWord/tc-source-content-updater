# Asya

Sa Biblia, adtong una, adunay usa ka probinsiya sa Imperyo sa Roma nga gitawag nga Asya. Naa kini sa kasadpan nga parte nga karon gitawag nga Turkey.

* Nagbiyahe si Pablo sa pipila ka siyudad sa Asya aron magsangyaw sa maayong balita. Duha sa siyudad nga iyang giadtuan mao ang Efeso ug Colosas.
* Aron dili maglibog, pwede mahubad kini nga, "ang karaan nga probinsiya sa Roma nga ginganlang Asya.
* Ang tanan nga Iglesia nga nahisgot sa Pinadayag makita sa probinsiya sa Roma nga ginganlan nga Asya.


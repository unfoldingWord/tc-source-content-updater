# Hagar

Si Hagar mao ang kaugalingong ulipon ni Sara.

* Si Sarai nga sa kadugayan ginganlan ug Sara, gihatag si Hagar sa iyang bana nga si Abram ingon nga ulipong asawa.
* Gusto ni Sarai nga manganak si Hagar alang kaniya ug kang Abram.
* Nanganak si Hagar sa anak ni Abram nga si Ismael.


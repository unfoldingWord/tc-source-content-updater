# Persia, Taga- Persia

Ang Persia usa ka Imperyo nga gitukod ni Cyrus nga Gamhanan sa 550 ka tuig sa wala pa gipanganak si Cristo. Ang sentro niini makita sa siyudad nga karon mao ang Iran. Ang mga tawo sa Persia gitawag nga "taga-Persia."

* Ang Imperyo sa Persia dako kaayo ug gamhanan.
* Sa panahon sa pagmando ni Haring Cyrus nakagawas ang mga Judio sa pagkabinihag sa Babilonia, ug gitukod nila pag-usab ang templo sa Jerusalem, nga gigamit ang pondo nga gihatag sa Imperyo sa Persia.
* Si Haring Artaxerxes mao ang pangulo sa Imperyo sa Persia niadtong si Esdras ug Nehemias miadto balik sa Jerusalem aron itukod pag-usab ang mga paril didto.
* Si Ester nahimong rayna sa Imperyo sa Persia sa dihang naminyo siya kang Haring Ahasuero.


# Jesreel

Ang Jesreel ngalan sa usa ka importante nga syudad sa Israel nga teritoryo sa tribu nga Isacar. Nahimutang kini sa habagatang-kasagpan sa Parat nga Dagat. Adunay pipila ka mga hari sa Israel ang nagtukod sa ilang palasyo didto.  

* Ang siyudad sa Jesreel naa sa kasadpan sa Kapatagan sa Migido, nga gitawag sad ug Walog sa Jesreel.
* Ang ubasan sa Nabot nahimutang sa Jesreel, duol sa palasyo ni Ahab. Didto nagtagna si propeta Elijah batok kang Ahab.
* Ang dautan nga asawa ni Ahab nga si Jesabel napatay sa Jesreel.
* Daghan pang mahinungdanon nga panghitabo niini nga siyudad, apil ang pipila ka mga gubat.


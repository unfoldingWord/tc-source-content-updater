# Pari, Pagkapari

Sa Biblia, ang pari usa ka tawo nga gipili aron maghatag ug mga sakripisyo sa Dios alang sa mga tawo sa Dios. Ang "pagkapari" trabaho o katungdanan sa usa ka pari.

* Sa Daang Kasabotan, gipili sa Dios si Aron ug ang iyang mga kaliwat nga mahimong iyang mga pari alang sa mga tawo sa Israel.
* Ang "pagkapari" mao ang katungod ug responsibilidad nga gipasa sa amahan sa iyang anak sa banay ni Levita.
* Ang Israelita nga mga pari adunay responsibilidad sa paghalad sa sakripisyo sa mga tawo ngadto sa Dios, apil ang ubang mga katungdanan sa templo.
* Ang mga pari naghalad sad ug inadlaw nga mga pag-ampo sa Dios alang sa mga tawo ug pagbuhat sa uban pang relihiyosong tulumanon.
* Ang mga pari maoy maghatag ug pormal nga mga panalangin sa mga tawo ug nagtudlo kanila sa mga balaod sa Dios.
* Sa panahon ni Jesus, adunay lainlain nga klase nga mga pari, apil ang mga pangulong pari ug ang kinatas-ang pari.
* Si Jesus ang atong "labing taas nga pari" nga gapangamuyo alang kanato sa atubangan sa Dios. Gihalad niya ang iyang kaugalingon nga hingpit nga sakripisyo alang sa sala. Nagpasabot kini nga mga sakripisyo nga gihimo sa tawhanong pari dili na kinahanglan.
* Sa Bag-ong Kasabotan, ang matag tumutuo kang Jesus gitawag nga "pari" nga direkta na nga makaadto sa Dios sa pag-ampo sa pagpangamuyo sa iyang kaugalingon ug sa ubang mga tawo.
* Niadtong una pa kayo nga panahaon, adunay say pagano nga mga pari nga naghatag ug halad sa dili tinuod nga dios sama ni Baal.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pulong nga "pari" pwede hubaron nga "gisakripisyo nga tawo" o "tigpatiwala sa Dios" o "tigpatunga alang sa mga sakripisyo" o "tawo nga gipili sa Dios nga morepresentar kaniya."
* Ang hubad sa "pari" kinahanglan lahi sa hubad sa "tigpataliwala."
* Ang pipila ka mga hubad mas gusto kanunay moingon nga sama sa, "paring Israelita" o "paring Judio" o "pari ni Yahweh" o "pari ni Baal" sa pagpatin-aw niini aron dili kini hunahunaon nga pari sa karon nga panahon.
* Ang pulong nga gigamit sa paghubad sa "pari" kinahanglan lahi sa pulong nga "pangulong pari," "kinatas-ang pari," "levita" ug "propeta."


# Gomorra

Ang Gomorra usa ka siyudad nga makita sa tabunok nga walog sa subangan sa rehiyon sa Babilonia.

* Ang Gomorra kanayon nga mahisgutan uban sa siyudad sa Sodoma; ang mga tawo niini nga mga siyudad makasal-anon o dautan kaayo.
* Adunay daghan nga mga hari nga naggiyera sa rehiyon diin ang Sodoma ug Gomorra makita.
* Sa dihang ang pamilya ni Lot gibihag adtong mga taga Sodoma nga nakig-away sa ubang mga siyudad, giluwas sila ni Abraham ug sa iyang mga tawo.
* Wala magdugay, ang Sodoma ug Gomorra gilaglag sa Dios tungod sa pagkadautan sa mga tawo nga nagpuyo didto.


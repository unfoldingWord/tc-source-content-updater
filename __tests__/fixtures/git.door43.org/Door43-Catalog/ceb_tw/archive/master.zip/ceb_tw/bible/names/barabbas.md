# Barabas

Si Barabas usa ka piniriso sa Jerusalem sa panahon nga si Jesus naaresto.

* Si Barabas nakahimo ug krimen sa pagpatay ug pagsupak batok sa gobyerno sa Roma.
* Gipapili ni Poncio Pilato ang mga tawo kung kinsa ang pagawason sa prisohan: Si Jesu Cristo o si Barabas ba. Ang gipili sa mga tawo si Barabas.


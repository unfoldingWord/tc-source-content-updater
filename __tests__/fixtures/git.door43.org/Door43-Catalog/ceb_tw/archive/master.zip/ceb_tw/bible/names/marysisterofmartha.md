# Si Maria nga igsoon ni Marta

Si Maria, babaye nga gikan sa Betania nga misunod kang Jesus.

* Si Maria adunay igsoon nga babaye nga si Marta ug igsoon nga lalaki nga si  Lazaro nga misunod sad kang Jesus.

* Usa ka panahon o higayon gidayeg ni Jesus si Maria sa pagpili niya nga maminaw kaniya kaysa mahasol sa pag-andam ug pagkaon alang  kaniya.
* Usa ka panahon sa dihang si Jesus mikaon sa Betania, gidihugan siya ni Maria ug mahal kaayo nga pahumot sa iyang mga tiil aron simbahon siya. Gidayeg siya ni Jesus sa pagbuhat niini.


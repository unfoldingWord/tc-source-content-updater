# Kalibutan, Kalibutanon

Ang pulong nga "kalibutan" kasagaran nagtumong lang sa kinatibuk-an sa kalibutan nga diin ang mga tawo nagpuyo: ang yuta. Ang pulong nga "kalibutanon" naghulagway sa dautan nga kinaiya ug batasan sa mga tawo nga nagpuyo niini nga kalibutan.

* Kasagaran ang pulong nga "kalibutan" nagtumong sa mga langit ug yuta, ug ang tanan nga anaa niini.
* Sa daghan nga mga konteksto, ang "kalibutan" nagpasabot gyud sa "mga tawo niini nga kalibutan."
* Usahay gipasabot nga kini nagtumong sa mga dautan nga mga tawo sa yuta o mga tawo nga wala motuman sa Dios.
* Ang apostol nga si Pablo migamit sa "kalibutan" sa pagtumong sa makaugalingon nga batasan ug dunot nga kinaiya sa mga tawo nga nagpuyo niini nga kalibutan. Pwede ilakip niini ang kinaugalingong pagkamatarong, mga buhat sa relihiyon nga diin nakabasi sa tawhanon nga pagbudlay o paglimbasog.
* Ang mga tawo ug mga butang nga makit-an nga sama niini nga mga kinaiya mao ang gitawag nga "kalibutanon."


Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "kalibutan" pwede sad hubaron nga "kinatibuk-an sa kalibutan" o "mga tawo niini nga kalibutan" o "dunot nga mga butang niini nga kalibutan" o "dautan nga batasan sa mga tawo niini nga kalibutan."
* Ang mga pulong nga "ang tanang kalibutan" kasagaran nagpasabot sa "daghan nga mga tawo" ug nagtumong sa mga tawo nga nagpuyo sa usa ka rehiyon. Pananglitan, ang "tanan nga kalibutan miadto sa Ehipto" pwede kini hubaron nga "daghan nga mga tawo gikan sa lainlain nga mga nasod palibot sa Ehipto miadto didto.
* Uban nga paagi sa paghubad sa "ang tanan nga kalibutan mingadto sa ilang kaugalingong lungsod aron magpatala sa Romano nga sensus" mao nga "daghan nga mga tawo nga nagpuyo sa mga rehiyon nga gimandohan sa Roma mingadto..."
* Depende sa konteksto, ang pulong nga "kalibutanon" pwede hubaron nga "dautan" o "makasasala" o "makaugalingon" o "dili diosnon" o "dunot" o "natakdan sa dunot nga kinaiya sa mga tawo niini nga kalibutan."


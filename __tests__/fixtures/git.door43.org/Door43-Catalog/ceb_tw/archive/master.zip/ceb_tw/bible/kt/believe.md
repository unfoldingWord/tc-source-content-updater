# pagtoo

Ang pulong nga "pagtoo" ug pagtoo sa" parehas lang ug gipasabot, apan adunay gamay lang nga kalainan sa ilang ipasabot:

Mga sugyot sa Paghubad

* Ang "pagtoo" pwede hubaron nga "nahibal-an nga tinuod" o "nahibal-an nga sakto".
* Ang "pagtoo sa" pwede hubaron nga, "mosalig gyud" o "mosalig ug motuman" ug "mosalig ug maayo ug motuman."


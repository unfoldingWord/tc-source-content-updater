# pagbalaan

Ang pagbalaan mao ang paggahin o himoon nga balaan. Ang pagbalaan mao ang pamaagi nga himoon nga balaan ang usa ka tawo.

* Sa Daang Kasabotan, ang pipila ka mga tawo ug mga butang gihimong balaan, o gigahin, alang sa pag-alagad sa Dios.
* Ang Bag-ong Kasabotan nagtudlo nga gihimong balaan sa Dios ang mga tawo nga mituo kang Cristo. Buot ipasabot gihimo sila sa Dios nga balaan ug gigahin nga mag-alagad kaniya.
* Ang mga tumutuo kang Jesus gimanduan sad nga himoon nila nga hinlo ang ilang mga kaugalingon aron mahimong balaan ang tanan nga ilang buhaton.

Mga sugyot sa paghubad 

* Depende sa konteksto, ang "pagbalaan" pwede hubaron nga "igahin" o "himoon nga balaan" o "hinloan."
* Kung ang mga tawo himoong balaan ang ilang kaugalingon, nagpasabot kini nga gihinluan ug gihalad nila ang ilang mga kaugalingon sa pag-alagad sa Dios. Kasagaran ang "paggahin alang sa Dios" gigamit sa Biblia nga adunay sama nga gipasabot niini.
* Kung ang gipasabot "gigahin alang sa Dios" kini nga pulong pwede hubaron nga "gipahinungod ang usa ka tawo.


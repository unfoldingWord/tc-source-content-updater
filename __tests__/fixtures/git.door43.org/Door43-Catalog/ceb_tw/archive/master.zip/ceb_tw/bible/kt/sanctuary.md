# balaan nga puloy-anan

Ang pulong nga "balaan nga puloy-anan" literal nga buot ipasabot "balaan nga lugar" ug nagtumong sa lugar nga gihimo sa Dios nga sagrado ug balaan. Nagtumong sad kini sa lugar nga makahatag ug panalipod ug kaluwasan.

* Sa Daang Kasabotan, ang pulong nga "balaan nga puloy-anan" kasagaran nagtumong sa tabernakulo o templo nga tinukod nga diin makita ang "dapit nga balaan" ug ang "dapit nga labing balaan."
* Ang Dios nagtumong sa balaan nga puloy-anan nga diin siya nagpuyo kauban sa iyang mga katawhan, nga ang mga Israelita.
* Gitawag sad niya ang iyang kauagalingon nga "balaan nga puloy-anan" o luwas nga lugar alang sa iyang mga katawhan nga diin sila mapanalipdan.

Mga Sugyot sa Paghubad:

* Kini nga pulong buot ipasabot "ginahin nga lugar."
* Depende sa konteksto, ang pulong nga "balaan nga lugar" pwede hubaron nga "balaan nga lugar" o "sagrado nga tinukod" o "balaang lugar nga puy-anan sa Dios" o "balaang lugar sa panalipod" o "sagrado nga lugar sa kaluwasan."  
* Ang mga pulong nga "siklo sa balaan nga puloy-anan" pwede hubaron nga "klase sa siklo nga gihatag alang sa tabernakulo" o "siklo nga gigamit isip buhis aron sa pag-amping sa templo."
* Sa moderno nga panahon ang pulong nga "balaan nga puloy-anan" kasagaran nagtumong sa lawak o kwarto nga diin ang Iglesia magsimba. Susihon aron masiguro gyud nga ang paghubad niini nga pulong dili sama ug pasabot sa teksto sa Biblia.


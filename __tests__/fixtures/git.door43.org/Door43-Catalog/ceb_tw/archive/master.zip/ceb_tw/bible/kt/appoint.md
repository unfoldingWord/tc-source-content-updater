# gipili, pinili

Ang pulong nga "gipili" ug "pinili" nagtumong sa pagpili sa usa ka tawo nga maoy motuman sa usa ka tahas o katungdanan.

* Ang "gipili" nagtumong sa makadawat sa usa ka butang sama sa, "gipili sa walay katapusan nga kinabuhi." Kini nagpasabot nga sila gipili nga makadawat sa kinabuhing dayon.
* Ang mga pulong nga "gipili nga panahon" nagtumong sa "gitakda nga panahon" o " giplano nga panahon" sa Dios nga mahitabo gyud.
* Ang pulong nga "gipiili" nagpasabot sad nga "gimanduan" o "gitahasan" ang usa ka tawo nga mobuhat sa usa ka buluhaton.

Mga Sugyot sa Paghubad

* Depende sa konteksto, naay daghan nga mga pamaagi sa paghubad sa "gipili": pwede sad, "gitahasan" o "pormal nga gipili" o "gitudlo."
* Ang pulong nga "pinili" pwede hubaron nga "gitahasan" o "giplano" o "mao gyuy gipili."
* Ang mga pulong nga "maoy gipili" pwede sad nga, "maoy pinili."


# minatay, pagminatay

Ang pulong nga "minatay" ug ang "pagminatay," nagtumong kini sa hilabihang kaguol, kasubo o kasakit.

* Usahay kini naglakip sa malalom nga pagmahay sa sala, o pagkalu-oy sa mga tawo nga nakasinati ug katalagman.
* Ang pagminatay pwede ilakip ang pag-agulo, pagbakho o pagdanguyngoy.

Mga Sugyot sa Paghubad:

* Ang pulong nga "minatay" pwede hubaron nga "nagguol kaayo" o "pagdanguyngoy sa hailabihan nga kasakit" o "magpakasubo."
* Ang "pagminatay" pwede hubaron nga "hilabihang kaguol."


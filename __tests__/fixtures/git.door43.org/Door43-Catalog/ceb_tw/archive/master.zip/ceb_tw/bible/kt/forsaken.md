# pasagdan, gipasagdan

Ang pulong nga "pasagdan" buot ipasabot pagbiya sa usa ka tawo o sa pagdili sa usa ka butang. Sa usa ka tawo nga "gipasagdan" gitalikdan o gibiyaan sa lain nga tawo.

* Kung "pasagdan" sa mga tawo ang Dios, buot ipasabot dili sila matinumanon kaniya pinaagi sa dili pagsunod.
* Kung "pasagdan" sa Dios ang tawo, buot ipasabot mihunong na ang Dios sa pagtabang kanila ug gitugutan sila nga (nga) makasinati ug pag-antos aron sila mobalik kaniya.
* Kini nga pulong pwede sad buot ipasabot pasagdan ang mga butang, sama sa pagpasagad, o wala gasunod sa katudlu-an sa Dios.
* Ang pulong nga "gipasagdan" pwede gamitan nga nangagi na sama sa "gipasagdan ka niya" o pagtumong sa usa ka tawo nga "napasagdan."

Mga Sugyot sa Paghubad

* Uban nga paagi sa paghubad niini nga pulong pwede ilakip ang, "pagbiya" o "pagpasagad" o "sa paghatag sa" o "palayo gikan sa" o "gibiyaan,)" depende sa konteksto.
* Ang pasagdan ang balaod sa Dios pwede hubaron nga "mosupak sa balaod sa Dios." Pwede sad kini hubaron nga "pagbiya" o "pagtugyan na sa" o "hunong sa pagtuman" sa iyang mga katudluan o mga balaod.
* Ang mga pulong "nga pasagdan" pwede hubaron ingon "nga pabiyaan" o "gitalikdan."
* Ang proyektong pinulongan pwede maklaro kung mogamit ug lain nga mga pulong sa paghubad niini (nga pulong), depende kung ang teksto naghisgot mahitungod sa pagpasagad sas butang o sa tawo.


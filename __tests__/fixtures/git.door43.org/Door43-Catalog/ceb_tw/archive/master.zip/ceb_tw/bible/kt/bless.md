# Pagpanalangin, Gipanalanginan, Panalangin

Ang "pagpanalangin" sa usa ka tawo o usa ka butang nagpasabot nga adunay mahitabo nga maayo o maka-angkon ug mga butang nga adunay kapuslanan ang usa ka tawo o butang nga gipanalanginan.

* Ang pagpanalangin sa usa ka tawo nagpasabot sad sa tinguha nga adunay positibo ug mapuslanon nga mahitabo sa gipanalanginan.
* Sa panahon sa Biblia, ang usa ka amahan kasagaran gasulti ug pormal nga panalangin sa iyang mga anak.
* Kung ang mga tawo "nagpanalangin" sa Dios o nagpahayag sa tinguha nga ang Dios mapanalanginan, nagpasabot kini nga nagdayeg sila kaniya.
* Ang pulong nga "pagpanalangin" gigamit usahay aron igahin ang pagkaon sa dili pa kaunon, o sa pagpasalamat ug pagdayeg sa Dios alang sa pagkaon.

Importante nga dili lang kini sabton nga nagtumong sa pag-angkon sa daghan kaayo nga mga materyal nga mga butang o maayo nga pisikal nga kahimtang lamang. Hunahunaa sad nga kini nagtumong sa uban pang mga daghang katudluan sa Kasulatan mahitungod sa gugma, kalu-oy ug grasya sa Dios nga dili lang sa niadto nga panahon apan hangtod karon. Hunahunaa ang pag-atiman, pagpanalipod, ug presensiya sa Espiritu sa Dios. Ug sa pagpanalangin nato sa Dios, pwede kita maghalad ug pagpasalamat, paghatag ug bili kaniya ug pagsabot samtang gakat-on ug gasunod (gatuman) kaniya.

Mga Sugyot sa Paghubad

* Ang "pagpanalangin" pwede sad hubaron nga, "maghatag ug madagayaon alang sa" o "sa magmaluluy-on ug magpakita ug pabor ngadto sa uban."
* "Ang Dios naghatag ug dakong panalangin sa" pwede sad hubaron nga, "Naghatag ang Dios ug daghan nga mga maayong butang sa" o "Ang Dios naghatag ug daghan nga mga panalangin alang" o "tungod sa Dios daghang mga maaayong butang ang nahitabo sa."
* "Gipanalanginan siya" pwede sad hubaron nga, "makaangkon gyud siya sa kaayuahan" o "makatagamtam siya sa maayo nga mga butang" o "palambuon siya sa Dios."
* "Gipanalanginan ang tawo nga" pwede sad hubaron nga, "Maayo kaayo nga ang tawo."
* Ang mga pulong sama sa, "mapanalanginan ang Ginoo" pwede sad hubaron nga, "Hinaot nga ang Ginoo madayeg" o "Madeyeg ang Ginoo" o "Nagdaayeg ako sa Ginoo."
* Sa konteksto sa pagpanalangin sa pagkaon, pwede sad hubaron nga, "salamat sa Ginoo sa pagkaon" o "madayeg ang Dios sa paghatag kanila sa pagkaon" o "gibalaan ang pagkaon pinaagi sa pagdayeg sa Dios niini."


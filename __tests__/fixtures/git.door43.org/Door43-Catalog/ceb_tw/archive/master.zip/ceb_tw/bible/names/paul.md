# Pablo, Saul

Si Pablo mao ang pangulo sa mga nauna nga mga Iglesia nga gisugo ni Jesus aron dalhon niya ang maayong mga balita sa ubang mga grupo nga mga tawo.

* Si Pablo usa ka Judio nga natawo sa siyudad sa Tarsus sa Roma, mao nga usa sad siya ka Romano.
* Si Pablo unang gitawag sa iyang Judio nga ngalan nga Saul.
* Si Saul usa ka relihiyoso nga pangulo sa mga Judio ug gipanakop niya ang mga Judio nga nahimong kristuhanon tungod kay wala siya motuo kang Jesus.
* Nagpakita si Jesus kang Saul pinaagi sa makabuta nga kahayag, ug giingnan niya siya nga undangon niya ang pagpasakit sa mga Kristohanon. Nagsugo si Jesus sa usa ka Kristohanon nga tawo aron tudluan si Saul, ug mituo siya kang Jesus.
* Sa una gitudluan ni Saul ang mga Judio mahitungod kang Jesus.
* Kadugayan, gisugo sa Dios si Saul aron magtudlo mahitungod kang Jesus sa ubang mga grupo nga mga tawo sa daghang mga siyudad sa Roma. Ug kadugayan gigamit niya ang iyang Romano nga ngalan nga Pablo. 
* Misulat sad ug mga sulat si Pablo aron awhagon ug tudluan ang mga Kristohanon sa lainlaing mga siyudad. Ang pipila sa iyang mga sulat anaa sa Biblia.


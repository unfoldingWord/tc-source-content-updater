# Pilato

Si Pilato usa ka Romano nga gobernador nga naghukom kang Jesus sa kamatayon.

* Tungod kay si Pilato mao ang gobernador, aduna siyay awtoridad sa paghukom sa mga kriminal.
* Gusto sa mga relihiyosong pangulo sa mga Judio nga ipalansang ni Pilato sa krus si Jesus, mao nga namakak ug miingon sila nga si Jesus usa ka kriminal.
* Nakaamgo si Pilato nga si Jesus walay sala, apan nahadlok siya sa panun sa mga tawo, mao nga gimanduan niya ang iyang mga sundalo sa paglansang kang Jesus sa krus.


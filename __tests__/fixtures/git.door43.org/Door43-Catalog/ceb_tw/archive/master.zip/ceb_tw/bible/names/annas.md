# Anas

Si Anas mao ang kinatas-ang pari sa mga Judio sa Jerusalem sulod sa 10 ka tuig, gikan sa ika 6 ka tuig hangtod sa ika15 ka tuig pagkahuman natawo si Cristo. Unya gitangtang siya sa gobyernong Romano gikan sa pagka kinatas-ang pari apan nagpadayon gihapon siya nga adunay impluwensiya nga pangulo sa mga Judio.

* Si Anas ang ugangan ni Caiapas, ang opisyal nga kinatas-ang pari sa panahon sa ministeryo ni Jesus.
* Sa sinugdan, gidala si Jesus kang Anas aron imbestigahon, bisan pa nga si Caiapas mao ang opisyal nga kinatas-ang pari niadtong panahona.
* Pagkahuman ug retiro sa mga kinatas-ang pari, nagpabilin lang gihapon ang ilang titulo uban ang pipila ka mga responsibilidad niini, mao nga si Anas gitawag gihapon nga kinatas-ang pari sa panahon sa pagkapari ni Caiapas ug sa uban pa.


# Dayeg, Pagdayeg

Ang Pagdayeg taas nga pagpasidungog ug pagtahod sa usa ka tawo. Nagpasabot sad kini nga hatagan ang usa ka tawo ug taas nga posisyon.

* Sa Biblia, ang pulong nga "dayeg" kasagarang gigamit sa pagdayeg sa Dios.
* Sa dihang ang tawo nagdayeg sa iyang kaugalingon, nagpasabot kini nga gihunahuna niya ang iyang kaugalingon sa mapahitas-on o arongante nga pamaagi.

Mga Sugyot sa Paghubad

* Pamaagi sa paghubad sa "pagdayeg" pwede sad, "taas nga pagpasidungog" o "hilabihan nga pagtahod" o "pagtaas" o "pagsulti ug maayo kaayo mahitungod sa."
* Sa uban nga mga konteksto, pwede hubaron pinaagi sa pulong o mga pulong nga nagpasabot ug, "pagbutang sa taas nga posisyon" o "pasidunggan pa pag-ayog " o "mapahitas-on nga paghisgot."
* "Ayaw dayga ang imong kaugalingon" pwede sad hubaron nga "ayaw hunahunaa ang imong kaugalingon nga taas ra kaayo" o "ayaw pagpanghambog mahitungod sa imong kaugalingon."
* "Kadtong magdayeg sa ilang kaugalignon" pwede sad hubaron nga "Kadtong mapahitas-on nga naghunahuna sa ilang kaugalingon" o "Kadtong naghinambog mahitungod sa ilang kaugalingon."


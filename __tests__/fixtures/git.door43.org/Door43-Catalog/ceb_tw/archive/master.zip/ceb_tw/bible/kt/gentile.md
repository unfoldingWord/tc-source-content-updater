# Gentil

Ang Gentil tawo nga dili kaliwat ni Jacob ug sa iyang dose ka mga anak. Ang mga Gentil mga tawo nga dili mga Judio.

* Sa Kasulatan, may mga higayon nga ang pulong nga mga Gentil nagtumong sa mga "dili tuli" tungod kay daghan kanila wala tuli-a ang ilang mga anak nga lalaki dili sama sa gihimo sa mga Israelita.
* Tungod kay gipili sa Dios ang mga Judio nga mahimo niyang pinasahi nga katawhan, giisip nila nga ang mga Gentil mga taga-gawas nga dili gyud pwede nga mahimong katawhan sa Dios.
* Ang mga Judio gitawag sad nga mga Israelita o mga Hebreo sa lainlain nga mga panahon sa kasaysayan. Ang tanan nga dili Judio gitawag nga nga Gentil.
* Ang Gentil pwede sad hubaron nga "dili mga Judio" o "dili Israelita" (Daang Kasabotan).
* Sa tradisyon, ang mga Judio dili gyud mokaon kauban ang mga Gentil, nga maoy nahimong unang hinungdan sa mga problema sa mga unang Iglesia.


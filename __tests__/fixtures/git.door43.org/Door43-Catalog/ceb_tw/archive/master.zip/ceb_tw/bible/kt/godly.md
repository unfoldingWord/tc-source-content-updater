# diosnon, pagkadiosnon

Ang pulong nga"diosnon" gigamit sa paghulagway sa usa ka tawo nga ang mga buhat nagpasidungog sa Dios ug nagpakita kung unsa ang hulagway sa Dios. Ang kinabuhi nga mapasidungganon sa Dios pinaagi sa paghimo sa iyang kabubut-on nagtumong kini sa "pagkadiosnon."

* Ang tawo nga adunay diosnon nga kinaiya magpakita sa mga bunga sa Balaan nga Espiritu, sama sa gugma, kalipay, kalinaw, pasensiya, pagkamaayo, ug pagpugong sa kaugalingon. 
* Ang pagkadiosnon, nga mao ang pagbuhat ug makapasidungog sa Dios, mao kini ang bunga o nagpakita nga ang tawo adunay Balaan nga Espiritu ug nagmasunuron kaniya.

Mga Sugyot sa Paghubad

* Ang mga pulong nga "ang diosnon" pwede hubaron nga, "diosnon nga tawo" o "tawo nga mituman sa Dios."


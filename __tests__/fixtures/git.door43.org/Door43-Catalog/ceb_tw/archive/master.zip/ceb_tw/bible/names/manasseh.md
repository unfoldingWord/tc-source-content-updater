# Manasas

Adunay lima ka tawo nga Manasas ang mga ngalan sa Daang Kasabotan:

* Manasas ang ngalan sa kamaguwangan nga anak ni Jose nga anak ni Jacob.
* Si Manasas ug ang iyang manghod nga si Efraim gisagop sa amahan ni Jose nga si Jacob, ug nahatagan ang ilang mga kaliwat ug pribilehiyo nga maapil sa dose ka tribo sa Israel.
* Usa sa mga tribo sa Israel ang mga kaliwat ni Manasas.
* Ang tribo ni Manasas kasagaran gitawag nga "katunga nga tribo ni Manasas" tungod kay katunga lang tribo ni Manasas ang mipuyo sa Canaan, sa kasadpan nga bahin sa Suba sa Jordan. A ubang bahin sa tribo mipuyo sa sidlakang bahin sa Jordan.
* Ang usa sa mga hari sa Juda Manasas sad ang iyang ngalan.
* Si Haring Manasas dautan kaayo nga hari nga diin ang iyang mga anak iyang gihalad nga sinunog nga halad ngadto sa dili tinuod nga mga dios.
* Gisilotan sa Dios si Haring Manasas pinaagi sa pagpadakop kaniya sa mga kaaway nga mga sundalo. Mibalik sa Dios si Manasas ug iyang giguba ang mga halaran nga diin ang mga dili tinuod nga dios ang gisimba nila.
* May duha pa ka tawo nga Manasas ang ilang mga ngalan sa panahon ni Ezra nga parehas nga nagminyo ug mga langyaw nga asawa. Kini nga mga tawo gisugo nga biyaan nila ang ilang mga asawa tungod sa dautan nga impluwensiya sa ilang mga dili tinuod nga mga dios.
* Aduna pa'y usa ka Manasas nga apohan sa mga liwat ni Dan, mga pari sila sa dili tinuod nga mga dios.


# Cristo, Mesias

Ang pulong nga "Mesias" ug "Cristo" buot ipasabot “Ang Dinihugan" ug nagtumong kang Jesus, nga anak sa Dios.

* Ang "Mesias" ug "Cristo"  parehas nga gigamit sa Bag-ong Kasabotan nga nagtumong sa anak sa Dios, nga gipili sa Dios Amahan nga magmando nga Hari sa iyang katawhan, ug sa pagluwas kanila sa sala ug sa kamatayon.
* Sa Daang Kasabotan, ang mga propeta nagsulat ug mga propisiya mahitungod sa Mesias gatusan ka mga tuig usa siya mianhi sa yuta.
* Kasagaran ang buot ipasabot sa pulong nga "Ang Dinihugan" gigamit sa Daang Kasabotan nga nagtumong sa Mesias nga moabot.
* Daghan niini nga mga propisiya ang natuman ni Jesus ug naghimo Siya ug daghan nga mga milagro nga nagpamatuod nga siya mao ang Mesias; ang uban niini nga mga propisiya matuman sa iyang pagbalik.
* Ang pulong nga "Cristo" kasagaran gigamit nga titulo, sama sa "ang Cristo" ug "Cristo Jesus."
* Ang "Cristo" gigamit sad kauban sa iyang ngalan, sama sa "Jesu Cristo."

Mga Sugyot sa Paghubad:

* Kini nga pulong pwede hubaron gamit ang iyang buot ipasabot, "Ang Dinihugan" o "Dinihugan sa Dios nga manluluwas."
* Daghan nga mga pinulungan migamit sa pulong nga parehas ang pagkasulti sa pulong nga “Cristo" o "Mesias."


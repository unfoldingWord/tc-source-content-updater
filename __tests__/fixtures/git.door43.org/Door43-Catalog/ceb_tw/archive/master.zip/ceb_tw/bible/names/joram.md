# Joram

Si Joram, nailhan sad nga Jehoram nga hari sa Israel, nga anak ni Ahab ug ni Jesabel.

* Naghari si Joram sa parehas nga panahon nga ang lain nga Jehoram naghari sad Juda.
* Dautan nga hari si Joram nga nagsimba sa mga diosdiosan nga maoy hinungdan sa pagkasala sa Israel.


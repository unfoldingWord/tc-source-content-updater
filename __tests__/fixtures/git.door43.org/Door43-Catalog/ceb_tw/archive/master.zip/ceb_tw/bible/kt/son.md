# Anak (nga lalaki)

Ang pulong nga "anak (nga lalaki)" nagtumong sa bata nga lalaki o lalaki nga nagpakita nga siya anak sa iyang mga ginikanan. Pwede kini magtumong sa tinuod o gisagop nga anak nga lalaki.

* Ang mga pulong nga "anak nga lalaki ni" kasagaran gigamit sa Biblia aron magtumong gyud kung kinsa ang tawo nga gihisgutan. Pananglitan sa 1 Mga Hari 4, si "Azarias anak nga lalaki ni Sadok" lahi kang "Azarias nga anak nga lalaki ni Natan." Kining duha ka mga lalaki lahi sad kang "Azarias nga anak nga lalaki ni Amazias" sa 2 Mga Hari 15. Parehas kini sa paggamit ug mga apelido karon nga mga panahon aron mailhan kung kinsa ang gitumong taliwala sa daghang mga tawo nga adunay parehas nga ngalan.
* Kini nga pulong pwede sad gamiton nga matinahuron nga pagtawag sa usa ka lalaki o lalaki nga mas bata.
* Ang "anak nga lalaki" kasagaran gigamit nga sumbingay sa Biblia aron magtumong sa bisan kinsa nga lalaki nga kaliwat, sama sa apo nga lalaki o kaapoapohan nga lalaki.
* Usahay ang mga "anak sa Dios" gigamit nga sumbingay sa Bag-ong Kasabotan aron magtumong sa mga tumutuo kang Cristo.
* Ang uban pang sumbingay gamit ang anak nga lalaki nagpasabot nga "adunay kinaiya nga" sama sa:
* "anak sa kahayag"
* "anak sa masinupakon"
* "anak sa kalinaw"
* "anak sa dalugdog"

Mga Sugyot sa Paghubad:

* Sa kasagarang mga paggawas niini nga pulong, mas maayo nga hubaron ang "anak nga lalaki" gamit ang literal nga pulong sa pinulungan nga hubaron nga nagtumong sa anak nga lalaki.
* Kung hubaron ang pulong nga "Anak sa Dios" kinahanglan gamiton ang kasagaran nga pulong alang sa "anak".
* Kung gamiton sa pagtumong sa mga kaliwat imbes nga anak, ang pulong nga "kaliwat" pwede gamiton, sama sa pagtumong kang Jesus nga "kaliwat ni David" o sa mga talaan sa gigikanan diin usahay ang "anak" nagtumong sa lalaki nga kaliwat.
* Usahay ang "mga anak nga lalaki" pwede hubaron nga "mga anak" kung parehas nga mga lalaki ug mga babaye ang gitumong. Pananglitan, "ang mga anak nga lalaki sa Dios" pwede hubaron nga "mga anak sa Dios" tungod kay kini nga pulong nag-apil sad sa mga batang babaye ug mga babaye.
* Ang sumbingay nga pulong sa "anak sa" pwede hubaron nga "usa ka tawo nga adunay kinaiya nga" o "usa ka tawo nga sama sa" o "usa ka tawo nga adunay" o "usa ka tawo nga naglihok sama nga."


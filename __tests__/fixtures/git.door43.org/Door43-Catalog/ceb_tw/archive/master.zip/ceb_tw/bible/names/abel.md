# Abel

Si Abel mao ang ikaduhang anak nga lalaki ni Adan ug Eva. 

* Usa ka pastol si Abel. 
* Gipahimuot ni Abel ang Dios sa iyang kinabuhi ug mga halad. 
* Gipatay si Abel ni Cain, ang kamagulangang anak nga lalaki ni Adan ug Eva.


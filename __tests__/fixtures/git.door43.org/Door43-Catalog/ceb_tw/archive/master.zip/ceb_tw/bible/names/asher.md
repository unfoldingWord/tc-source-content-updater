# Aser

Si Aser mao ang ikawalo nga anak ni Jacob. Usa siya sa dose nga mga tribu sa Israel kauban ang iyang mga kaliwat. Aser sad ang ngalan ani nga tribu.

* Ang inahan ni Aser mao si Zilpah, ang ulipon ni Leah.
* Ang iyang ngalan nagpasabot nga "malipayon" o, "bulahan."
* Aser sad ang ngalan sa teritoryo nga gihatag sa tribu ni Aser sa dihang ang mga Israelita mipuyo na sa gisaad nga yuta.


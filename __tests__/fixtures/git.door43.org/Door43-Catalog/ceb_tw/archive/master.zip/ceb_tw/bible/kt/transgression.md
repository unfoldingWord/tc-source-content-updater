# milapas, kalapasan

Ang kalapasan usa ka binuhatan sa dili pagtuman sa usa ka sugo, mando o katudloan mahitungod sa matarung nga pagkinabuhi. Ang milapas nagpasabot sa tinuyoan nga pagtalikod sa butang nga gitawag sa Dios nga buhaton sa usa ka tawo.

* Sa mahulagwayong pamaagi ang kalapasan pwede nagtumong sa "pagtabok sa linya," nga mao ang paglapas sa gitakda nga pagasundan alang sa kaayuhan sa tawo ug sa uban.
* Naghisgot ang Biblia mahitungod sa "kalapasan" (pagsupak) "sala" (sayop nga binuhatan) ug "kasal-anan" (pagkadautan). Nagpasabot kini silang tanang sa binuhatan nga sukwahi sa kabubut-on sa Dios ug sa paglapas sa iyang mga kasugoan.

 Mga Sugyot sa Paghubad

* Ang "milapas " pwede hubaron nga "sala" o "pagsupak" o " pagsukol batok sa/kang."
* Sa birsekulo o basahon nga migamit sa "sala" o " milapas o nakalapas" mahinungdanon kung pwede, mogamit ug lain nga paghubad niini nga mga pulong. Kasagaran duha o labaw pa nga pulong nga adunay parehas nga gipasabot ang gamiton aron mapagawas kung unsa ang giingon o aron sa pagpakita sa iyang kamahinungdanon.


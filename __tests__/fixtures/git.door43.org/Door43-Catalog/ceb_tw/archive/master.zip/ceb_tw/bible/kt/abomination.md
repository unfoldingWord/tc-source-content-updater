# kasilag

Ang pulong nga "kasilag" nagtumong sa makahatag ug kapungot o labing kayugot.

* Gitan-aw sa mga taga-Ehipto nga "kasilag" ang mga Hebreo. Nagpasabot kini nga hilabihan ang kayugot sa mga taga-Ehipto ngadto sa mga Hebreo ug dili sila gusto makig-uban o moduol kanila.
* Lakip sa mga butang nga gitawag sa Biblia nga "kasilag kang Yahweh" mao ang mga: pagpamakak, pagpasigarbo, paghalad ug mga tawo, pagsimba ug mga diosdiosan, pagpatay, ug mga lawasnong sala sama sa pagpanapaw ug pagpakighilawas sa isig ka lalaki o babaye.
* Sa pagtudlo ni Jesus sa iyang mga disipulo mahitungod sa kataposan nga panahon, naghisgot si Jesus sa usa ka propesiya ni propetang Daniel mahitungod sa "kasilag sa kalaglagan" nga maoy mahimong pagsupak batok sa Dios nga makapahugaw sa lugar diin siya gisimba.

Mga Sugyot sa Paghubad:

* Ang pulong nga "kasilag" mahimo sad hubaron nga "makasilag nga butang" o "makapungot nga butang" o "makapungot nga mga buluhaton" o "dautan kaayo nga binuhatan."
* Depende sa konteksto, ang "kasilag ngadto kang" mahimong hubaron nga: "makapungot kang" o "dili gyud madawat kang" o "labing ngil-ad kang."
* Mahimong hubaron ang "kasilag sa kalaglagan" nga: "makapahugaw nga butang nga makapalaglag sa mga tawo" o "makapungot nga butang nga makahatag ug dakong kaguol."


# Balaan

Ang mga pulong nga "Balaan" usa ka titulo sa Biblia nga kasagaran nagtumong sa Dios.

* Sa Daang Kasabotan, kini nga titulo apil sa mga pulong nga "Balaan sa Israel."
* Sa Bag-ong Kasabotan, si Jesus ang gitumong nga "Balaan."
* Ang mga pulong nga "balaan" usahay gigamit sa Biblia aron magtumong sa anghel.

Mga Sugyot sa Paghubad:

* Ang literal nga pulong mao ang "Ang Balaan."


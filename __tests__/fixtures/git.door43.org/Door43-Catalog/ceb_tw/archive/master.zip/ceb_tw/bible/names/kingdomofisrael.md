# Gingharian sa Israel

Paghuman namatay ni Solomon, natunga ang Israel sa duha ka mga gingharian. Ang gingharian sa Israel sa amihanan, nga naglakip sa napulo ka mga tribu sa Israel.

* Ang tanang mga hari sa gingharian sa Israel mga dautan. Gidani nila ang mga tawo sa pag-undang sa pagsimba sa Dios sa Templo sa Jerusalem, ug nag-alagad hinuon sa mga diosdiosan ug dili tinuod nga mga dios. Sa kadugayan gipadala sa Dios ang mga taga Asiria aron sa pag-atake kanila ug sa pagkuha sa pipila kanila isip mga binihag.
* Ang mga taga Asiria nagdala ug mga langyaw nga nipuyo uban sa gamay nga mga tawo nga nahabilin sa gingharian sa Israel. Kini nga mga langyaw nakigminyo sa mga Israelita, ug ang ilang mga kaliwat nahimong mga Samaritanong mga tawo.


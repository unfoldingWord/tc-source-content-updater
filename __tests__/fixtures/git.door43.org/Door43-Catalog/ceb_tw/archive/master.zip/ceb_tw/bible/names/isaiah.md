# Isaias

Si Isaias usa ka propeta sa Dios.

* Misulat si Isaias ug daghang mga propesiya mahitungod sa Israel ug kini nga mga propesiya nahitabo samtang buhi pa siya.
* Ilado si Isaias sa iyang gisulat nga propesiya mahitungod sa Mesias nga nahitabo mga 700 ka tuig ang nilabay sa dihang si Jesus naa na diri sa kalibutan.
* Si Jesus ug ang iyang mga disipulo gisulti nila pag-usab ang propesiya ni Isaias aron tudluan ang mga tawo mahitungod sa Mesias.
* Ang libro ni Isaias usa sa mga gitwag nga dako nga libro sa Biblia tungod sa kadaghan nga nahisulat.


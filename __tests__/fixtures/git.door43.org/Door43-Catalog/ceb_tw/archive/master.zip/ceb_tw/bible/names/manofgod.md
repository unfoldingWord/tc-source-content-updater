# tawo sa Dios

Ang sumbingay nga "tawo sa Dios" matinahuron kini nga paagi sa pagtumong sa propeta ni Yahweh.

* Titulo kini sa pagtahod nga gihatag sa daghan nga mga propeta sa Daang Kasabotan.
* Pwede sad kini hubaron nga "tawo nga iya sa Dios" o "tawo nga gipili sa Dios" o "tawo nga nag-alagad sa Dios."


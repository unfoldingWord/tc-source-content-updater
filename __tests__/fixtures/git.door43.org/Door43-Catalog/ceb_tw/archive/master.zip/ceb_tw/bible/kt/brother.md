# Igsoon nga lalaki

Ang pulong nga "igsoon nga lalaki" kasagaran nagtumong sa usa ka lalaki nga parehas ug amahan o inahan sa lain nga tawo.

* Sa Daang Kasabotan, ang pulong nga "mga igsoon nga lalaki" kasagaran gatumong sad sa mga paryente, sama sa membro sa usa ka tribo, banay, o grupo sa mga tawo.
* Sa Bag-ong Kasabotan, ang mga apostoles kasagaran migamit ug "mga igsoon" nga nagtumong sa mga kaubanan nga mga Kristohanon, mga lalaki o mga babaye, kay ang tanan nga mga tumutuo membro sa usa ka espirituhanong pamilya, nga ang Dios ang ilang langitnong Amahan.
* Adunay pipila ka higayon sa Bag-ong Kasabotan nga ang mga apostoles migamit sa pulong nga "igsoon nga bababye" kung kini nagtumong labi na sa kaubanang Kristohanon nga babaye, o aron maghatag ug importasiya nga parehas nga kalakip ang mga lalake ug mga bababye. Pananglitan, si Santiago naghisgot siya sa tanan nga mga tumutuo sa dihang nagtumong siya sa "igsoong lalaki ug babaye nga nanginahanglan ug pagkaon o sinina."

Mga Sugyot sa Paghubad:

* Mas maayo nga hubaron kini sama sa mga pulong nga gigamit adtong ihubad nga pinulungan nga nagtumong sa tinuod nga igsoon, gawas kung maghatag kini ug sayop nga pagsabot.
* Labi na sa Daang Kasabotan kung "mga igsoon" ang gigamit nga kasagaran gatumong sa mga membro sa usa ka pamilya, banay, o grupo sa mga tawo, ang mga posible nga paghubad pwede "mga paryente" o "mga membro sa banay" o "kauban nga mga Israelita."
* Sa konteksto nga nagtumong sa kauban nga tumutuo kang Cristo, kini nga pulong pwede nga hubaron nga, "igsoon kang Cristo" o "espirituhanon nga igsoon."
* Kung ang mga lalaki ug mga babaye ang gitumong ug ang "igsoon" maghatag ug sayop nga pasabot, mahimo nga gamiton ang kasagarang pulong alang sa paryente nga naglakip sa mga lalaki ug mga babaye.  
* Ubang paagi sa paghubad niini aron nga ang pulong magtumong sa lalaki ug babaye nga tumutuo mao ang, "kauban nga mga tumutuo" o "Kristohanon nga mga igsoong lalaki ug mga bababye."
* Siguraduha nga tan-awon pag-ayo ang konteksto aron mahibaw-an kung lalaki lang ba ang gitumong o kauban ang mga lalaki ug mga babaye.


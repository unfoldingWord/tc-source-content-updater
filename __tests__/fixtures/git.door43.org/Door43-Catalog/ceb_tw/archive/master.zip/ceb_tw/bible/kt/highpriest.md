# kinatas-ang pari

Ang pulong nga "kinatas-ang pari" nagtumong sa pinasahi nga pari nga gipili aron mag-alagad sulod sa usa ka tuig ingon nga pangulo sa tanang mga Israelitang pari.

* Ang kinatas-ang pari adunay mga pinasahi nga mga responsibilidad. Siya lang ang gitugutan nga mosulod sa labing balaan nga lugar sa templo aron maghalad ug pinasahi nga sakripisyo kausa sa usa ka tuig.
* Adunay daghang mga pari ang Israel apan usa lang ka kinatas-ang pari sa usa ka kada tuig.
* Niadtong gidakop si Jesus, si Caiapas ang opisyal nga kinatas-ang pari. Gihisgotan sad ang ugangan ni Caiapas nga si Anas tungod kay siya ang kinatas-ang pari sauna, nga tingali aduna pa gihapon siyay gahum ug awtoridad sa mga tawo.

Mga Sugyot sa Paghubad:

* Ang "kinatas-ang pari" pwede hubaron nga "labing gamhanan nga pari" o "pari nga kinatas-an ug ranggo."
* Siguradoha ang paghubad niini nga pulong lahi sa "pangulong pari."


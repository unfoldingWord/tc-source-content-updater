# Hamat, Lebo Hamat

Ang Hamat usa ka importante nga siyudad sa amihanan nga dapit sa Syria, amihanan sa yuta sa Canaan. Ang ngalan sa siyudad karon mao ang Hamah.

* Ang ngalan nga "Lebo Hamat" tingali gikan sa usa ka agianan sa bungtod duol sa siyudad sa Hamat.
* Gihubad sa ubang mga bersyon ang "Lebo Hamat" nga "agianan pasulod sa Hamat."
* Ang mga "Hamatehanon" mga kaliwat sa anak ni Noe nga si Ham ug sa iyang apo nga si Canaan.
* Gipildi ni Haring David ang mga kaaway ni Haring Tou sa Hamat, mao nga maayo ang ilang panaghigala.
* Si Solomon adunay pipila ka mga siyudad diin niya gibutang ang mga gikinahanglanon. Ang Hamat usa niini nga mga siyudad.
* Didto sa yuta sa Hamat gipatay si Haring Zedekias ni Haring Nabucudonosor ug diin nadakpan si Haring Jehoahas sa usa ka Ehiptohanong paraon.


# Elias

Si Elias usa sa ilabihan ka importante nga propeta ni Yaweh. Nagtagna si Elias kaniadtong si Ahab mao ang hari sa amihanang gingharian sa Israel.

* Gibadlong ni Elias si Ahab tungod kay giawhag niya ang mga tawo sa pagsimba sa diosdiosan.
* Gihatag sa Dios ang pagkaon ug puy-anan ni Elias sa milagroso nga mga pamaagi.
* Ang Dios nagbuhat ug daghang milagro pinaagi kang Elias ug gipakita sa Israel nga si Yaweh mao lang ang tinuod nga Dios.
* Gibadlong ni Elias ang 450 ka mga propeta ni Baal ug gipakita niya kanila nga si Baal dili tinuod nga Dios. Tungod sa niining panghitabo, ang mga tawo sa gingharian sa Israel gipatay nila ang mga propeta ni Baal ug sa mobo nga panahon nagsimba sila kang Yaweh.
* Wala namatay si Elias--gidala siya sa langit nga buhi pa. Si Elias ug si Moises nagpakita ug nakig-istorya kang Jesus human nilabay ang gatusang katuig sa dihang  si Jesus nag-andam na nga mamatay sa Jerusalem.


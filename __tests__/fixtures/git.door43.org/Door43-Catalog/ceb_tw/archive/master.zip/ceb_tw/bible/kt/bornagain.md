# natawo ug usab, nahimong anak sa Dios, bag-ong pagkaanak

Ang "natawo ug usab" unang gigamit ni Jesus sa paghulagway kung unsay gipasabot sa pagbag-o sa Dios sa tawo gikan sa espirituhang pagkamatay ngadto sa espirituhang pagkabuhi. Ang pulong nga "nahimong anak sa Dios" o "naianak sa Espiritu" nagtumong sad sa tawo nga nahatagan ug bag-ong kinabuhing espiritwal.

* Ang tanan nga mga tawo naianak nga patay sa espiritwal ug gihatagan ug "bag-ong kinabuhi" kung dawaton nila si Jesu Cristo isip ilang manluluwas.
* Sa panahaon nga ang usa ka tawo naianak sa bag-ong kinabuhing espiritwal, ang Balaang Espiritu sa Dios magsugod ug puyo sa bag-o nga tumutuo ug hatagan niya siya ug gahum aron mamunga ug espiritwal nga bunga sa iyang kinabuhi.
* Buluhaton sa Dios nga maianak ug usab ang usa ka tawo ug mahimong anak niya.

Mga Sugyot sa Paghubad

* Ang ubang pamaagi sa paghubad sa "natawo ug usab" pwede ang "naianak pag-usab" o "natawo sa espirituhanong bahin."
* Maayo nga hubaron kini nga literal ug gamiton ang normal nga pulong nga gigamit sa pinulongan nga "natawo."
* Ang pulong nga "bag-ong pagkaanak" pwede sad hubaron nga "natawo sa espirituhanon bahin."
* Ang mga pulong nga "natawo sa Dios" pwede hubaron nga ang Dios ang hinungdan aron mahatagan ug bag-ong kinabuhi sama sa bag-ong gianak nga bata" o "gihatagan ug bag-ong kinabuhi sa Dios."
* Sa sama nga pamaagi, "natawo sa espirituhanon bahin" pwede hubaron nga, gihatagan ug bag-ong kinabuhi pinaagi sa Balaang Espiritu" o "gihatagan ug gahum pinaagi sa  Balaang Espiritu nga mahimong anak sa Dios" o "Ang Espiritu ang hinungdan nga adunay bag-ong kinabuhi sama sa bag-ong gianak nga bata."


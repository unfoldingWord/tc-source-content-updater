# Rama

Ang Rama usa ka karaan nga siyudad sa Israel nga nahimutang mga 8 ka kilometros amihanan sa Jerusalem didto sa Benjamin duol sa Gibeon.

* Nahimutang ang Rama sa lugar kung diin ang mga kaliwat sa asawa ni Jacob nga si Raquel namuyo.
* Niadtong ang mga Israelita gibihag sa Babilonia, gidala una sila sa Rama usa pa sila miadto sa Babilonia.
* Ang Rama mao ang gipuy-an sa amahan ug inahan ni Samuel.


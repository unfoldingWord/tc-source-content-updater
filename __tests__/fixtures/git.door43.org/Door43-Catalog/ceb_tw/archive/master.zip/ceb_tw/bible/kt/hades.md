# Hades, Sheol

Ang mga pulong nga "Hades" ug "Sheol" gigamit sa Biblia aron magtumong sa kamatayon ug ang mga lugar diin moadto ang mga kalag sa mga tawo inig kamatay. Susama ang mga pasabot nila.

* Ang Hebreohanon nga pulong nga "Sheol" kasagarang gigamit sa Daang Kasabotan aron magtumong sa lugar sa kamatayon.
* Sa Bag-ong Kasabotan, ang Griegong pulong nga "Hades" nagtumong sa lugar alang sa mga kalag sa mga tawo nga misupak sa Dios. Kini nga mga kalag giingon nga "mikanaog" sa Hades. Usahay gitandi kini sa "pagsaka" sa langit, diin nagpuyo ang mga kalag sa mga tawo nga mitoo kang Jesus.
* Ang pulong nga "Hades" gi-uban sa pulong nga "kamatayon" sa libro nga Pinadayag. Sa kataposang panahon, parehas nga ilabay ang kamatayon ug ang Hades ngadto sa Lawa sa Kalayo nga mao ang impiyerno.

Mga Sugyot sa Paghubad:

* Ang pulong sa Daang Kasabotan nga "Sheol" pwede hubaron nga "lugar sa mga patay" o "lugar alang sa mga kalag sa mga patay." Ang ubang mga paghubad hubaron kini siya nga "bung-aw" o "kamatayon," depende sa konteksto.
* Ang ubang mga paghubad gitawag kini nga "ang bung-aw" o migamit ug mas kasagaran nga pulong sama sa "kamatayon."
* Ang pulong sa Bag-ong Kasabotan nga "Hades" mahimong hubaron nga "lugar sa mga kalag sa mga patay nga wala mituo" o "lugar sa pag-antos sa mga patay" o "lugar sa mga kalag sa mga tawong patay nga wala mituo."
* Ang ubang mga paghubad ipabilin ang pulong nga "Sheol" o "Hades" gi-ispeling kini sumala sa paglitok sa pinulongan nga hubaron.


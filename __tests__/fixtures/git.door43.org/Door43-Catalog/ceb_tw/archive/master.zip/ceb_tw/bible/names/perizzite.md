# Perisihanon

Ang Perisihanon grupo sa mga tawo nga nahimamat sa daghang mga higayon sa mga Israelita didto sa Palestina. Kini nga grupo wala nahisgutan kung unsa ang ilang pagkatawo o kung asa dapit sila nagpuyo.

* Kanunay sila nga nahisgutan sa libro nga Maghuhukom diin giingon nga ang mga Perisihanon nakigminyo sa mga Israelita ug maoy nag-impluwensiya kanila nga mag-alagad sa mga dili tinuod nga dios.
* Ang grupo sa mga tawo nga gitawag sa Ingles nga "Perizzies" lahi sa mga Perisihanon. Basin kinahanglan nga ispelingon ang ilang mga ngalan nga lahi gyud aron maklaro.


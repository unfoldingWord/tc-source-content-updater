# Bukid sa mga Olibo

Ang Bukid sa mga Olibo usa ka bukid o dakong bungtod nga makita sa sidlakan nga bahin sa siyudad sa Jerusalem. Tingali ginganlan kini tungod kay napuno kini ug mga kakahoyan sa olibo.

* Sa pipila ka higayon, niadto si Jesus ug iyang mga disipulo sa Bukid sa mga Olibo aron mag-ampo ug magpahulay.
* Gidakop si Jesus didto sa Hardin sa Getsemane, nga anaa sa Bukid sa mga Olibo.
* Pwede sad kini hubaron nga "Bukid sa Kahoy nga Olibo."


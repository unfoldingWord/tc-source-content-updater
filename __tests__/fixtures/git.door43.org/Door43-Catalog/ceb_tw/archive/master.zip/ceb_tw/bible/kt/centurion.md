# senturyon

Ang senturyon usa ka opisyal sa kasundalohan sa Roma nga adunay usa ka gatos ka sundalo nga iyang gimanduan.


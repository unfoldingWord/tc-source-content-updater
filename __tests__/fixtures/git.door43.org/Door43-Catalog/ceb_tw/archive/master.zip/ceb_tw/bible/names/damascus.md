# Damasco

Ang Damasco mao ang kapital nga siyudad sa nasod sa Syria. Anaa gihapon kini sa sama nga dapit nga diin kini sa panahon sa Biblia.

* Ang Damasco usa sa mga labing karaan nga siyudad ug gipuy-an pa gihapon nga mga siyudad sa kalibotan.
* Sa panahon ni Abraham, ang Damasco ang kapital nga siyudad sa gingharian sa Aram (nga anaa sa gitawag karon nga Syria).
* Sa Daang Kasabotan, nahisgotan sa kasaysayan ang mga mahinungdanong pakig-istoryahanay taliwala sa mga nagpuyo sa Damasco ug sa mga katawhan sa Israel.
* Adunay pipila ka mga propesiya sa Biblia nga nagtagna sa pagkalaglag sa Damasco. Natuman na tingali kini nga mga propesiya niadtong gilaglag sa Asyria kini nga siyudad sa panahon sa Daang Kasabotan o tingali aduna pay umaabot nga paglaglag nga mas hingpit.
* Sa Bag-ong Kasabotan, ang Pariseo nga si Saul (kadugayan nailhan nga Pablo) niadto sa siyudad sa Damasco aron dakpon ang mga Kristohanon didto sa siyudad sa Damasco sa dihang giatubang siya ni Jesus ug mao nga nahimo siyang tumutuo.


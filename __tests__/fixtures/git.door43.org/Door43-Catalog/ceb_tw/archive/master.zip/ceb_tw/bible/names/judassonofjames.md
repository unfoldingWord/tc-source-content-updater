# Judas anak ni Santiago

Si Judas anak ni Santiago, usa sa dose nga suod nga disipolo ni Jesus. Timan-i nga siya dili mao si Judas Iscariote.

* Kasagaran sa Biblia, ang mga tawo nga parehas ug ngalan mailhan pinaagi sa paghisgot kung kang kinsa silang anak. Dinhi, si Judas giila nga "anak ni Santiago."
* Ang lain nga Judas igsoon ni Jesus. Nailhan siya nga si "Judas."
* Ang libro sa Bag-ong Kasabotan nga "Judas " tingali gisulat sa igsoon ni Jesus nga si Judas, kay giila niya ang iyang kaugailngon nga "igsoon ni Santiago." Si Santiago igsoon sad ni Jesus.
* Posible sad nga ang libro sa Judas gisulat sa disipolo ni Jesus, nga si Judas nga anak ni Santiago.


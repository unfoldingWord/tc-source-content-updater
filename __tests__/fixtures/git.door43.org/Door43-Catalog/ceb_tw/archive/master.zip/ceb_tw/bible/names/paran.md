# Paran

Ang Disyerto sa Paran mao ang kamingawang dapit sa sidlakan sa Ehipto ug habagatan nga lugar sa Canaan. Aduna sad gitawag nga Bukid sa Paran nga maoy lain ngalan sa Bukid sa Sinai.

* Ang ulipon nga si Hagar ug ang iyang anak nga lalaki nga si Ismael nagpuyo didto sa Disyerto sa Paran pagkahuman nga gimando ni Sarah kang Abraham nga palayason sila.
* Kaniadtong gipanguluhan ni Moises ang mga Israelita gawas sa Ehipto, miagi sila sa Disyerto sa Paran.
* Gikan sa Cades-Barnea didto sa kamingawan sa Paran, gipaadto ni Moises ang dose ka mga lalaki nga maniid sa Canaan ug mobalik aron magsugid.
* Ang kamingwan sa Zin tingali parte sa mas halapad nga Disyerto sa Paran.


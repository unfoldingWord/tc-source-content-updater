# Hitihanon

Ang mga Hitihanon mga kaliwat ni Ham nga gikan sa iyang anak nga lalaki nga si Canaan. Nahimo silang dako nga imperyo  niadto ug kini gitawag karon nga Turkey ug amihanang Palestine.

* Ang mga Hitihanon kasagaran mga hulga sa mga Israelita sa lawasnon ug espirituhanon nga bahin.
* Nipalit si Abraham ug yuta kang Epron nga Hitihanon aron iyang ilubong ang iyang namatay nga asawa nga si Sara sa usa ka langob didto. Kadugayan, didto sad nga langob gilubong si Abraham ug ang pipila niya ka mga kaliwat.
* Nasubo ang mga ginikanan ni Esau niadtong naminyo siya ug duha ka babayeng Hitihanon.
* Usa sa mga isog nga mga manggugubat ni David ginganlan ug Urias nga Hitihanon.
* Uban sa mga langyaw nga puyopuyo ni Solomon mga Hitihanon. Kini nga mga babaye maoy hinungdan nga nalayo ang kasingkasing ni Solomon sa Dios tungod sa ilang pagsimba sa mga diosdiosan.


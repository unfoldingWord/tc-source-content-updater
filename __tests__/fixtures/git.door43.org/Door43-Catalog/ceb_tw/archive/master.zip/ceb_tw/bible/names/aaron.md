# Aaron

Gipili sa Dios si Aaron nga mahimong unang kinatas-ang pari sa katawhan sa Israel. 

* Si Aaron mao ang magulang ni Moises. 
* Gitabangan ni Aaron si Moses nga makigsulti kang Paraon nga pagawason niya ang mga Israelita gikan sa pagka-ulipon sa mga taga-Ehipto. 
* Samtang nagbyahi ang mga Israelita sa disyerto, nakasala si Aaron pinaagi sa paghimo ug diosdiosan aron simbahon sa mga tawo. 
* Gipili sa Dios si Aaron ug iyang mga kaliwat nga mahimong mga pari sa mga katawhan sa Israel.


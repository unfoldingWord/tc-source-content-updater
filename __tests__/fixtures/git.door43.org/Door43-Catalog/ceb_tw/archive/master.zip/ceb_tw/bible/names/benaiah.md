# Benaia

Si Benaia usa ka maunongon nga opisyal ni haring David ug ni haring Solomon.

* Sa dihang nahimo nga hari si Solomon, gitabangan siya ni Benaia sa pagpilde sa iyang mga kaaway.
* Gisugo ni haring Solomon si Benaia nga patyon si Adonias nga nagplano nga moilog sa iyang pagkahari.
* Gisugo sad siya nga patyon angpaangulo sa mgasundalo nga si Joab nga nagplano sad batok kang Solomon.
* Gipili ni Solomon si Benaia nga mopuli kang Joab isip pangulo sa mga sundalo sa Israelita.
* Si Benaia nahimong bantog nga isog ug kusgan sa pakig-away.
* Adunay pipila ka mga tawo sa Daang Kasabotan ang Benaia sad ug ngalan, lakip na ang usa ka pari.


# pamatuod, pagpamatuod

Ang pulong nga "pamatuod" ug "pagpamatuod" nagtumong sa pamahayag mahitungod sa usa ka butang nga tinuod nga nahibal-an sa usa ka tawo. Kasagaran ang usa ka tawo nagpamatuod mahitungod sa usa ka butang nga iyang natagamtaman.

* Ang pulong nga "maghatag ug pamatuod" kasagaran nagtumong sa usa ka saksi sa kaso sa korte nga nagsulti sa kung unsa ang nahitabo.
* Ang saksi nga nag-sulti sa "bakak nga pamatuod" wala nagsulti ug tinuod mahitungod sa kung unsa ang nahitabo.
* Usahay ang pulong nga "pamatuod" nagtumong sa propesiya nga gipahayag sa usa ka propeta.
* Sa Bag-ong Kasabotan, kini nga pulong kasagaran nagtumong kung giunsa gipamatuoran sa mga tumutuo kang Cristo ang mahitungod sa mga nahitabo sa kinabuhi, kamatayon, ug pagkabanhaw ni Jesus. 

Mga Sugyot sa Paghubad:

* Ang pulong nga "pamatuod" o "paghatag ug pamatuod" pwede hubaron nga "isulti ang kamatuoran" o "isulti kung unsa ang nakita ug nadunggan" o "paghatag ug "ebidensiya" o "isulti kung unsa ang nahitabo."
* Ang mga pamaagi sa paghubad sa "pamatuod" pwede nga "pagtaho sa kung unsa ang nahitabo" o "pamahayag sa kung unsa ang tinuod" o "ebidensiya" o "kung unsa ang giingon" o "propesiya."
* Ang mga pulong nga "ingon nga pamatuod kanila" pwede hubaron nga "pagpakita kanila kung unsa ang tinuod" o "aron mapamatud-an kanila kung unsa ang tinuod."
* Ang mga pulong nga "ingon nga pamatuod batok kanila" pwede hubaron nga "maoy magpakita kanila sa ilang mga sala" o "magpakita sa ilang pagpakaaron-ingnon" o "maoy magpamatuod nga sayop sila."
* Ang "pagsulti sa bakak nga pamatuod" pwede hubaron nga "nag-ingon sa bakak nga mga butang mahitungod sa" o "nagpahayag sa mga butang nga dili tinuod mahitungod sa usa ka tawo."
* Kung magtumong sa mga sugo nga nagpamatuod mahitungod sa kasabotan sa Dios, ang "pamatuod" pwede hubaron nga "mga sugo nga nagpamatuod nga si Yahweh mao ang Dios" o "ebidensiya."
* Ang pulong nga "arka sa pamatuod" pwede hubaron nga "arka diin nakabutang ang kasabotan sa mga sugo sa Dios."


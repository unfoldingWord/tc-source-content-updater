# Arabah

Ang pulong nga "Arabah" kasagaran nagtumong sa patag nga disyerto o rehiyon. Kini kasagaran nagtumong sa daku nga disyerto ug kapatagan nga rehiyon apil ang walog nga gapalibot sa Suba sa Jordan, ug paubos sa kayutaan gikan sa habagatan sa tumoy sa gitawag nga Patay nga Dagat hangtod sa amihan sa tumoy sa gitawag nga Pula nga Dagat.

* Ang mga Israelita gilakbay kini nga disyerto sa ilang pagbiyahe gikan sa Ehipto padulong sa yuta sa Canaan.
* Ang "Dagat sa Arabah" kasagaran gitawag nga "Dagat nga asin" o ang "Patay nga dagat."


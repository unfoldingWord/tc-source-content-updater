# Kahadlok, Nahadlok, Kahadlok kang Yahweh

Ang pulong nga "kahadlok" ug "nahadlok" nagtumong sa dili maayo nga gibati sa usa ka tawo sa dihang adunay hulga sa pagpanakit sa iyang kaugalingon o sa uban.

* Ang pulong nga "kahadlok" pwede sad magtumong sa dakong respeto ug dakong pagdayeg sa tawo nga naa sa katungdanan.
* Ang pulong nga "kahadlok kang Yahweh" ug mga pulong nga, "kahadlok ngadto sa Dios" o "kahadlok ngadto sa Ginoo" nagtumong sa dako nga pagrespeto sa Dios ug ipakita kini sa pagtuman Kaniya. Kini nga kahadlok nadasig sa pagkahibalo nga ang Dios balaan ug nagdumot sa sala.
* Ang Biblia nagtudlo nga ang tawo nga adunay kahadlok kang Yahweh mahimo nga maalam.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "pagkahadlok" pwede hubaron nga, "adunay kahadlok" o "adunay dakong respeto" o "pagtahod" o "dakong pagdayeg sa."
* Ang pulong nga "kahadlok" pwede hubaron nga "nalisang" o "nakuyawan" o "adunay kahadlok."
* Ang sumbingay nga "Ang kahadlok sa Dios nahulog kanilang tanan" pwede hubaron nga, "Sa kalit lang silang tanan mibati ug dakong pagdayeg ug pagtahod sa Dios" o "Dihadiha, mibati silang tanan ug kahibulong ug nagtahod gyud sa Dios" o "Diha dayon, mibati silang tanan ug kahadlok sa Dios” o “Niadtong pagkahitabu-a, silang tanan nahadlok dayon sa Diyos."


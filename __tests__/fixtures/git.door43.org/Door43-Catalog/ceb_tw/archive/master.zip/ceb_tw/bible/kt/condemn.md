# silot

Ang pulong nga "silot" nagpasabot sa paghukom sa usa ka tawo tungod sa pagbuhat niya ug sayop.

* Kasagaran, ang pulong nga "silot" nagtumong sa grabe nga paghukom sa usa ka tawo.
* Usahay, ang "silot" nagpasabot sa bakak nga pag-akusar sa usa ka tawo.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, kini nga pulong mahimong hubaron nga "mapintas nga pagkahukom" o "pagsaway nga dili tinuod."
* Ang mga pulong nga "silotan siya" mahimong hubaron nga "pamatud-an nga sad-an siya" o "ipahayag nga kinahanglan silotan siya sa iyang sala."


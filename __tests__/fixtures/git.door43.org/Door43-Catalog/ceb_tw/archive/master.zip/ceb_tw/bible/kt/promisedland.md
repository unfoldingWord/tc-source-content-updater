# Gisaad nga yuta

Ang pulong nga "Gisaad nga Yuta" nahisgutan lang sa mga estorya sa Biblia, apan dili sa mga teksto mismo sa Biblia. Kini ang lain nga pamaagi sa pagtumong sa yuta nga gisaad sa Dios nga ihatag kang Abraham ug iyang mga kaliwat.

* Niadtong nagpuyo pa si Abraham sa siyudad sa Ur, gimandoan siya sa Dios sa pagpuyo sa yuta sa Canaan. Siya ug ang iyang mga kaliwat, ang mga Israelita nagpuyo didto sa daghang mga katuigan.
* Niadtong dihay grabe nga huwaw nga maoy hinungdan nga walay pagkaon didto sa Canaan, mibalhin ang mga Israelita sa Ehipto.
* Paglabay sa upat ka gatos ka tuig, giluwas sa Dios ang mga Israelita gikan sa pagka-ulipon ug gipabalik niya sila sa Canaan pag-usab sa yuta nga gisaad sa Dios nga ihatag kanila.

Mga Sugyot sa Paghubad

* Ang pulong nga "Gisaad" pwede hubaron nga ang "Yuta nga giingon sa Dios nga ihatag kang Abraham" o "ang gisaad nga yuta sa Dios kang Abrahan" o "ang gisaad nga yuta sa Dios sa iyang mga tawo" o "yuta sa Canaan."
* Sa teksto sa Biblia, kini nga pulong nahitabo sa lain nga bahin nga, "ang yuta nga gisaad sa Dios."


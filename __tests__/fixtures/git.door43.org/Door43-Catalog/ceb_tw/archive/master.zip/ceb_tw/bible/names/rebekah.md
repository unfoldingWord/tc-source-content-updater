# Rebeca

Si Rebeca anak nga babaye sa usa sa mga pag-umangkon nga lalaki ni Abraham. Igsoon ni Abraham ang iyang apohan.

* Gipili sa Dios si Rebeca nga mahimong asawa sa anak ni Abraham nga si Isaac.
* Mibiya si Rebeca sa iyang nasod ug mikuyog sa ulipon ni Abraham aron moadto sa nasod ni Isaac, magminyo kang Isaac ug mopuyo didto uban sa iyang pamilya.
* Sa dugay nga panahon wala makaanak si Rebeca, apan sa kadugayan gipanalanginan siya sa Dios ug nanganak siya ug kaluha nga mga lalaki nga mao sila Esau ug Jacob.


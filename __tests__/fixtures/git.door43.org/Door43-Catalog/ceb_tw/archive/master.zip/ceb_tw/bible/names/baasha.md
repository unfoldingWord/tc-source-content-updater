# Baasa

Si Baasa usa sa mga daotan nga hari sa Israel nga nag-impluwensiya sa mga Israelita nga magsimba sa mga diosdiosan.

* Ikatulo nga hari si Baasa sa Israel. Naghari siya sulod sa bente-kuwatro ka tuig sa panahon nga si Asa mao ang hari sa Juda.
* Usa siya nga kumander sa mga militar. Nahimo siyang hari kay iyang gipatay ang nauna nga hari nga si Nahab.
* Sa panahon nga naghari si Baasa, nagsige ug gira ang gingharian sa Israel ug Juda.
* Tungod sa iyang daghang sala batok sa Dios, gitangtang ang iyang katungdanan ug namatay siya.


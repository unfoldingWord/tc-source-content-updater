# Potifar

Si Potifar importante nga opisyal ni Paraon sa Ehipto sa panahon nga si Jacob, ang iyang mga asawa, ug ang iyang mga anak nagpuyo didto sa Canaan. Kapitan si Potifar sa mga gwardiya.

* Gipalit ni Potifar si Jose nga anak ni Jacob nga isip ulipon ug gipili niya nga magdumala sa iyang panimalay.
* Sa dihang si Jose gibutang-butangan ug sayop nga binuhatan, gipapriso ni Potifar si Jose.


# makapanunod, mana, manununod

Ang pulong nga "makapanunod" ug "mana" nagtumong sa pagdawat sa usa ka butang nga adunay bili gikan sa ginikanan o sa ubang mga tawo tungod sa pinsahi nga relasyon sa usa ka tawo. Ang "manununod" usa ka tawo nga nakadawat sa mana.

* Ang mga kalibutanon nga mana nga madawat pwede ang kuwarta, yuta, o uban pang klase nga kabtangan.
* Ang esperituhanon nga mana mao ang tanang gihatag sa Dios sa mga tawo nga nagtuo kang Jesus, apil ang mga panalangin sa karon nga kinabuhi ug sa walay katapusan nga kinabuhi uban kaniya.
* Gitawag sad sa Biblia nga ang mga katawhan sa Dios mao ang iyang mana nga nagpasabot nga sila iya kaniya; sila ang iyang mga bililhon nga kabtangan.
* Ang pulong sa ingles nga "heritage" pareho lang sa "inheritance," apan nagtumong kini sa dili pisikal nga mga panalangin ug mga kinaiya sa usa ka tawo nga nadawat niya gikan sa iyang mga ginikanan o sa Dios. Ang "heritage ug inheritance" parehas lang sa binisaya nga "mana."
* Gisaad sa Dios kang Abraham ug sa iyang mga kaliwat nga makapanunod sila ug yuta sa Canaan, nga mailaa hangtod sa kahangturan.
* Aduna sad sumbingay o sa espirituhanong bahin diin ang mga tawo nga iya sa Dios giingon nga "makapanunod ug yuta." Nagpasabot kini nga magmauswagon sila ug mahimong bulahan pinaagi sa Dios sa pisikal ug espirituhanong bahin.
* Sa Bag-ong Kasabotan, gisaad sa Dios nga ang tanan nga mosalig kang Jesus "makapanunod ug kaluwasan" ug "makapanunod sa kinabuhi nga walay katapusan." Nagpahayag sad kini ug "makapanunod sa gingharian sa Dios." Kini ang espirituhanong mana nga walay katapusan.
* Adunay mga lain pang sumbingay nga pasabot niini nga mga pulong:
* Ang Biblia nag-ingon nga ang maalamon nga tawo "makapanunod ug himaya" ug ang matarong nga tawo "makapanunod sa maayo nga mga butang."
* Ang makapanunod sa mga saad" nagpasabot sa pagdawat ug maayong mga butang nga gisaad sa Dios nga ihatag sa iyang mga katawhan.
* Kini nga pulong gigamit sad sa negatibo nga bahin nga nagtumong sa buang-buang o masupakon nga tawo nga "makapanunod ug hangin" o "makapanunod ug binuang." Kini nagpasabot nga nadawat nila ang sangputanan sa ilang makasasala nga mga buluhaton, lakip ang silot ug walay pulos nga kinabuhi.

Mga Sugyot sa Paghubad:

* Kanunay, tan-awa usa kung aduna nay mga pulong sa ihubad nga pinulungan mahitungod sa manununod o mana ug kadto nga mga pulong mao ang gamiton.
* Depende sa konteksto, ang pulong nga "makapanunod" mahimong hubaron sad nga, "makadawat" o "pagpanag-iya" o "moabot ang pagpanag-iya sa."
* Ang mga pamaagi sa paghubad sa "mana" pwede sad nga, "gisaad nga gasa" o "sigurado nga pagpanag-iya."
* Kung ang katawhan sa Dios gitumong nga iyang mana pwede hubaron kini nga, "ang mga bililhon nga iya sa Dios."
* Ang pulong nga "manununod" pwede hubaron sa pulong o mga pulong nga nagpasabot nga "ang bulahan nga anak nga nakadawat sa pagpanag-iya sa Amahan" o "ang tawo nga napili aron makadawat."


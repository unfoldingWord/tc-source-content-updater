# Goshen

Ang Goshen ngalan sa rehiyon nga makita sa amihanang dapit sa nasod sa Ejipto.

* Kaniadto nga si Jose ang taga-mando sa Ejipto, ang iyang amahan ug mga igsoon ug ang ilang mga pamilya migadto ug mipuyo sa Goshen aron makalingkawas sa gutom sa Canaan.
* Sila ug ang ilang mga kaliwat mipuyo sa Goshen sa sulod sa 400 ka mga tuig ug napugos sa pagkaulipon sa Paraon sa Ejipto.
* Dinhi sa Goshen gitabangan ni Moises ang katawhan sa Israel aron nga makalingkawas sa pang-ulipon sa mga Ejiptohanon.


# Sion , Bukid sa Sion

Ang pulong nga "Sion" o "Bukid sa Sion" nagtumong sa salipdanan o kuta nga nakuha ni Haring David gikan sa mga Jebusites. Nahimutang kini sa usa sa mga bungtod nga nahimutangan sa siyudad sa Jerusalem ug nahimong pinuy-anan ni David.

* Ang Bukid sa Sion ug Bukid sa Moria ang duha ka mga bungtod nga nahimutangan sa siyudad sa Jerusalem. Ang anak ni David nga Solomon nagtukod ug templo sa Dios sa Bukid sa Moria, nga diin gihalad ni Abraham ang iyang anak nga Isaac ngadto sa Dios sa daghang katuigan sa wala pa matukod ang templo.
* Sa kadugayan, ang "Sion" o "Bukid sa Sion" nahimong kinatibuk-ang pulong nga nagtumong niini nga duha nga mga bukid ug sa siyudad sa Jerusalem.
* Ginganlan ni David ang Sion o Jerusalem nga ang "Siyudad ni David." Lahi kini sa yutang natawhan ni David nga mao ang Betlehem, nga gitawag sad ug Siyudad ni David.
* Ang pulong nga "Sion" gigamit sa ubang mga sumbingay nga pamaagi, nga nagtumong sa Israel o ispirtuhanong gingharian sa Dios o sa bag-ong langitnong Jerusalem nga himoon sa Dios.


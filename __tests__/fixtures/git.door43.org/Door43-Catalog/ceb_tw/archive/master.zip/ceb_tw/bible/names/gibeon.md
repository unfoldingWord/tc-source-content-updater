# Gibeon, Gebeohanon

Ang Gebeon siyudad ug rehiyon sa Canaan nga diin nagpuyo ang mga Gibeohanon.

* Ang buot ipasabot sa "Gibeohanon" usa ka tawo nga gikan sa rehiyon nga gitawag nga Gibeon.
* Ang mga Gibeohanon nakadungog kung giunsa sa paglaglag sa mga Israelita ang Jerico, ug nangahadlok sila. Mao nga ang mga Gibeohanon miadto sa mga pangulo sa Israel ug nag-aron-ingnon nga mga tawo nga gikan sa layo nga nasod.
* Ang mga Israelita naghimo ug kasabotan sa mga Gibeohanon ug wala nila sila laglaga.


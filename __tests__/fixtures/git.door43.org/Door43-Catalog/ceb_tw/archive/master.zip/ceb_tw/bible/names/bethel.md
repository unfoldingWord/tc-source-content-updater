# Betel

Ang Betel usa ka siyudad sa panahon ni Abraham nga naa sa amihanan sa Jerusalem sa Canaan. Sa Daang Kasabotan, gawas pa sa Jerusalem nga pirme nahisgutan ang Betel permi sad nga nahisgutan labaw pa sa ubang mga siyudad.

* Si Abram (Abraham) nagpuyo sidlakan sa Betel ug nagtukod ug halaran sa Dios pagkahuman niya nadawat sa unang higayon ang saad sa Dios. Niadto nga panahon dili pa Betel ang ngalan sa lugar, apan sa kadugayan gitawag na kini nga Betel nga mao nay nailhan sa mga tawo.
* Sa iyang paglayas palayo sa iyang igsoon nga si Esau, Si Jacob nagpalagpas ug gabii duol niini nga siyudad ug natulog lang siya sa gawas. Samtang natulog, nagdamgo siya ug mga angel nga gasaka ug gakanaog sa hagdan sa langit. Niadto nga damgo, ang Dios nagsaad kang Jacob ug mga panalangin sama sa iyang gihatag kang Abram (Abrahan). 
* Si Jacob ang nagpangalan niini nga siyudad nga "Betel." Ang iyang ngalan sa una kay Luz. Aron maklaro kini, sa ubang hinubaran gihubad nila nga "Luz (sa kadugayan gitawag kining Bethel)" sa tudling mahitungod kang Abraham, ug sama sad sa unang pag-abot ni Jacob didto (sa wala pa niya giusab ang ngalan).


# milagro, katingahalan, timaan

Ang "milagro" usa ka katingalahang katingalahan nga dili mahitabo gawas kung ang Dios ang maghimo.

* Pipila sa mga milagro nga gihimo ni Jesus mao ang pagpalinaw sa unos ug pag-ayo sa lalaking buta.
* Usahay gitawag ang mga milagro nga "katingalahan" tungod kay ang mga tawo matingala o mahibulong tungod niini.
* Ang pulong nga "katingalahan" pwede sad magtumong sa makahibulong nga pagpakita sa Dios sa iyang gahum, sama sa iyang paglalang sa langit ug sa yuta.
* Gitawag sad ang mga milagro nga mga "timaan" tungod kay gigamit sila nga mga timailhan o ebidensiya nga ang Dios mao ang makagagahom sa tanan nga adunay hingpit nga awtoridad sa tibuok kalibotan.
* Ang ubang mga milagro mao ang mga pagluwas nga gihimo sa Dios, sama niadtong giluwas niya ang mga Israelita sa ilang pagkaulipon didto sa Ehipto ug niadtong iyang gipanalipdan si Daniel aron dili siya pasakitan sa mga leon.
* Ang ubang mga katingalahan sa Dios mao ang mga buhat sa paghukom, sama niadtong nagpadala siya ug lunop sa tibuok kalibutan sa panahon ni Noe ug niadtong nagpadala siya ug makalilisang nga mga katalagman sa Ehipto sa panahon ni Moises.
* Kadaghanan sa mga milagro sa Dios mao ang pisikal nga pagkaayo sa mga tawong masakiton o pagbanhaw sa mga tawo.
* Ang gahum sa Dios gipakita kang Jesus niadtong iyang giayo ang mga tawo sa ilang mga sakit, gipalinaw ang mga unos, nilakaw sa ibabaw sa tubig, ug nagbanhaw ug tawo. Mga milagro kining tanan.
* Gihatagan sad sa Dios ug gahum ang mga propeta ug apostoles nga maghimo ug mga milagro sa pag-ayo ug uban pang mga butang nga mahimo lang pinaagi sa gahum sa Dios.

Mga Sugyot sa Paghubad:

* Ang mga paghubad sa "milagro" o "katingalahan" pwede nga "imposibleng mga butang nga gibuhat sa Dios" o "gamhanang mga buhat sa Dios" o "katingalahang mga buhat sa Dios."
* Ang kasagarang panultihon nga "mga timaan ug mga katingalahan" pwede hubaron nga "mga pamatuod ug mga milagro" o "mga milagrosong binuhatan nga nagpamatuod sa gahum sa Dios" o "katingalahang mga milagro nga nagpakita kung unsa ka makagagahom ang Dios."
* Timan-i nga ang ipasabot sa milagrosong timaan lahi sa timailhan nga nagpamatuod o naghatag ug pamatuod o ebidensiya alang sa usa ka butang. Apan pwede nga duol ang ipasabot niining duha ka pulong.


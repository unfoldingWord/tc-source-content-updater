# Jefta

Si Jefta usa ka manggugubat gikan sa Galaad nga nag-alagad ingon nga maghuhukom, o pangulo sa Israel.

* Sa libro nga Hebreo 11:32, gisaulogan si Jefta ingon nga usa sa mga pangulo nga manluluwas sa iyang mga katawhan.
* Giluwas niya ang mga Israelita gikan sa mga Amonihanon ug gipanguluhan ang iyang mga katawhan aron pildihon ang mga Efraimanhon.
* Apan nagbuhat si Jefta ug binuang ug dinalidali nga panaad sa Dios nga maoy hinungdan nga gihalad niya ang iyang anak nga babaye.


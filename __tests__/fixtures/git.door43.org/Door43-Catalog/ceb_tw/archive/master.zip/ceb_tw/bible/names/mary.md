# Maria

Si Maria inahan ni Jesus ug asawa ni Jose.

* Ang Balaan nga Espiritu milagrosong naghimo ug hinungdan aron mamabdos si Maria dihang birhen pa siya. Ang bata sa iyang tiyan anak kini sa Dios.
* Gikuha ni Jose si Maria isip iyang asawa, apan si Maria nagpabilin nga birhen hangtod sa pagkahuman nga gipanganak ang bata.
* Sa dihang gipanganak na ang bata, gipanganlan ni Maria ug si Jose ang bata nga Jesus.


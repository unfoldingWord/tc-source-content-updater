# Azaraya

Pipila ka lalaki sa Daang Kasabotan adunay ngalan nga Azaraya. Ang pasabot ani, "si Yahweh mitabang."

* Si Azaraya usa sa daghang Israelita gikan sa Juda nga nadakpan sa kasundalohan ni Nabucodonosor ug gidala aron magpuyo sa Babilonia. Mas nailhan siya sa iyang ngalan sa Babilonia nga Abednego.
* Si Azaraya (Abednego) ug ang iyang mga higala nagtuman sa Dios imbes nga magsimba sa hari. Gipakita sa Dios ang iyang gahum ug pagpanalipod pinaagi sa pagluwas kanila gikan sa nagdilaab nga hurno. Gipasidunggan sa Dios kini nga mga batan-on nga lalaki nga Israelita pinaagi sa paghatag sa katungdanan nga mamuno sa gingharian sa Babilonia.
* Azaraya ang lain nga ngalan ni Uzziah nga hari sa Juda.
* Naa sad sa Daang Kasabotan ang pari nga Azaraya ang ngalan.
* Sa panahon ni propeta Jeremias, adunay tawo nga ngalan ug Azaraya nga nag-awhag sa mga tawo nga dili magpuyo sa ilang natawhan nga yuta sa Juda apan ang mando sa Dios kanila adto gyud sila magpuyo didto.


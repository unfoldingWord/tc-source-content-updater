# Babilonia, taga-Babilonia

Ang karaan nga siyudad sa Babilonia mao ang kapital sa Imperyo sa Babilonia. Naa kini sa karaan nga rehiyon sa Babilonia nga karon mao ang nasod nga Iraq.

* Ang Babilonia daplin sa Suba sa Euprates, sa parehas nga rehiyon diin gitukod sa milabay na nga gatuson ka tuig ang Torre sa Babel.
* Usahay ang pulong nga "Babilonia" nagtumong sa tibuok Imperyo sa Babilonia. Pananglitan, ang "hari sa Babilonia" nangulo sa tibuok nga imperyo, dili lamang sa iyang siyudad.
* Ang mga taga-Babilonia gamhanan nga mga tawo nga miatake sa gingharian sa Juda ug gibihag nila sila sa Babilonia sulod sa 70 ka tuig.
* Parte niini nga rehiyon gitawag nga "Caldea" ug ang mga tawo nga nagpuyo didto mao ang mga "Caldehanon." Mao nga kasaagaran ang pulong nga "Caldea" sa Biblia nagtumong sa Babilonia.
* Sa Bag-ong Kasabotan, ang pulong nga "Babilonia" gigamit sa pagkasumbingay ug pagpropesiya mahitungod sa mga lugar, mga tawo, ug mga panghunahuna nga makasasala nga nagsupak batok sa Dios, ug puno sa pagsimba sa diosdiosan.
* Sa libro nga Pinadayag, ang mga pulong nga "Ang Gamhanan nga Babilonia" o " Gamhanan nga siyudad sa Babilonia" gigamit sa pipila nga mga higayon, nagpakita nga kini nga siyudad sumbingay nga nagtumong sa usa ka siyudad  nga daku, datu, ug adunay importansya sa politika.


# Adlaw nga Igpapahulay

Ang Adlaw nga Igpapahulay usa ka pinasahi nga adlaw sa semana nga gisugo sa Dios nga igahin sa mga Israelita ingon nga adlaw sa pagpahulay.

* Ang matag Adlaw nga Igpapahulay mao ang ikapito (katapusan) nga adlaw sa matag semana.
* Pagkahuman ug lalang sa Dios sa kalibutan sulod sa unom ka adlaw, mipahulay siya sa ikapito nga adlaw. Sa sama nga pamaagi, gisugo sad sa Dios ang mga Israelita nga igahin ang ikapito nga adlaw ingon nga pinasahi nga Adlaw nga Igpapahulay ug pagsimba kaniya.
* Alang sa mga Judio, magsugod ang Adlaw nga Igpapahulay sa pagsalop sa adlaw sa Biyernes hangtod sa pagsalop sa adlaw sa Sabado.

Mga Sugyot sa Paghubad

* Pwede sad kini hubaron nga "adlaw sa dili pagtrabaho" o "adlaw sa Dios sa pagpahulay."
* Ang ubang mga paghubad gikapital kini nga mga pulong aron ipakita nga pinasahi kini nga adlaw, pananglitan "Adlaw nga Igpapahulay."
* Hunahunaa kung giunsa paghubad niini nga pulong sa lokal o nasudnong pinulongan.


# balay sa Dios, balay ni Yahweh

Sa Biblia, ang mga pulong nga "balay sa Dios" o "balay ni Yahweh" nagtumong sa lugar diin gisimba ang Dios.

* Kini nga pulong gigamit sad nga nagtumong sa tabernakulo o sa templo.
* Usahay ang "balay sa Dios" gigamit nga nagtumong sa katawhan sa Dios.

Mga Sugyot sa Paghubad:

* Kung magtumong sa lugar sa pagsimba, kini nga pulong pwede hubaron nga, "ang balay diin simbahon ang Dios" o "ang lugar nga simbahon ang Dios."
* Kung magtumong kini sa templo o tabernakulo, pwede kini hubaron nga, "ang templo."


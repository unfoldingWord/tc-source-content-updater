# Amnon

Si Amnon mao ang kamagulangang anak nga lalaki ni Haring David sa iyang asawa nga si Ahinoam.

* Gilugos ni Amnon si Tamar nga iyang igsoon nga babaye sa laing inahan nga igsoon sad ni Absalom.
* Tungod niini, nagplano si Absalom batok kang Amnon ug gipapatay siya.


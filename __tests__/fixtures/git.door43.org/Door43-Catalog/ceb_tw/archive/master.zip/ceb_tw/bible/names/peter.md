# Pedro, Simon Pedro, Cefas

Kini ang lainlaing mga ngalan nga nagtumong kang Pedro nga usa sa mga dose ka mga apostoles ni Jesus. Usa siya nga importante nga pangulo sa nauna nga Iglesia.

* Usa pa siya gitawag ni Jesus nga iyang disipulo, Simon ang ngalan niini nga tawo.
* Kadugayan ginganlan sad siya ni Jesus nga Cefas nga nagpasabot nga "bato" sa aramaic nga pinulungan. Gitawag sad siya nga Pedro, ang ngalan nga nagpasabot sa "bato" sa Griyego nga pinulungan.
* Mas ilado siya sa iyang ngalan nga Pedro ug Simon Pedro.
* Gigamit sa Dios si Pedro pinaagi sa pag-ayo sa mga tawo ug pagwali sa maayong balita mahitungod kang Jesus.
* Duha ka mga libro sa Bag-ong Kasabotan ang mga sulat nga gisulat ni Pedro aron dasigon ug tudluan ang kaubanan nga mga magtutuo.


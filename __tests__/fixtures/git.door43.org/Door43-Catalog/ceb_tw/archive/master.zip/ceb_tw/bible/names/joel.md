# Joel

Joel ang ngalan sa usa ka propeta nga nagsulat sa usa ka libro sa Daang Kasabotan. Ang libro nga Joel usa sa dose nga mubo nga mga libro mahitungod sa mga propisiya nga mga ulahing libro sa Daang Kasabotan.

* Ang personal lang nga impormasyon mahitungod kang propeta Joel mao nga ang ngalan sa iyang amahan mao si Petuel.
* Sa konteksto sa iyang libro, posible nga si Joel nagtagna sa Juda nga anaa sa habagatang dapit sa gingharian sa Israel.
* Dili klaro kung hangtod kanusa si propeta Joel nabuhi ug nagtagna, apan base sa sulod sa iyang libro gihunahuna sa uban nga sa panahon sa paghari ni haring Joas.
* Sa iyang pagwali sa Pentecostes, si apostol Pedro nagkutlo gikan sa libro ni Joel.
* Aduna pay ubang mga tawo sa Biblia nga Joel ang ngalan. Ang ubang pinulongan mas gusto nga mag-espiling sa ilang mga ngalan nga adunay gamay nga kalainan aron nga maklaro nga sila lahi nga mga tawo.


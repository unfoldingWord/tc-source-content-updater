# Ester

Si Ester usa ka Judio nga nahimong rayna sa gingharian sa Persia sa panahon nga ang mga Judio gibihag sa mga taga Babilonia.

* Sa libro nga Ester giistorya kung giunsa nga si Ester nahimo nga rayna ni Ahasuero nga hari sa Persia ug kung giunsa siya paggamit sa Dios sa pagluwas sa iyang mga katawhan.
* Usa ka ilo si Esther, nga gipadako sa iyang diosnong ig-agaw nga si Mordoqueo nga mas tigulang pa sa iya.
* Ang iyang pagsunod sa iyang amahan nga nagsagop kaniya maoy nakatabang sa iyang pagsunod sa Dios.
* Misunod si Ester sa Dios ug gitahan niya ang iyang kinabuhi aron maluwas ang iyang mga katawhan, nga ang mga Judio.
* Ang istorya ni Ester naghulagway sa Dios nga maoy nagkontrolar sa tanang mga panghitabo sa kasaysayan labi na gyud sa iyang pagpanalipod sa iyang katawhan ug sa iyang pagpalihok pinaagi sa mga tawo nga motuman kaniya.


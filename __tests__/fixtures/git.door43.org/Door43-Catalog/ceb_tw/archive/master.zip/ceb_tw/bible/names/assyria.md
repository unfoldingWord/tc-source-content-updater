# Asiria, Imperyo sa Asiria, Asshur

Ang Asiria usa ka gamhanan nga Imperyo sa panahon nga ang mga Israelita nagpuyo sa Canaan.

* Karon nga panahon ang Asiria naa sa dapit amihanan-sentro nga bahin sa Iraq.
* Nakig-away ang mga taga-Asiria batok sa Israel sa nagkalainlaing panahon sa ilang kasaysayan. Kini usa ka paagi sa Dios sa pagsilot sa iyang katawhan nga nagrebelde batok kaniya ug nagsimba sa mga diosdiosan.
* Sa tuig nga 722 sa wala pa gipanganak si Cristo, nasakop tanan sa mga taga-Asiria ang gingharian sa Israel. Napugos ug biya ang mga Israelita ug nibalhin didto sa Asiria.
* Nagdala sad ang mga taga-Asiria ug mga langyaw aron ipaminyo sa mga Israelita nga nahabilin sa Israel. Ginganlan ang mga kaliwat nila nga mga Samaritano.
* Mga kaliwat ni Asshur ang mga katawhan sa Asiria.
* Ang Asshur mao ang kapital sa nasod nga Asiria.


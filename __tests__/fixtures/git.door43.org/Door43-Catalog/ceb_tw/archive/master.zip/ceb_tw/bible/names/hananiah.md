# Ananias

Sa libro sa Daniel, si Ananias usa ka maalamon nga batan-ong Hebreo nga gidala sa Babilonia niadtong panahon sa pagkabinihag. Mas nailhan siya sa ngalan nga Sadrac.

* Si Ananias gihatagan sa mga taga-Babilonia ug katungdanan ingon nga alagad sa gingharian tungod sa iyang kinaiya nga walay ikasaway ug mga abilidad nga hinatag sa Dios.
* Ginganlan pag-usab si Ananias ug Sadrac sa hari sa Babilonia.
* Kuyog ang iyang mga Judiong kauban, gilabay si Sadrac ngadto sa hurno nga nagkalayo tungod kay mibalibad sila sa pagsimba sa hari. Gipakita sa Dios ang iyang gahum pinaagi sa pagpanalipod kanila sa pagkadaut.
* Aduna pay dili kaayo ilado nga mga lalaki nga Ananias ang mga ngalan sa pipila ka mga bersikulo sa Daang Kasabotan.
* Ang usa ka lalaki nga Ananias usa ka dili tinuod nga propeta sa panahon ni propetang Jeremias.


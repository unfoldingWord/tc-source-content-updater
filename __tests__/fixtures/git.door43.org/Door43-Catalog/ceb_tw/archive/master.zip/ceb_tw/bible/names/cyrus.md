# Ciro

Si Ciro usa ka Persianong hari nga nagtukod sa imperyo sa Persia pinaagi sa pagsakop sa mga nalupig nga mga nasod nga gibuntog niya  niadtong mga 550 ka tuig sa wala pa gipanganak si Cristo.

* Gibuntog ni Ciro ang siyudad sa Babilonia mao nga nakagawas ang mga Israelita nga mga binihag didto.
* Gimando ni Ciro nga pwede mopauli ang mga Judio, mao nga ang iyang sumusunod nga si Dario mitugot sad sa pagtukod usab sa templo sa Jerusalem pagkahuman sa pagkabinihag nila.
* Si Ciro mao ang naghari sa panahon nila Daniel, Esdras, ug Nehemias.


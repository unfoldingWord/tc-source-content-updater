# Hilkias

Hilkias ang ngalan sa kinatas-ang pari sa panahon sa paghari ni Haring Josias.

* Niadtong giayo ang templo, nakit-an ni Hilkias ang Basahon sa Balaod ug gisugo niya nga dad-on kini ngadto kang Haring Josias.
* Pagkahuman ug basa sa Libro sa Balaod kang Josias, nasubo siya ug iyang gipasimba ang mga tawo balik kang Yahweh ug gipatuman sa mga balaod sa Dios.
* Ang laing lalaki nga Hilkias mao ang anak ni Eliakim ug nagtrabaho siya sa palasyo sa panahon ni Haring Ezequias.


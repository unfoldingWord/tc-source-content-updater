# Dios nga Amahan, langitnon nga Amahan

Ang pulong nga "Dios nga Amahan" ug "langitnon nga Amahan" nagtumong kang Yahweh, ang nag-inusara nga tinuod nga Dios.

* Ang Dios mao ang Dios Amahan, Dios nga Anak, ug ang Dios nga Balaang Espiritu. Matag-usa kanila bug-os ang pagka-Dios, apan usa ra sila nga Dios. Misteryo kini nga dili kaayo masabtan sa tawo.
* Ang Dios Amahan gipadala ang Dios Anak (Jesus) dinhi sa kalibutan ug gipadala sad niya ang Balaang Espiritu sa iyang katawhan.
* Ang matag-usa nga mituo sa Dios nga Anak mahimong anak sa Dios nga Amahan, ug ang Dios nga Balaang Espiritu mosulod ug mopuyo adto nga tawo.

Lain sad kini nga misteryo nga dili kaayo masabtan sa tawo.

Mga Sugyot sa Paghubad

* Sa mga pulong nga "Dios nga Amahan," maayo nga hubaron kini nga "Amahan" sama sa pulong nga nagtumong sa tawhanon nga amahan.
* Ang pulong nga "langitnong Amahan" pwede hubaron nga "Amahan nga nagpuyo sa langit" o "Amahang Dios nga nagpuyo sa langit" o "Dios nga Amahan nga nagpuyo sa langit."


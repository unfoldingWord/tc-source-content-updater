# gahum

Ang pulong nga "gahum" nagtumong sa abilidad sa pagbuhat o paghimo aron mahitabo ang mga butang, kasagaran gagamit ug dakong kusog ug awtoridad.

* Ang "ang gahum sa Dios" nagtumong sa abilidad niya sa pagbuhat ug mga butang nga imposible nga buhaton sa mga tawo.
* Ang Dios ang kinatas-an nga awtoridad, ug adunay bug-os nga gahum sa tanan nga iyang gilalang. 
* Naghatag ug gahum ang Dios sa iyang mga tawo aron makahimo sa gusto niya, aron kung mag-ayo sila ug mga tawo o magbuhat ug ubang mga milagro, himoon nila kini pinaagi sa gahum sa Dios.
* Tungod kay si Jesus ug ang Balaang Espiritu Dios sad, parehas ang ilang gahum.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pulong nga "gahum" pwede hubaron nga "abilidad" o "kalig-on" o "kusog" o "abilidad sa pagbuhat ug milagro" o "magkontrolar."
* Ang pulong sama sa "luwasa kami gikan sa gahum sa among mga kaaway" pwede hubaron nga, "luwasa kami gikan sa pagdaogdaog sa among mga kaaway" o "luwasa kami gikan sa pagkontrolar sa among mga kaaway." Sa niini nga bahin, "ang gahum" adunay buot ipasabot sa paggamit sa kusog sa usa ka tawo aron iyang pugngan ug daogdaogon ang uban.


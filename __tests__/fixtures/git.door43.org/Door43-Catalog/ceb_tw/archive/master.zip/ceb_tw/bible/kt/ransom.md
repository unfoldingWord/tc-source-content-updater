# tubos

Ang pulong nga "tubos" nagtumong sa gidaghanon sa kwarta o ubang mga bayad nga kinahanglan nga bayaran o bayad alang sa pagpagawas sa usa ka tawo nga binihag.

* Ang "pagtubos" nagpasabot sa paghatag ug bayad o paghimo ug usa ka butang nga adunay pagsakripisyo aron sa pagluwas sa usa ka tawo nga gibihag, giulipon o gipriso. Ang gipasabot sa "pagpalit ug balik" parehas lang ang gipasabot sa "pagtubos."
* Gitogutan ni Jesus nga mamatay ang iyang kaugalingon isip tubos aron makagawas ang makasasala nga mga tawo gikan sa ilang pagkaulipon sa sala. Kini nga buhat sa Dios nga “pagpalit ug balik” sa iyang mga tawo pinaagi sa pagbayad sa silot sa ilang sala gitawag sad ug "katubsanan" sa Biblia.

Mga Sugyot sa Paghubad

* Ang pulong nga "pagtubos" pwede hubaron nga, "pagbayad aron makagawas" o "pagbayad sa prisyo aron makagawas" o "pagpalit ug balik" sa usa ka tawo.
* Ang mga pulong nga "pagbayad sa tubos" pwede hubaron nga "pagbayad sa prisyo."


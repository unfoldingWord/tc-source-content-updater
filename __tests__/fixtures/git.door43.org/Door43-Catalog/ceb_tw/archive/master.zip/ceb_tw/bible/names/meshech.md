# Mesec

Mesec ang ngalan sa usa ka anak nga lalaki ni Japet nga anak nga lalaki ni Noe. Adunay laing tawo nga Mesec ang ngalan nga mao ang apo ni Sem nga anak nga lalaki ni Noe.

* Sama sa ubang ngalan sa tawo sa Biblia, nahimo sad kini nga pulong nga ngalan sa lugar, sama sa Mesec. Tingali kini nga yuta ginganlan sumala sa ngalan sa usa sa mga lalaki nga ginganlan ug Mesec.
* Ang ubang pamaagi sa pagklaro nga kini nga ngalan nagtumong sa lainlaing mga butang, mahimo ang pag-ingon nga (depende sa konteksto) "ang dapit nga gitawag nga Mesec" o "laing lalaki nga gitawag nga Mesec."


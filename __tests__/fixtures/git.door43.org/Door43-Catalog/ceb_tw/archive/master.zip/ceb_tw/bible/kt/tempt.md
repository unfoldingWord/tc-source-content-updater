# pagtintal, tintasyon

Ang pagtintal sa usa ka tawo mao ang pagsulay kaniya aron makabuhat siya ug sayop.

* Ang tintasyon maoy hinungdan nga ang usa ka tawo ganahan nga mobuhat ug sayop.
* Ang mga tawo natintal sa ilang makasal-anong kinaiya ug sa ubang mga tawo.
* Gitintal sad ni Satanas ang mga tawo aron supakon ang Dios ug aron magbuhat ug sala batok sa Dios pinaagi sa pagbuhat sa sayop nga mga butang.
* Gitintal sad ni Satanas si Jesus ug gisulayan siya aron himuon niya ang usa ka butang nga sayop, apan gisuklan ni Jesus ang tanang tintasyon ni Satanas ug wala siya makasala.

Mga Sugyot sa Paghubad

* Ang pulong nga "pagtintal" pwede hubaron nga "sulayan aron makasala" o "maghaylo" o "aron pakasad-on ang usa ka tawo."
* Ang paghubad sa pulong nga "pagtintal" pwede sad nagpasabot nga "gisulayan."
* Ang mga pamaagi sa paghubad sa "tintasyon" pwede nga "mga butang nga makapatintal" o "mga butang nga maghaylo sa usa ka tawo aron makasala" o "mga butang nga magtinguha sa pagbuhat sa usa ka butang nga sayop."


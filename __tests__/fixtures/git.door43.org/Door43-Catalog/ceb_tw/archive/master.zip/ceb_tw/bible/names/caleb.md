# Caleb

Usa si Caleb sa dose nga mga Israelitang espiya nga gipadala ni Moises aron susihon ang yuta nga Canaan.

* Siya ug si Josue mibalik gikan sa pagsusi sa Canaan ug giingnan nila ang mga tawo nga mosalig sa Dios nga motabang kanila sa pagpildi sa ilang mga kaaway, aron makapanginabuhi sila nga may kalinaw didto nga lugar.
* Si Josue ug si Caleb lang gyud sa ilang mga kaliwat ang gitugutan nga makasulod sa Gisaad nga Yuta nga Canaan.


# Gaza

Sa kapanahon sa Biblia, ang Gaza importante nga siyudad sa Filistina nga makita sa baybayon sa Dagat sa Mediteraneo, mga 77 kilometro habagatang-kasadpan sa Jerusalem ug 38 kilometro habagatan sa Ashdod.

* Sa adtong una pa kaayong panahon, ang Gaza mao ang agianan sa mga kasundalohan ug mga negosyante sa taliwala sa Asya ug Ehipto.
* Karon, ang siyudad nga Gaza importante gihapon nga pantalan sa giingon nga "Gaza strip", nga usa ka rehiyon nga makit-an sa baybayon sa Dagat sa Mediteraneo nga giutlanan sa Israel sa amihanan ug sa sidlakan ug sa Ehipto sa habagatan.
* Didto sa siyudad nga Gaza gidala si Samson sa mga Filistihanon niadtong gidakop nila siya.
* Si Felipe nga ebanghelista naglakaw sa awaaw nga dalan sa Gaza niadtong natagbuan niya ang eunocos nga taga Etiopia.


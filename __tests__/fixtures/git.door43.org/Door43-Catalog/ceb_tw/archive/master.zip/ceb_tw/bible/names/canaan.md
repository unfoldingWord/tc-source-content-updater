# Canaan, taga Canaan

Si Canaan anak ni Ham nga anak nga lalaki ni Noe. Iyang mga kaliwat ang mga taga Canaan, mga pipila ka grupo sa mga tawo nga nipuyo sa lugar gikan sa kapatagan sa suba sa Jordan ngadto sa Dagat sa Mediteraneo. Kini nga lugar nailhan nga Yuta sa Canaan.

* Gisaad sa Dios kini nga lugar nga ihatag kang Abraham ug sa iyang mga kaliwat, nga ang mga Israelita.
* Sa panahon karon ang mga nasod ug mga teritoryo niini nga lugar mao ang Israel, Lebanon, parte sa Jordan, parte sa Syria, ug Palestina.


# Jotam

Sa Daang Kasabotan, adunay tulo ka mga tawo nga Jotam ug mga ngalan.

* Ang usa ka Jotam kamanghurang anak ni Gideon. Mitabang si Jotam sa pagpilde sa iyang kamagulangang igsoon nga si Abimelek, nga maluibong nagpatay sa tanan niyang mga igsoon.
* Ang usa pa ka Jotam hari sa Juda sulod sa napulo ug unom ka mga tuig paghuman nga namatay ang iyang amahan nga si Uzzia (nga nailhan sad nga Azaria).
* Sama sa iyang amahan, Si Haring Jotam misunod sa Dios ug maayo siya nga hari.
* Apan, sama sad sa iyang amahan, wala gitangtang ni Haring Jotam ang lugar sa pagsimba sa diosdiosan ug kini ang hinungdan nga ang mga tawo mitalikod sa Dios pag-usab.
* Ang usa pa ka resulta sa pagsimba ug diosdiosan mao nga ang anak ni Jotam nga si Ahas nahimong dautan nga hari.
* Usa si Jotam sa katigulangan nga nahisulat sa kagikanan ni Jesu Cristo sa libro ni Mateo.


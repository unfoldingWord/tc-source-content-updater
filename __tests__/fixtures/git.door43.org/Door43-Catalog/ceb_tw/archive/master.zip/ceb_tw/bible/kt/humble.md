# mapainubsanon, pagpaubos

Ang mapahinubsanon nga tawo wala naghunahuna sa iyang kaugalingon nga mas labaw pa siya sa uban. Dili siya mapahitas-on.

* Ang pagpahiubos atubang sa Dios nagpasabot sa pagdawat sa atong pagkaluya ug pagkadili hingpit kompara sa iyang kagamhanan, kaalam, ug kahingpitan.
* Kung ang usa ka tawo magpahiubos sa iyang kaugalingon, giisip niya ang iyang kaugalingon nga naa sa estado diin gamay lang ang iyang importansiya.
* Ang paghunahuna sa kinahanglanon sa uban usa pa sa kaugalingong kinahanglanon mao ang pagpaubos.
* Kung gamiton ang mga gasa ug mga abilidad sa usa ka tawo, ang pagpaubos nagpasabot sad sa pag-alagad nga adunay kaligdong nga kinaiya.
* Ang pulong nga "mapahinubsanon" pwede hubaron nga "dili magpasigarbo."
* Ang "ipaubos ang kaugalingon sa Dios" pwede hubaron nga, " Itugyan ang imong kabubut-on sa Dios nga adunay pag-ila sa iyang kagamhanan."


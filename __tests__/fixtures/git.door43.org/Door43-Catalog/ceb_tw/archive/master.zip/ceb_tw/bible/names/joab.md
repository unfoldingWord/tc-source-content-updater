# Joab

Si Joab usa ka importante nga pangulo sa mga sundalo ni haring David sa tibuok niyang paghari.

* Sa wala pa nahimo nga hari si David, maunungon na nga sumusunod si Joab kang David.

 Sa kadugayon, sa paghari ni David sa Israel, nahimo nga pangulo si Joab sa mga sundalo ni David.
* Ang inahan ni Joab, si Zeruiah, nga usa sa mga igsoon ni haring David. Mao nga si Joab pag-umangkon ni David.
* Kaniadtong ang anak ni David nga si Absalom nagtraydor kaniya pinaagi sa pagsulay sa pagkuha sa iyang pagkahari, gipatay ni Joab si Absalom aron mapanalipdan ang hari.
* Agresibo kaayo nga manggugubat si Joab ug daghan ang iyang napatay nga mga kaaway sa Israel.


# maayong balita, ebanghelyo

Ang pulong nga "ebanghelyo" literal nga buot ipasabot "maayong balita" ug nagtumong sa mensahe o pagpahibalo sa mga tawo mahitungod sa usa ka butang nga kaayohan ug magpalipay kanila. 

* Sa Biblia, kini nga pulong kasagaran nagtumong sa mensahe sa Dios mahitungod sa kaluwasan sa mga tawo pinaagi sa sakripisyo ni Jesus sa krus.
* Kadaghanan sa mga Englis nga mga Biblia, "maayong balita" ang kasagarang hubad sa "ebenghelyo" ug gigamit sad sa mga pulong nga sama sa "ebanghelyo ni Jesu Cristo," ang "ebanghelyo sa Dios" ug ang "ebenghelyo sa gingharian."

Mga Sugyot sa paghubad

* Lainlain nga paagi sa paghubad niini nga pulong pwede sad ang "maayong mensahe" o "maayo nga pagpahibalo" o "mensahe sa kaluwasan sa Dios" o "ang maayong butang nga gitudlo sa Dios mahitungod kang Jesus."
* Depende sa konteksto, mga paagi sa paghubad niini nga mga pulong, "maayong balita sa" pwede sad ang "maayong balita/mensahe mahitungod sa" o "maayong balita gikan sa" o "ang maayong mga butang nga giingon kanato mahitungod sa" o "unsa ang giingon sa Dios mahitungod sa iyang pagluwas sa mga tawo."


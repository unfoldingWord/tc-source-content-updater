# Median, Mediahanon

Ang Median usa ka grupo sa katawhan nga nagpuyo sa amihanan nga dapit sa Disyerto sa Arabia hangtod sa habagatan sa yuta sa Canaan. Kining mga tawhana gitawag nga mga "Mediahanon."

* Ang mga Median nabuhi niadtong ika-19 hangtod ika-11 ka siglo sa wala pa gipanganak si Cristo.
* Si Jose gidala ngadto sa Ehipto sa mga Mediahanon nga tigbaligya ug mga ulipon.
* Paglabay sa daghang mga tuig, gisulong ug gi-asdangan sa mga Mediahanon ang mga Israelita didto sa Canaan. Gipangulohan ni Gideon ang mga Israelita sa pagpildi kanila.
* Kadaghanan sa mga tribo nga Arabo karon kaliwat sa mga Mediahanon.


# Noe

Si Noe mao ang tawo nga nabuhi labaw sa 4,000 ka tuig na ang nilabay, sa panahon nga gilunop sa Dios ang tibuok kalibotan aron laglagon ang tanang daotan nga mga tawo sa kalibotan. Giingnan sa Dios si Noe nga magbuhat ug daku kaayo nga barko diin siya ug ang iyang pamilya magpuyo samtang aduna pay daku nga tubig nga nagtabon sa kayutaan.

* Si Noe usa ka matarung nga tawo nga nagtuman sa Dios sa tanan.
* Kaniadtong giingon sa Dios kang Noe kung unsaon niya pagtukod sa daku kaayo nga barko, gituman gyud niya ang sakto nga pamaagi nga gimando kaniya sa Dios.
* Sulod sa barko si Noe ug ang iyang pamilya naluwas ug kadugayan midaghan ug pag-usab ang mga tawo sa yuta pinaagi sa ilang mga anak ug mga apo.
* Ang tanan nga natawo pagkahuman sa lunop gitawag nga mga kaliwat sa pamilya ni Noe.


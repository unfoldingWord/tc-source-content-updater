# Hamor

Si Hamor usa ka dili Judio nga silingan ni Jacob.

* Pagkahuman ug balik ni Jacob sa iyang yutang gigikanan uban ang iyang mga asawa ug anak, nipalit siya ug yuta gikan sa mga anak ni Hamor aron mahimong lubnganan sa iyang pamilya.
* Gilugos sa anak ni Hamor nga si Secem ang anak nga babaye ni Jacob nga si Dina; nanimalos ang mga igsoon ni Dina kang Hamor ug sa iyang pamilya.


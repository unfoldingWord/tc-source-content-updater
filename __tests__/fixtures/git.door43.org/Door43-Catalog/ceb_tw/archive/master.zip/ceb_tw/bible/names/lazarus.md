# Lazaro

Si Lazaro higala ni Jesus ug gibanhaw niya kini gikan sa patay.

* Si Lazaro adunay duha ka igsoon nga mga babaye, si Maria ug si Marta, nga mituo sad kang Jesus.
* Pagkahuman sa pagbanhaw ni Jesus kang Lazaro, nasuko ang mga pangulo sa mga Judio ug nangita sila ug paagi aron patyon silang duha.


# Berea

Sa panahon sa Bag-ong Kasabotan, ang Berea (o Beroea) mauswagon nga siyudad sa habagatang sidlakan sa Masedonia, nga mga 50 milyas habagatan sa Tesalonica. Mao kini karon ang moderno nga Griego nga siyudad nga Verria.

* Si Pablo ug si Silas miikyas sa siyudad sa Berea pagkahuman nga gitabangan sila sa ilang mga kaubanan sa pagtuo sa pag-ikyas gikan sa mga Judio sa Tesalonica nga supak kanila.
* Sa dihang ang mga tawo nga nagpuyo sa Berea nakadungog kang Pablo nga nagwali, gisusi nila ang Kasulatan aron sa pagmatuod kung ang iyang giingon kanila tinuod.


# pagpasig-uli

Ang pulong nga "pagpasig-uli" nagtumong sa sakripisyo nga gihimo aron matagbaw o matuman sa hustisya sa Dios ug aron mohupay ang iyang kapungot.

* Ang paghalad sa sakripisyo nga dugo ni Jesu Cristo mao ang pagpasig-uli sa Dios alang sa mga sala sa katawhan.
* Ang pagkamatay ni Jesus sa krus nagtagbaw sa kapungot sa Dios batok sa sala. Naghatag kini ug pamaagi aron ang Dios motan-aw sa mga tawo nga adunay pabor ug magtanyag kanila sa kinabuhing walay katapusan.

Mga Sugyot sa Paghubad

* Kini nga pulong pwede hubaron nga "pagkatagbaw" o "hinungdan sa pagpasaylo sa Dios sa mga sala ug paghatag ug pabor sa mga tawo."
* Ang pulong nga "pagtabon sa sala" doul sa pasabot sa "pagpasig-uli."  Importante nga itandi kung giunsa paggamit kining duha ka mga pulong.


# Dili tinuod nga dios, dios sa mga langyaw, dios, diosa

Ang dili tinuod nga dios usa ka butang nga gisimba sa mga tawo imbis simbahon ang tinuod nga Dios. Ang pulong nga "diosa" nagtumong sa babaye nga dili tinuod nga dios.

* Dili tinuod kining mga diosdiosan. Si Yahweh ra gyud ang tinuod nga Dios.
* Usahay ang mga tawo maghimo ug mga butang nga simbolo sa mga diosdiosan nga simbahon sa mga tawo.
* Sa Biblia, ang mga tawo sa Dios kasagaran mitalikod sa pagsunod kaniya aron mosimba sa mga dili tinuod nga dios.
* Ang mga demonyo kasagaran naglinlang sa mga tawo sa pagtuo nga kining mga dili tinuod nga dios o diosdiosan nga ilang gisimba adunay gahum.
* Si Baal, Dagon, ug si Molek tulo sa mga daghang mga dili tinuod nga dios nga gisimba sa mga tawo sa panahon sa Biblia.
* Si Asera ug Artemis (Diana) duha ka mga diosa nga gisimba sa mga tawo niadtong una pa kaayong panahon. 

Mga Sugyot sa paghubad

* Aduna siguroy pulong sa "diosdiosan" o "dili tinuod nga dios" sa pinulongan nga hubaron o sa duol niya nga pinulongan.
* Ang pulong nga "diosdiosan" pwede gamiton sa pagtumong sa dili tinuod nga dios.
* Sa Ingles, ang gamay nga "d" gigamit aron magtumong sa dili tinuod nga dios ug ang dako nga "D" gigamit nga nagtumong sa tinuod nga Dios. Mao kini ang gibuhat sa ubang manghuhubad.
* Ang laing kapilian mao ang paggamit ug lahi gyud nga pulong sa pagtumong sa dili tinuod nga dios.
* Ang ubang mga pinulongan mahimong magdugang ug pulong aron magtumong kung lalaki o babaye ang gihulagway nga dili tinuod nga dios.


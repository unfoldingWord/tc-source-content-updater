# pagbalaan

Ang pagbalaan nagpasabot sa paggahin sa usa ka butang o tawo aron mag-alagad sa Dios. Ang tawo o butang nga gibalaan giisip nga balaan ug gigahin alang sa Dios.

* Ang pasabot niini nga pulong sama sa "pagputli" o "pagbalaan" apan aduna kini nga dugang nga pasabot nga pormal nga paggahin sa usa ka tawo alang sa pag-alagad sa Dios.
* Ang mga butang nga gibalaan sa Dios naglakip sa mga mananap nga isakripisyo, ang halaran sa sinunog nga halad, ug ang tabernakulo.
* Ang mga tawo nga gibalaan sa Dios naglakip sa mga pari, ang katawhan sa Israel, ug ang kamagulangang anak nga lalaki.
* Usahay, ang pulong nga "pagbalaan" adunay pasabot nga sama sa "pagputli," hilabi na kung nagtumong kini sa pag-andam sa mga tawo o mga butang alang sa pag-alagad sa Dios aron sila mahinloan ug madawat niya.

Mga Sugyot sa Paghubad:

* Ang mga pamaagi sa paghubad sa "pagbalaan" pwede nga "paggahin alang sa pag-alagad sa Dios" o "pagputli alang sa pag-alagad sa Dios."
* Hunahunaa sad kung giunsa paghubad ang mga pulong nga "balaan" ug "pagputli."


# kapungot

Ang “kapungot” mao ang hilabihan nga kasuko nga usahay nga magpabilin ug dugay. Nagtumong kini hilabi na sa matarong nga paghukom sa Dios sa sala ug pagsilot sa mga tawo nga mosupak batok kaniya.

* Sa Biblia, ang "kapungot" kasagaran nagtumong sa kasuko sa Dios ngadto sa mga nakasala batok kaniya.
* Ang "kapungot sa Dios" pwede sad magtumong sa iyang paghukom ug pagsilot adtong nakasala.
* Ang kapungot sa Dios mao ang matarong nga silot sa mga dili maghinulsol sa ilang sala.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang ubang pamaagi sa paghubad niini nga pulong mao ang "hilabihang kasuko" o "matarong nga paghukom" o "kasuko."
* Kung mahitungod sa kasuko sa Dios, siguraduha nga ang pulong gamiton dili magtumong sa makasasala nga kasuko. Ang kasuko sa Dios matarung ug balaan.
* Ang uban nga paagi sa paghubad mao ang  pagpabilin sa "naisulat na" ug himoan nalang ug mubo nga sulat aron sa pagpatin-aw niini nga pagpasabot.


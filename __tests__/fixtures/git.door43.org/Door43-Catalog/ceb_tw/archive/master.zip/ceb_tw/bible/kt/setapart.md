# gigahin

Ang pulong nga "gigahin" nagpasabot sa pagkabulag gikan sa usa ka butang aron matuman ang usa ka tumong.

* Ang mga Israelita gigahin alang sa pag-alagad sa Dios.
* Ang Balaang Espiritu nagmando sa mga Kristohanon sa Antioquia nga igahin si Pablo ug Barnabas alang sa buluhaton nga gusto sa Dios nga ipabuhat kanila.
* Ang tumutuo nga "gigahin" sa pag-alagad sa Dios mao ang "gipahinungod" sa pagtuman sa kabubut-on sa Dios.
* Ang usa ka pasabot sa pulong nga "balaan" mao ang igahin ingon nga iya sa Dios ug pagkabulag sa mga makasasala nga pamaagi sa kalibutan.
* Ang pulong nga "pagkabalaan" nagpasabot sa paggahin sa usa ka tawo alang sa pag-alagad sa Dios.

Mga Sugyot sa Paghubad:

* Ang mga pamaagi sa paghubad sa "paggahin" pwede ang "pinasahi nga pagpili" o "ibulag gikan kaninyo" o "ilain alang sa pinasahi nga tahas."
* Ang "gigahin" pwede hubaron nga "ibulag."


# Nazaret

Ang Nazaret usa ka lungsod sa rehiyon sa Galilea sa amihanang Israel.

* Sila Jose ug Maria gikan sa Nazaret ug didto nila gipadako si Jesus.
* Daghan sa mga tawo sa Nazaret wala nitahod sa katudluan ni Jesus tungod kay nagdako si Jesus uban kanila ug gihunahuna nila nga ordinaryo lang siya nga tawo.
* Gisulayan sa mga tawo sa Nazaret nga patyon si Jesus niadtong giangkon niya nga siya ang Mesiyas.


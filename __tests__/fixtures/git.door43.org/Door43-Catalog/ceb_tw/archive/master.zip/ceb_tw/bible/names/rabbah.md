# Raba

Usa ka importante nga siyudad ang Raba sa mga Amonihanon.

* Kasagarang gisulong ang Raba sa panahon sa gubat batok sa mga Amonihanon.
* Ang Hari sa Israel nga si David nagbihag sa Raba nga usa sa ulahi niyang mga pagbuntog.
* Ang modernong siyudad karon nga Amman Jordan ang Raba kaniadto.


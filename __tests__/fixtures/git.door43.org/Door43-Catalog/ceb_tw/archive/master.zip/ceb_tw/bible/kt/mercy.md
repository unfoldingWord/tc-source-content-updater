# kaluoy, maluluy-on

Ang mga pulong nga "kaluoy" ug "maluluy-on" nagtumong sa pagtabang sa mga tawo nga nanginahanglan labi na kung kabos o ubos ang ilang kahimtang.

* Ang pulong nga "kaluoy" mahimong magpasabot nga dili silotan ang mga tawo sa sayop nga gibuhat nila.
* Ang gamhanang tawo sama sa hari gihulagway nga "maluluy-on" kung maayo ang iyang pagtratar sa mga tawo imbes nga dauton sila.
* Ang pagkamaluluy-on nagpasabot sad sa pagpasaylo sa usa ka tawo nga nakabuhat ug sayop batok kanato.
* Magpakita kita ug kaluoy kung tabangan nato ang mga tawo nga adunay dakong panginahanglan.
* Maluluy-on ang Dios kanato ug gusto niya nga magmaluluy-on sad kita sa uban.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang "kaluoy" pwede hubaron nga "pagkamaayo" o "pagkamaluluy-on kaayo."
* Ang pulong nga "maluluy-on" pwede hubaron nga "nagpakita ug kaluoy" o "pagkamaayo kang" o "pagpasaylo."
* Ang "pagpakita ug kaluoy kang" o "maluoy kang" pwede hubaron nga "trataron ug maayo" o "magmaluluy-on kaayo kang."


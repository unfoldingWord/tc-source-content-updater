# Pariseo

Ang mga Pariseo mao ang importante nga mga grupo sa Israelita nga mga pangulo sa ilang relihiyon sa panahon ni Jesus. Kadaghanan kanila mao ang mga dili kaayo dato nga mga negosyante ug ang uban kanila mga pari.

* Sa tanang nangulo sa mga Judio, ang mga Pariseo ang hilabihan ka estrikto mahitungod sa pagtuman sa mga balaod ni Moises ug ang uban pang mga balaod ug tradisyon sa mga Judio.
* Nabalaka sila pag-ayo mahitungod sa paglahi sa mga katawhan sa Judio aron dili sila maimpluwensiya sa mga Gentil nga nagpalibot kanila. Sa kamatuoran ang ngalan nga "Pariseo" gikan sa pulong nga "lainon."
* Ang mga Pariseo mituo sa kinabuhi human ang kamatayon; mituo sad sila sa mga anghel ug ang uban pang espirituhanong linalang.
* Ang mga Pariseo ug ang mga Saducio (apil ang kinatas-ang mga pare) kanunay nga nagsupak kang Jesus ug sa mga nauna nga mga Kristohanon.


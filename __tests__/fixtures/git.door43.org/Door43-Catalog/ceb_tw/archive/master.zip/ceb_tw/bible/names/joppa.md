# Jope

Sa panahon sa Biblia, ang siyudad sa Jope importante nga puwerto nga naa sa dagat sa Mediterranian, nga 30 ka milyas amihanang-kasadpan sa Jerusalem.

* Ang karaan nga lugar sa Jope gitawag na karon nga siyudad sa Jafa nga karon parti na sa siyudad sa Tel Aviv.
* Sa Daang Kasabotan, ang siyudad sa Jope mao ang giadtuan ni Jonas sa pagsakay niya ug barko paingon sa Tarsis.
* Sa Bag-ong Kasabotan, sa Jope gibuhi pag-usab ni Pedro ang babayeng kristuhanon nga si Tabita.


# Pagpangamuyo

Ang pulong nga "pagpangamuyo" nagtumong sa paghangyo sa usa ka tawo alang sa ubang tawo. Sa Biblia kasagaran nagtumong kini sa pag-ampo alang sa ubang tawo.

* Ang "pagpangamuyo" nagpasabot sa paghangyo sa Dios alang sa kaayohan sa ubang tawo.
* Ang Biblia nagtudlo nga ang Balaang Espiritu mao ang tigpangamuyo kanato, nag-ampo siya sa Dios alang kanato.
* Ang usa ka tawo nangamuyo alang sa ubang tawo pinaagi sa paghangyo ngadto sa usa ka tawo nga adunay awtoridad.

Mga Sugyot sa Paghubad:

* Ang ubang pamaagi sa paghubad sa "pagpangamuyo" mao ang "paghangyo alang" o "pag-awhag."


# Josias

Usa ka diosnon nga hari si Josias nga naghari sa gingharian sa Juda sa sulod sa katluan ug usa ka tuig. Naghimo siya ug daghang mga butang sa pagdasig sa mga tawo sa Juda sa paghinulsol ug sa pagsimba kang Yaweh.

* Paghuman nga napatay ang iyang amahan nga si Haring Amon, si Josias nahimo nga hari sa Juda sa edad nga otso anyos.
* Sa ika-napulo ug walo sa iyang paghari, gimanduan ni Haring Josias si Hilkiah nga kinatas-ang pari sa pagtukod pag-usab sa templo sa Ginoo. Samtang gibuhat kini, nakaplagan ang mga libro sa Balaod.
* Sa dihang ang mga libro sa Balaod gibasa kang Josias, naguol siya nga ang iyang mga tawo wala mituman sa Dios. Gimando niya nga ang tanang mga lugar sa pagsimba sa diosdiosan gubaon ug ang mga pari sa dili tinuod nga dios pamatyon.
* Gimanduan sad niya ang mga tawo sa pagsaulog sa Kasaulugan sa Pagsaylo pag-usab.


# mga binuhatan, mga gihimo, mga buhat

Sa Biblia, ang mga pulong nga "mga binuhatan," "mga gihimo" ug "mga buhat" gigamit nga nagtumong sa mga butang nga gihimo sa Dios ug sa mga tawo.

* Ang pulong nga "trabaho" nagtumong sa paghago o unsa man nga butang nga nahimo sa pag-alagad sa mga tawo.
* Ang "mga buhat" sa Dios ug ang "mga buhat sa iyang mga kamot" sumbingay kini nga nagtumong sa tanan nga mga butang nga iyang gihimo o nahimo na, lakip ang paglalang sa kalibutan, pagluwas sa mga makakasala, paghatag sa mga kinahanglanon sa tanang nilalang ug pagtipig sa kinatibuk-an sa kalibutan. Ang mga pulong nga "mga hinimoan" ug "mga buhat" gigamit sad nga nagtumong sa mga milagro sa Dios sa pagpahayag sa "gamhanong mga buhat" o "kahibulungang mga himo."
* Ang buhat o mga gihimo sa mga tawo pwede kini maayo o dautan.
* Gihatagan ug gahum sa Balaang Espiritu ang mga tumutuo sa paghimo ug maayong mga buhat, nga gitawag sad nga "maayong bunga."
* Ang mga tawo wala maluwas tungod sa maayo nila nga mga binuhatan; naluwas sila pinaagi sa pagtuo kang Jesus.
* Ang "binuhatan" sa tawo pwede bisan unsa nga iyang gihimo aron mabuhi o mag-alagad sa Dios. Ang Biblia sad nagtumong sa Dios nga "nagtrabaho."

Mga Sugyot sa Paghubad

* Uban nga mga paagi sa paghubad sa "mga binuhatan" o "mga gihimo" pwede ang "mga kalihokan" o "mga butang nga nahimo."
* Siguraduhon nga ang mga pulong nga gigamit sa paghubad sa "mga binuhatan" apil niini ang mga pulong ug hunahuna.
* Kung nagtumong sa "mga binuhatan" sa Dios o mga "himo sa Dios" ug ang "buhat sa iyang mga kamot" kini nga pahayag pwede sad hubaron nga "milagro" o "gamhanong mga buhat" o "kahibulungang mga butang nga iyang gihimo."
* Ang mga pulong nga "ang buhat sa Dios" pwede hubaron nga "mga butang nga gihimo sa Dios" o "ang milagro nga gihimo sa Dios" o "ang makahibulungang mga gihimo sa Dios" o "tanan nga butang nga natapos sa Dios."
* Ang pulong nga "binuhatan" pwede nga "matag buhat nga maayo" o "matag gihimo nga maayo."
* Ang pulong nga "binuhatan" pwede sad ang mas lapad nga buot ipasabot sa "pag-alagad" o "ministeryo." Pananglitan, ang pahayag nga "ang imong binuhatan sa Ginoo" pwede sad hubaron nga "unsay imong nahimo alang sa Ginoo." Ang pahayag nga "susiha ang imong kaugalingong buhat" pwede sad hubaron nga "siguraduhon nga ang imong gihimo mao ang kabubut-on sa Dios" o "siguraduhon nga gihimo nimo ang tanan nga imong mahimo."
* Ang mga pulong nga "ang mga binuhatan sa Balaang Espiritu" pwede hubaron nga “ang ministeryo sa Balaang Espiritu" o "ang mga butang nga gihimo sa Balaang Espiritu."


# Tinuod, kamatuoran

Ang pulong nga "tinuod" ug "kamatuoran" nagtumong sa konsepto nga mga matuod nga panghitabo nga nahitabo gyud ug mga panultihon nga giingon gyud.

* Ang tinuod nga mga butang mao ang tinuod, aktwal, matinud-anon, lehitimo ug matuod.
* Ang kamatuoran mao ang tinuod nga pagsabot, pagtuo o panultihon.
* Gipadayag ni Jesus ang kamatuoran sa Dios sa mga pulong nga gilitok niya.
* Kamatuoran ang pulong sa Dios. Naghisgot kini mahitungod sa aktwal nga mga butang nga nahitabo ug nagtudlo kung unsa ang tinuod mahitungod sa Dios ug mahitungod sa tanan niyang gihimo.

Mga Sugyot sa Paghubad

* Depende sa konteksto ug kung unsa ang gihulagway, ang pulong nga "tinuod" pwede hubaron pinaagi sa "tinuod" o "matuod" o "sakto" o "sigurado o orihinal."
* Mga pamaagi sa paghubad sa pulong nga "tinuod" pwede sad, "kung unsa ang tinuod" o "sigurado gyud" o "baruganan."
* Mga sugyot sa paghubad niini nga mga pulong:
* "Dawata ang kamatuoran" ---"tuohi ang tinuod."


# Imahe/dagway sa Dios, Imahe

Ang pulong nga "imahe" nagtumong sa sama nga itsura sa usa ka butang o sama sa usa ka tawo ang kinaiya o pagkatawo. Ang mga pulong nga "imahe sa Dios" gigamit sa lainlaing mga pamaagi, depende sa konteksto.

* Sa sinugdanan sa panahon, gilalang sa Dios ang mga tawo "sa iyang kaugalingong imahe," nga "sama sa iyang dagway." Nagpasabot kini nga ang mga tawo adunay pipila ka mga kinaiya nga nagpakita sa imahe sa Dios, sama sa abilidad nga makabati sa emosyon, sa abilidad nga magrason ug makig-istorya, ug adunay espiritu nga buhi nga walay katapusan.
* Ang Biblia nagtudlo nga si Jesus, Anak sa Dios, mao ang "imahe sa Dios," nga siya Dios mismo. Dili sama sa mga tawo, si Jesus wala gilalang. Gikan siya sa walay sinugdanan ug katapusan. Ang Dios nga Anak anaa kaniya ang tanan nga balaang kinaiya tungod kay sama siya sa Dios Amahan.

Mga Sugyot sa Paghubad:

* Kung nagtumong kang Jesus, ang "imahe sa Dios" pwede hubaron nga "sakto nga dagway sa Dios" o "pareho nga kinaiya sa Dios" o "parehas sa Dios."
* Kung nagtumong sa mga tawo, "gilalang sila sa Dios sumala sa iyang imahe" pwede hubaron sa mga pulong nga nagpasabot sa, "gilalang sila sa Dios aron mahimong sama kaniya" o "gilalang sila sa Dios nga adunay kinaiya nga sama sa iyang kaugalingon.


# Judio

Ang mga Judio kaliwat ni Abraham sa iyang apo nga si Jacob.

* Nagsugod ug tawag ang mga tawo sa Israelita nga "Judio" sa dihang mibalik na sila sa Juda gikan sa pagkabihag nila sa Babilon.
* Ang pulong nga "Judio" gikan sa pulong nga "Juda." Ang mga Israelita nga binihag sa mga taga Babilon gikan sila sa habagatang bahin sa gingharian sa Juda.
* Ang Mesias nga si Jesus usa ka Judio. Apan, ang mga pangulo sa Judio nga relihiyoso nagsalikway kang Jesus ug namugos gyud sila nga ipapatay siya.


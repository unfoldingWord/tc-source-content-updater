# Jonathan

Ang ngalan nga "Jonathan" nahisgutan sa daghang higayon sa Daang Kasabotan. 
Ang ngalan nga Jonatan nagpasabot kini nga, "naghatag si Yaweh."

* Ang ilado nga Jonathan mao ang kamagulangang anak ni Haring Saul. Suod nga higala siya ni David.
* Ang ubang Jonathan nga nahisgutan sa Daang Kasabotan apil ang: apo ni Moises;  pag-umangkon ni Haring David, anak ni Abiatar nga pari nga nangalagad kang David; usa ka sekretaryo nga diin si propeta Jeremias napriso sa iyang panimalay; ug daghan pang uban.


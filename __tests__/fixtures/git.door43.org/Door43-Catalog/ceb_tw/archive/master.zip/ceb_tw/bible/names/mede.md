# Medos, Media

Ang Media usa ka karaan nga imperyo anaa sa sidlakan sa Asiria ug Babilonia ug amihanan sa Elam ug Persia. Ang yutang sakop niini apil ang gitawag karon nga Turkey, Iran, Syria, Iraq ug Afghanistan.

* Ang mga tawo nga nagpuyo sa imperyo sa Media gitawag nga mga "Medos."
* Maayo ang panaghigala sa mga Medos ug mga Persiahanon. Ang duha ka mga imperyo nagtipon sa ilang kasundalohan aron buntogon ang imperyo sa Babilonia.
* Ang pagsulong ni Dario nga Medos sa Babilonia nahitabo sa panahon nga nagpuyo si propetang Daniel didto.


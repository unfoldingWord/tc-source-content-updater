# Lamec

Duha ka mga tawo ang adunay ngalan nga Lamec nga gihisgutan sa libro sa Genesis.

* Ang unang Lamec nga gihisgutan mao ang kaliwat ni Cain. Nanghinambog siya sa iyang duha ka asawa nga nakapatay na siya ug tawo.
* Ang ikaduhang Lamec kaliwat ni Set. Amahan siya ni Noe.


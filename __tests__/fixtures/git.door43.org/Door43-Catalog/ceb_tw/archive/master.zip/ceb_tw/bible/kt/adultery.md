# pagpanapaw/pagluib, maluibon, mananapaw

Ang pulong nga "pagpanapaw" nagtumong sa sala sa mga tawo nga adunay asawa/bana nga nakighilawas sa dili niya asawa/bana. Ang pulong nga "maluibon" naghulagway niining klase sa batasan o sa tawo nga naghimo niini nga sala.

* Ang pulong nga "mananapaw" nagtumong sa bisan kinsang tawo nga nakahimo ug pagpanapaw.
* Usahay ang pulong nga "babayeng mananapaw/maluibon" gigamit aron magtumong gyud nga babaye ang nakapanapaw.
* Ang pagpanapaw makaguba sa mga saad nga gihimo sa bana ug asawa sa usa'g usa sa ilang kasabotan sa pagminyo.
* Gisugo sa Dios ang mga Israelita nga dili magpanapaw/mangluib.
* Kasagaran gamiton ang pulong nga "maluibon" sa paghulagway sa dili pagkamatinud-anon sa katawhan sa Israel ngadto sa Dios, hilabi na kung mosimba sila sa mga diosdiosan.

Mga Sugyot sa Paghubad:

* Kung ang pinulongan nga ihubad walay pulong nga nagpasabot nga "pagpanapaw," mahimong hubaron kini nga pulong nga, "nakighilawas sa asawa sa uban" o "pakigsuod sa asawa/bana sa uban."
* Ang ubang pinulongan adunay dili direkta nga paghisgot mahitungod sa pagpanapaw, sama sa "makigdulog uban sa asawa/bana sa lain" o "dili pagkamatinud-anon sa asawa/bana."


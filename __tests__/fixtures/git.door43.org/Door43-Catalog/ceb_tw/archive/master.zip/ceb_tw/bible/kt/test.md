# pagsulay

Ang pulong nga "pagsulay" nagtumong sa panghitabo nga lisod ug makapasakit nga nagpahayag sa kalig-on o kaluya sa usa ka tawo.

* Usahay naghatag ug mga pagsulay ang Dios aron ipakita ang sala sa mga tawo. Ang pagsulay makatabang sa usa ka tawo aron mosalikway sa sala ug mopaduol sa Dios.
* Ang bulawan ug ang ubang mga metal gisulayan sa kalayo aron mahibal-an kung kini tinuod o lig-on. Usa kini nga hulagway sa paghatag sa Dios ug sakit nga mga panghitabo aron sulayan ang iyang katawhan.
* Ang pulong nga "ibutang sa pagsulay" pwede magpasabot nga "gisulayan ang usa ka butang o gisulayan ang usa ka tawo aron mapamatud-an ang iyang bili."
* Si Jesus nag-ingon kang Satanas nga dili maayo nga sulayan ang Dios. Siya ang gamhanan sa tanan, balaan nga Dios nga maoy labaw sa tanan.
* Gisulayan sa Dios ang mga tawo apan wala niya sila gitintal. Si Satanas mao ang nagtintal sa mga tawo aron makasala.

Mga Sugyot sa Paghubad:

* Ang pulong nga "pagsulay" pwede sad hubaron nga "hagiton" o "hatagan ug mga kalisdanan" o "aron mapamatud-an."
* Ang mga pamaagi sa paghubad sa "sulay" pwede nga "ang hagit" o "lisod nga mga kasinatian."
* Ang sa ingles nga "ibutang sa pagsulay" pwede hubaron nga "gisulayan" o gihagit" o "gipugos aron mapamatud-an ang kaugalingon."
* Ang mga pulong nga "sulay" ug "tintal" kinahanglan gyud nga lahi ang pagkahubad.


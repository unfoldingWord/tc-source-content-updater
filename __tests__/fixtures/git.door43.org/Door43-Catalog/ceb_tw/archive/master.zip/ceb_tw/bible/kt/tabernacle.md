# tabernakulo

Ang tabernakulo usa ka pinasahi nga tinukod nga murag tolda diin gisimba sa mga Israelita ang Dios niadtong 40 ka mga tuig nga naglibotlibot sila sa disyerto.

* Naghatag ang Dios sa mga Israelita ug detalyado nga mga panudlo sa pagtukod niining dako nga tolda nga adunay duha ka kuwarto ug gipalibotan sa serado nga hawanan.
* Sa matag higayon nga ang mga Israelita mobalhin ug bag-o nga lugar sa disyerto aron didto magpuyo, bungkagon sa mga pari ang tabernakulo ug dad-on ang mga parte niini sa ilang sunod nga kampohan. Unya itukod nila kini pag-usab sa tunga sa ilang bag-o nga kampo.
* Ang tabernakulo gitukod pinaagi sa mga banayan nga kahoy nga gibutangan ug mga kurtina nga hinimo sa panapton, buhok sa kanding, ug panit sa mga mananap. Ang hawanan nga nagpalibot niini giseradohan ug daghan pang mga kurtina.
* Ang duha ka mga bahin sa taberkulo mao ang dapit nga Balaan (diin makita ang halaran nga sunugan sa insenso) ug ang usa mao ang dapit nga Labing Balaan (diin didto gitago ang arka sa pakigsaad).
* Ang hawanan sa tabernakulo adunay halaran alang sa pagsunog sa mga mananap nga gisakripisyo ug adunay pinasahi nga planggana alang sa ritwal nga paghinlo.
* Wala na mogamit ug tabernakulo ang mga Israelita niadtong nagtukod na ug templo si Haring Solomon sa Jerusalem.

Mga Sugyot sa Paghubad:

* Ang pulong nga "tabernakulo" nagpasabot nga "puloy-anan." Ang lain nga mga pamaaagi sa paghubad pwede nga, "tolda alang sa panagtagbo" o "sagrado nga tolda " o "tolda diin anaa ang Dios" o "tolda sa Dios."
* Siguradoha nga ang paghubad niini nga pulong lahi sa paghubad sa pulong nga "templo."


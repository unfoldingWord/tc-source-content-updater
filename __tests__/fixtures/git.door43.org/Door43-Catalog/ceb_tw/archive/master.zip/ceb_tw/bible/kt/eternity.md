# walay katapusan, dumalayon, kahangturan

Ang pulong nga "walay katapusan" ug "dumalayon" parehas lang ang gipasabot ug nagtumong sa usa nga anaa kanunay o sa walay katapusan.

* Ang pulong nga "kahangturan" nagtumong sa walay sinugdanan o walay katapusan. Pwede sad kini nagtumong sa kinabuhing walay katapusan.
* Paghuman niini nga kinabuhi sa kalibutan, ang tanang mga tawo magpadayon sa kinabuhi nga walay katapusan sa langit man uban ang Dios o sa impyerno nga bulag sa Dios.
* Ang pulong nga, "kinabuhing dumalayon" ug "kinabuhing walay katapusan" gigamit sa Bag-ong Kasabotan nga nagtumong sa pagkabuhi nga walay katapusan kauban ang Dios sa langit.
* Ang mga pulong nga "hangtod sa kahangturan" adunay ideya sa panahon nga walay katapusan ug nagpahayag kung unsa ang kinabuhing walay katapusan o unsa ang kinabuhing dumalayon.

Mga Sugyot sa Paghubad

* Ang ubang pamaagi sa paghubad sa "dumalayon" o " kinabuhing walay katapusan" pwede ang, "walay katapusan" o "walay paghunong" o "kanunay nagpadayon."
* Ang pulong nga "kinabuhing walay katapusan" o "kinabuhing walay kahangturan" pwede kini hubaron nga "kinabuhing walay kahumanan" o "kinabuhing magpadayon nga walay paghunong" o "ang pagkabanhaw sa atong mga lawas aron magkinabuhi sa walay katapusan."
* Depende sa konteksto, adunay lainlain nga pamaagi sa paghubad sa "kahangturan" pwede sad ang, "anaa siya gawas sa panahon" o "kinabuhing walay katapusan" o "kinabuhi sa langit."
* Hunahunaa sad kung giunsa paghubad niini sa Biblia sa lokal o nasudnong pinulongan.


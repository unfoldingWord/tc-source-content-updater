# Ashera, Asherim

Ang Ashera, ngalan sa usa ka diosa nga gisimba sa mga Canaanhon sa panahon sa Daang Kasabotan.

* Ang pulong nga "Asherim" nagtumong sa nililok nga mga imahe nga hinimo gikan sa kahoy o nililok nga mga kahoy nga nagrepresentar ani nga diosa. Usahay kini nga mga imahe nagtumong sa "mga poste sa Ashera." 
* Kasagaran nakaplastar kini duol sa mga halaran alang sa diosdiosan nga si Baal ang gituohan nga bana ni Ashera.
* Gimanduan sa Dios ang mga Israeilta nga gubaon ang tanang linilok nga mga imahe ni Ashera.
* Apan ang uban nga mga pangulo nga Israelita, sama kang haring Solomon, haring Manasseh, ug kang Reyna Jezebel, dili lamang nila gitugutan ang pagbutang sa daghang Asherim sa Israel, apan ila hinuon gimpluwensyahan ang mga tawo nga mosimba kanila.
* Adunay uban nga mga pangulo sama kang Gidion, Haring Asa, ug Haring Josiah nga mituman sa Dios ug nangulo sa mga tawo sa pagguba niining mga diosdiosan.


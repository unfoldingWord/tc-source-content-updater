# Jetro, Reuel

Ang ngalan nga Jetro ug Reuel parehas nga gigamit nga natumong sa amahan ni Zippora nga asawa ni Moises.

* Kaniadtong pastol pa si Moises didto sa Median, nahimamat niya ang taga Median nga ginganlan ug Reuel. Ang iyang mga anak nagpainum sa mga karnero sa atabay didto.
* Giminyuan ni Moises si Zippora usa sa mga anak ni Reuel.
* Paglabay sa mga katuigan, si Reuel nga gitawag sad ug Jetro, nakipagkita kay Moises sa dihang ang mga Israelita naglibotlibot sa kamingawan.
* Sa niini nga punto, gihisgutan si Jetro nga usa ka pari.
* Gitambagan ni Jetro si Moises kung unsaon nga matabangan siya sa uban sa paghukom sa mga tawo mahitungod sa ilang mga binuhatan. 
* Natala sa Daang Kasabotan ang duha pa ka mga tawo nga Reuel ang pangalan apil ang usa sa mga anak ni Esau. Pwede magdisisyon ang mga maghuhubad sa pag-ispling niining duha ka mga tawo nga lainlain aron maklaro nga lahi silang duha.


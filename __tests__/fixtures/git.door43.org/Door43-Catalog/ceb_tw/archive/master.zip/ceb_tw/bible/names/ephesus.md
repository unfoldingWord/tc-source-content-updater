# Efeso

Ang Efeso usa ka karaan nga siyudad sa Griego sa kasadpan nga baybayon nga karon mao ang nasod saTurkey.

* Sa panahon sa mga unang Kristuhanon, ang Efeso mao ang kapital sa Asya, diin niadto nga panahon ginganlan nga gamay nga probinsiya sa Roma.
* Tungod sa iyang lokasyon, kini nga siyudad importante nga sentro sa negosyo ug sa biyahe.
* Makita sa Efeso ang ilado nga pagano nga templo diin gisimba ang diosa nga si Artemis (o Diana).
* Si Pablo nagpuyo ug nag-alagad sa Dios sa Efeso kapin sa duha ka tuig ug kadugayan gipili si Timoteo nga maoy mangulo sa mga bag-o nga tumutuo didto.
* Ang Efeso usa ka libro sa Bag-ong Kasabotan nga gisulat ni Pablo alang sa mga tumutuo sa taga-Efeso.


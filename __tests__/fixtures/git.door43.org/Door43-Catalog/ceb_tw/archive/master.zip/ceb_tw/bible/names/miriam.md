# Miriam

Si Miriam mao ang magulang nga igsoong babaye ni Aaron ug Moises.

* Niadtong bata pa siya, gimandoan si Miriam sa iyang inahan nga bantayan ang iyang manghod nga si Moises nga gibutang sa basket didto sa mga kasagbotan sa Suba sa Nilo. Niadtong nakit-an sa anak nga babaye sa paraon ang bata ug nanginahanglan siya ug magbantay niini, si Miriam maalam nga gidala ang iyang inahan aron magbantay sa bata.
* Niadtong miikyas ang mga Israelita gikan sa mga Ehiptohanon ug mitabok sa Pulang Dagat, gipangulohan ni Miriam ang mga Israelita sa pagsayaw sa kalipay ug pagpasalamat.
* Paglabay sa pipila ka tuig, niadtong naglibotlibot ang mga Israelita sa disyerto, wala malipay sila Miriam ug Aaron nga si Moises naminyo ug babayeng taga-Cus ug nagsugod sila ug panglibak kaniya.
* Tungod sa iyang pagsupak pinaagi sa pagsulti batok kang Moises, gihatagan ug sakit sa Dios si Miriam nga sangla. Apan kadugayan, gi-ayo siya sa Dios niadtong nag-ampo si Moises alang kaniya.


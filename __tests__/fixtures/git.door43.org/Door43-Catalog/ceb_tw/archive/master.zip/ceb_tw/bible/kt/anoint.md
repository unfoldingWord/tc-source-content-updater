# dihog, nadihugan

Ang pulong nga "dihog" nagpasabot sa pagpahid o pagbubo ug lana sa usa ka tawo o butang. Usahay, ang lana sagulan ug mga pahumot aron mohumot kini. Gigamit sad nga sumbingay kini nga pulong sa pagpasabot sa Balaan nga Espiritu nga nagpili ug naghatag ug gahum sa usa ka tawo.

* Sa Daang Kasabotan, ang mga pari, mga hari, ug mga propeta gidihugan ug lana aron igahin sila alang sa pinasahi nga pag-alagad sa Dios.
* Gidihugan sad ang uban sama sa mga halaran o ang tabernaculo aron ipakita nga gamiton sila aron simbahon ug himayaon ang Dios.
* Sa Bag-ong Kasabotan, gidihugan ang mga masakiton aron maayo sila.
* Ang Bag-ong Kasabotan nagsulat ug duha ka higayon nga gidihugan si Jesus ug humot nga lana sa usa ka babaye ingon nga pagsimba. Usa ka higayon, miingon si Jesus nga sa pagbuhat niini, ang babaye nag-andam kaniya alang sa iyang umaabot nga paglubong.
* Pagkahuman mamatay ni Jesus, giandam sa iyang mga higala ang iyang lawas sa paglubong pinaagi sa pagdihog niini ug lana ug mga pahumot.
* Ang mga titulo nga "Mesiyas" (Hebreohanon) ug "Cristo" (Griego) nagpasabot nga "ang Gidihugan."
* Si Jesus nga Mesiyas mao ang pinili ug gidihugan ingon nga Propeta, Kinatas-ang Pari, ug Hari.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang pulong nga "pagdihog" mahimong hubaron nga "pagbubo ug lana" o "butangan ug lana" o "gigahin pinaagi sa pagbubo ug humot nga lana."
* Ang "madihugan" mahimong hubaron nga "igahin pinaagi sa lana" o "gipili" o "gigahin."
* Sa pipila ka konteksto, ang pulong nga "nadihugan" mahimong hubaron nga "napili."
* Ang mga pulong sama sa "ang nadihugan nga pari" mahimong hubaron nga "ang pari nga gigahin pinaagi sa lana" o "ang pari nga gigahin pinaagi sa pagbubo ug lana."


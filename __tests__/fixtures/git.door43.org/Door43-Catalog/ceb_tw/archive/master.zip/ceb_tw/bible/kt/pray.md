# Ampo, Pag-ampo

Ang pag-ampo mao ang pakigsulti sa Dios.

* Kasagaran ang mga tawo mag-ampo sa Dios sa paghangyo kaniya sa pagtabang sa ila o sa ubang mga tawo.
* Sa ilang mga pag-ampo nagpasalamat sad ang mga tawo ug nagdayeg sa Dios. 
* Ang pag-ampo pwede sad ipasabot nga paghinulsol sa atong mga sala sa Dios ug sa paghangyo kaniya sa pagpasaylo kanato.
* Kung ang mga tawo mosulay sa pakig-estorya sa ilang dili tinuod nga dios, gitawag sad kini nga "pag-ampo."


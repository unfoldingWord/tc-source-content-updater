# Malaquias

Si Malaquias usa sa mga propeta sa Dios sa nasod nga Israel.

* Si Malaquias nagtagna sa panahon nga ang templo sa mga Israelita gitukod pag-usab kadtong namalik sila gikan sa pagkabihag sa Babilonya.

* Tingali sa Malaquias nabuhi sa panahon nila ni Nehemias ug si Ezra.

* Ang libro nga Malaquias katapusan nga libro sa Daang Kasabotan ug giingon sa kasaysayan uban kini niadtong mugbo nga mga libro nga gisulat sa ubang mga propeta.


# Abner

Si Abner mao ang ig-agaw ni Haring Saul sa Daang Kasabotan. 

* Si Abner mao ang labing labaw nga pangulo sa kasundalohan ni Haring Saul ug ang nagpailaila sa batan-on nga David ngadto kang Saul human gipatay ni David ang higante nga si Goliat.
* Kadtong namatay na si Haring Saul, gipili ni Abner si Isboset, nga anak nga lalaki ni Saul, isip hari sa Israel samtang si David gipili nga hari sa Juda.
* Kadugayan, mabudhion nga gipatay si Abner ni Joab nga labing labaw nga pangulo sa kasundalohan ni David.


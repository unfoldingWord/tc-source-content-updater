# sinyales, ebidensiya, timaan

Ang sinyales usa ka butang, panghitabo, o binuhatan na nagpahayag ug pinasahi nga pasabot.

* Ang mga sinyales pwede nga mga timaan sa usa ka butang nga gisaad.
* Ang bangaw nga gibuhat sa Dios didto sa langit usa ka sinyales nga nagpahinumdom sa mga tawo nga dili na gyud laglagon sa Dios ang tanang nabuhi pinaagi sa lunop sa tibuok kalibotan.
* Gisugo sa Dios ang mga Israelita nga tulion ang ilang anak nga mga lalaki ingon nga sinyales sa iyang kasabotan kanila.
* Ang mga sinyales pwede magpahayag o magtudlo ngadto sa usa ka butang.
* Gisultihan sa usa ka anghel ang mga pastol ug sinyales nga makatabang kanila sa pag-ila kung kinsa nga bata sa Betlehem ang bag-ong natawo nga Mesiyas.
* Gihalokan ni Judas si Jesus ingon nga sinyales alang sa mga pangulo sa relihiyon nga si Jesus mao ang ilang dakpon.
* Ang mga sinyales makahatag ug ebidensiya nga tinuod ang usa ka butang.
* Ang mga milagro nga gibuhat sa mga propeta ug apostoles mga sinyales nga nagpamatuod nga nagsulti sila sa mensahe sa Dios.
* Ang mga milagro nga gibuhat ni Jesus mga sinyales nga nagpamatuod nga siya gyud ang Mesiyas.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang "sinyales" pwede sad hubaron nga "timaan" o "simbolo" o "marka" o "ebidensiya" o "pamatuod" o "pagpakita."


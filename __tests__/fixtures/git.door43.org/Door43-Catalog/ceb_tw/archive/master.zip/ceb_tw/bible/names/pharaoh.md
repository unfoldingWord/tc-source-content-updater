# Paraon, Hari sa Ehipto

Adtong una pa kaayo nga panahon, ang mga hari nga nangulo sa nasod sa Ehipto gitawag nga mga paraon.

* Tanantanan, adunay labaw pa sa 300 ka mga paraon ang nangulo sa Ehipto sulod sa labaw pa sa 2,000 ka mga tuig.
* Kini nga mga Ehiptohanong mga hari gamhanan kaayo ug adunahan.
* Pipila sa niini nga mga paraon nahisgutan sa Biblia.
* Kasagaran kini nga titulo gigamit nga ngalan nila imbes nga titulo. Sa niini nga mga higayon, gikapital kini nga "Paraon."


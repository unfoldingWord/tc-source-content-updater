# Galilea, taga Galilea

Ang Galilea mao ang pinaka tumoy sa amihanang parte sa Israel, mas layo pa kaysa sa Samaria.

* Ang Galilea giutlanan sa sidlakan sa dako nga suba nga gitawag nga "Dagat sa Galilea."
* Si Jesus nagpuyo ug nagdako sa lungsod sa Nasaret sa Galilea.
* Ang taga Galilea usa ka tawo nga nagpuyo sa Galilea.


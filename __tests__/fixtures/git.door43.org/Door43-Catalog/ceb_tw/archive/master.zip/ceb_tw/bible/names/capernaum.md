# Caparnaum

Ang Caparnaum usa ka lugar nga pangisdaanan nga nahimutang sa amihang kasadpan sa baybay sa dagat sa Galilea.

* Sa Caparnaum nipuyo si Jesus niadtong nagtudlo siya sa Galilea.
* Gitunglo ni Jesus ang Caparnaum tungod kay ang mga tawo niini nga lugar wala modawat sa Iyang mensahe. Karon, ang karaan nga lungsod sa Caparnaum naguba na.


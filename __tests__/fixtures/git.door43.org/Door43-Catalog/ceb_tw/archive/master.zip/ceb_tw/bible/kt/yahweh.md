# Yahweh

Ang pulong nga "Yahweh" mao ang kaugalingon nga ngalan sa Dios nga iyang gipahayag kang Moises didto sa gadilaab nga sampinit. Nag-ingon ang Dios nga mao kini ang iyang ngalan hangtod sa kahangturan.

* Ang ngalan nga "Yahweh" gikan sa pulong nga nagpasabot "nga mahimo nga."
* Pwede kini magpasabot nga "Siya" o "Ako" o "ang usa nga maoy hinungdan nga."
* Kini nga ngalan nagpahayag nga ang Dios walay katapusan; kanunay siya nga buhi ug padayon nga buhi hangtod sa kahangturan.  Wala siya nagkinahanglan nga adunay bisan kinsa nga maghimo kaniya o maghatag kaniya ug kinabuhi. Kini sad nagpasabot nga kanunay siya ng anaa.
* Daghang bersyon sa Biblia sa nasudnong mga pinulungan sama sa Ingles, Pransiya, ug Espanya ang migamit ug kaparehas sa "ang GINOO" aron magrepresentar kang "Yahweh," sama sa mga pulong nga "Ako ang GINOO nga inyong Dios" ug sa daghan pang ubang konteksto.
* Bisan pa niini, ang ULB ug UDB gihubad lang ang ngalan sa Dios nga literal nga "Yahweh."
* Sa Bag-ong Kasabotan, ang orihinal nga pulong nga gigamit sa mga pulong nga "Dios" o "Ginoo" o "Ama" aron magtumong sa Dios; ang pulong nga "Yahweh" wala gamita sa Bag-ong Kasabotan.

Mga sugyot sa paghubad

* Kini nga pulong pwede hubaron sa pulong o mga pulong nga nagpasabot nga "Ako" o "usa nga buhi" o "ang usa nga maoy" o "Siya nga buhi."
* Kini nga pulong pwede sad isulat nga parehas sa espeling sa "Yahweh."
* Timan-i nga ang "Jehovah" dili maayo nga hubad sa niini nga pulong. Kaniadto ang mga Judio nag-ingon nga "Ginoo" imbes nga "Yahweh” kadugayan ang ubang mga tawo gitangtang ang mga letra nga mga “vowels” sa Hebreo nga pulong alang sa Ginoo ug gipulihan ug mga “vowels” ang Hebreo nga pulong nga Yahweh. Kini nagresulta sa nahimo nga espeling nga "Jehovah," diin dili kini sakto nga pamaagi nga i-espeingl ang kaugalingon nga ngalan sa Dios.


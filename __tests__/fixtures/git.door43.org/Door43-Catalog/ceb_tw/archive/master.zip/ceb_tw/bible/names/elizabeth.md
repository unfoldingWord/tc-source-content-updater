# Elisabet

Si Elisabet mao ang inahan ni Juan nga Bautista. Zacarias ang ngalan sa iyang bana.

* Si Elisabet wala makaanak, apan sa dihang tigulang na gyud siya diha pa lang siya nahatagan ug anak, nagsaad ang Dios kang Zacarias nga si Elisabet manganak ug usa ka lalaki.
* Gituman sa Dios ang iyang saad, ug sa wala magdugay si Zacarias ug si Elisabet nahatagan ug anak. Ginganlan nila ang bata nga Juan. 
* Si Elisabet paryente ni Maria nga inahan ni Jesus.


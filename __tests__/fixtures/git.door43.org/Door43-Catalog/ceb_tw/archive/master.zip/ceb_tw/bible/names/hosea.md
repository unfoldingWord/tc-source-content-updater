# Hosea

Si Hosea usa ka propeta sa Israel mga 750 ka tuig usa pa gipanganak si Cristo.

* Ang iyang ministeryo milungtad sa daghang mga tuig sa paghari sa pipila ka mga hari sa Israel ug Juda sama kang Jeroboam, Zacarias, Uzia, Jotam, ug Ezequias.
* Si Hosea giingnan sa Dios nga iyang minyoon si Gomer, usa ka babaye nga nagbaligya ug dungog ug padayon nga higugmaon niya siya bisan pa kung dili siya matinud-anon.
* Mao kini ang hulagway sa gugma sa Dios alang sa Israel, ang dili matinudanon niyang katawhan.
* Nagtagna si Hosea batok sa mga tawo sa Israel, gipasidan-an niya sila nga mosalikway sa pagsimba sa mga diosdiosan.


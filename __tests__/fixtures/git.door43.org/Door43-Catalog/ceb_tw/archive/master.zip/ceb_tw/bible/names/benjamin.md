# Benjamin

Si Benjamin ang kinamanghurang anak ni Jacob sa iyang asawa nga si Rachel.

* Ang mga kaliwat ni Benjamin nahimong usa sa dose ka tribu sa Israel.
* Ang hari sa Israel nga si Saul gikan sa Israelitang tribu ni Benjamin.
* Si Saul nga taga Tarsus, nga sa kadugayan nahimo nga si Pablo nga apostol, gikan sad sa tribu ni Benjamin.


# Miguel

Si Miguel mao ang pangulo sa tanang mga balaan ug matinumanon nga mga anghel sa Dios. Siya lang ang anghel nga pinasahi nga gitumong nga "arcanghel" sa Dios.

* Ang pulong nga "arcanghel" nagpasabot nga "pangulong anghel" o "anghel nga nangulo."
* Gipangulohan ni Miguel ang Israel batok sa mga taga-Persia. Siya sad ang mangulo sa mga kasundalohan sa Israel sa kataposang gubat batok sa mga pwersa sa dautan sumala sa gitagna sa libro nga Daniel sa Daang Kasabotan.
* Usahay gihulagway sad siya nga tigpatiwala alang sa mga katawhan atubangan sa Dios.
* Aduna say pipila ka mga lalaki sa Biblia nga mao kini ang ngalan.


# En Gedi

Ang En Gedi ngalan sa usa ka siyudad sa kamingawan sa Juda sa habagatang silangan sa Jerusalem.

* Ang En Gedi makita sa kasadpang baybayon sa Dagat nga Asin.
* Parte sa ngalan niini nagpasabot nga "tuburan," nga nagtumong sa tubod sa tubig nga nagdagayday gikan sa siyudad padulong sa dagat.
* Nailhan ang En Gedi nga adunay mga maayong ubasan ug ubang tabunok nga yuta, tungod sa kanunay nga patubig nga nagagikan sa tuburan.
* Adunay mga salipdanan sa En Gedi diin si David mikalagiw sa dihang gigukod siya ni Haring Saulo.


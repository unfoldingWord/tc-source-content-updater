# panaad

Ang panaad usa ka panumpa sa pagbuhat ug usa ka butang. Kung ang usa ka tawo nagsaad ug usa ka butang, nagpasabot kini nga siya masaligon sa pagbuhat sa usa ka butang.

* Nagtala ang Biblia sa daghang mga panaad nga gihimo sa Dios alang sa iyang mga tawo.
* Ang mga panaad importante nga bahin sa usa ka pormal nga kasabotan sama sa mga pakigsaad.
* Inubanan usahay ang mga panaad ug panumpa nga magpamatuod nga kini matuman.

Mga Sugyot sa Paghubad

* Ang pulong nga "panaad" pwede hubaron nga, "mapasaligon" o "pasalig" o kasigurohan."
* Ang "panaad sa pagbuhat ug usa ka butang" pwede hubaron nga, pagpasalig sa usa ka tawo nga magbuhat ug usa ka butang" o "masaligon sa pagbuhat ug usa ka butang."


# Hari sa mga Judio

Ang pulong nga, "Hari sa mga Judio" usa ka titulo nga nagtumong kang Jesus, ang Mesias.

* Ang unang higayon nga natala sa Biblia kini nga titulo gigamit sa mga maalamong mga tawo nga nagbeyahe sa Betlehem nga nangita sa bata nga "Hari sa mga Judio."
* Gipakita sa anghel kang Maria nga ang iyang anak, kaliwat ni David, ug mahimong hari nga ang iyang paghari hangtod sa kahangturan.
* Sa wala pa gilansang si Jesus, ang mga Romanong sundalo nagbiay-biay nga nagtawag kang Jesus nga "Hari sa mga Judio." Gisulat sad kini nga titulo sa piraso nga kahoy nga gilansang sa taas sa krus ni Jesus.
* Tinuod gyud nga si Jesus Hari sa mga Judio ug hari sa tanang mga binuhat.

Mga Sugyot sa Paghubad

* Ang pulong nga "Hari sa mga Judio" pwede hubaron nga "hari sa mga Judio" o "hari nga nangulo sa mga Judio" o " labing taas nga pangulo sa mga Judio."
* Tan-awa kung giunsa ang pulong nga "hari sa" gihubad sa lugar sa hinubaran.


# Dan

Si Dan mao ang ikalimang anak nga lalaki ni Jacob ug usa sa dose ka mga tribo sa Israel. Dan sad ang ngalan sa dapit diin nagpuyo ang tribo nga Dan sa amihanang dapit sa Canaan.

* Niadtong panahon ni Abram, aduna say siyudad nga Dan sa kasadpan sa Jerusalem. Tingali wala pa kini nga siyudad kaniadtong panahon nga nisulod ang Israel sa yutang gisaad kanila. Apan adunay lain nga siyudad nga Dan nga anaa mga 60 ka milya sa amihanan sa Jerusalem.
* Ang pulong nga "Danenahon" nagtumong sa mga kaliwat ni Dan nga mga membro sad sa iyang banay.


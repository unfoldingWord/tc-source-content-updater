# Ismael

Si Ismael anak nga lalaki ni Hagar nga ulipon nila Abraham ug Sarah.

* Ang ngalan nga "Ismael" nagpasabot nga "nakadungog ang Dios.
* Si Ismael nakadawat ug kaayohan sa balaan nga saad mahitungod sa iyang kaugalingon ug sa iyang kaugmaon nga gihatag kang Hagar. 
* Bisan pa niani, dili si Ismael ang anak nga motuman sa saad sa Dios kang Abraham nga ang iyang mga kaliwat modaghan sama sa mga bitoon.


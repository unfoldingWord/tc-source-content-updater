# matarong, pagkamatarong

Ang pulong nga "matarong" ug "pagkamatarong" nagtumong kini sa bug-os nga pagkamaayo, katarong, pagkamatinud-anon, ug gugma sa Dios. Tungod kay matarong ang Dios, kinahanglan nga iyang silotan ang sala.

* Kini nga pulong kasagaran sad nga gamiton sa paghulagway sa tawo nga mituman sa Dios ug maayo ang pagkatawo. Apan, tungod kay ang tanan nga mga tawo makasasala man, gawas sa Dios wala gyuy lain nga bug-os nga matarong. 
* Mga ehemplo sa mga tawo sa Biblia nga gitawag nga mga "matarong" mao sila Noe, Job, Abraham, Zacarias, ug si Elisabet.
* Sa dihang ang mga tawo mosalig kang Jesus aron luwason sila, hugasan sila sa Dios sa ilang mga sala ug ipahayag nga matarong na sila pinaagi sa pagkamatarong ni Jesus.

Mga Sugyot sa Paghubad:

* Kung magtumong sa Dios, ang pulong nga "matarong" pwede hubaron nga "hingpit nga maayo ug matarong" o "kanunay nga naghimo ug sakto."
* Ang " pagkamatarong" sa Dios pwede sad hubaron nga "maangayon" o "hingpit nga pagkamatinumanon ug pagkamaayo."
* Kung magtumong sa mga tawo nga matinumanon sa Dios, ang pulong nga "matarong" pwede sad hubaron nga "maayo ang moral" o "maangayon" o "nagkinabuhi nga nahimut-an sa Dios." 
* Ang mga pulong nga "ang matarong" pwede sad hubaron nga "matarong nga mga tawo" o "mahadlukon sa Dios nga mga tawo."  
* Depende sa konteksto, ang "pagkamatarong" pwede sad hubaron kauban ang pulong o mga pulong nga buot pasabot, "pagkamaayo" o "pagkamaangayon" o "hingpit sa atubangan sa Dios" o "nagbuhat sa tamang paagi sa pagtuman sa Dios" o "maayo ug hingpit ang binuhatan."
* Usahay "ang matarong" gigamit nga sumbingay nga nagtumong sa "mga tawo nga gahunahuna nga sila maayo" o "mga tawo nga mura ug matarong."


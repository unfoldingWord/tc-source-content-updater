# Naaman

Si Naaman mao ang komander sa kasundalohan sa usa sa mga kaaway sa Israel.

* Si Naaman adunay grabe nga sakit sa panit nga walay nakahibalo kung unsaon pag-ayo.
* Giingnan ni Eliseo si Naaman nga magligo sa Suba sa Jordan. Niadtong mituman si Naaman, giayo siya sa Dios sa iyang sakit.
* Nituo si Naaman sa Dios tungod kay giayo siya niya sa iyang sakit.


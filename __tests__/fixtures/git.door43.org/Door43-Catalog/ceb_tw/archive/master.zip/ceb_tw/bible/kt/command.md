# sugo, magsugo, kasuguan

Ang pulong nga "sugo" ug "magsugo" nagtumong sa pagmando sa usa ka tawo nga buhaton ang usa ka butang.

* Bisan kini nga mga pulong parehas lang ang buot ipasabot, ang "mga sugo" kasagaran nagtumong sa pipila ka mga sugo sa Dios nga diin mas pormal kini ug permanente, sama sa napulo ka mga sugo.
* Ang sugo pwede nga positibo ("Pasidunggi ang imong mga ginikanan" o negatibo ("Ayaw ug pangawat").
* Ang Iningles nga "take command" buot ipasabot nga ang usa ka tawo angkonon niya ang responsibilidad nga pakapangulo..

Mga Sugyot sa Paghubad:

* Mas maayo nga hubaron kini nga pulong lahi sa pulong nga "balaod." Ikumpara sad sa "kamandoan" o "balaod."
* Ang uban nga mga tagahubad mas gusto nila nga hubaron ang "sugo" ug "kasugu-an” nga pareho lang ang pulong sa ilang pinulongan.
* Ang uban gusto nilang gamiton ang pinasahi nga pulong sa mga sugo nga nagtumong sa walay katapusan, ug pormal nga mga sugo nga gihimo sa Dios.


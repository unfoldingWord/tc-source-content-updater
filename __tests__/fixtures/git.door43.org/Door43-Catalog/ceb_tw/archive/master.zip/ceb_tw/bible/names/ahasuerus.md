# Ahasuero/Assuero

Si Ahasuero usa ka hari nga nangulo sa adtong una pa kaayong gingharian sa Persia sulod sa baynte ka tuig.

* Mao kini ang panahon nga ang mga binihay nga mga Judio nagpuyo sa Babilonia, nga giharian sa Persia.
* Ang uban nga ngalan niini nga hari mao ang Xerxes o Artaxerxes.
* Pagkahuman gipahawa niya ang iyang rayna tungod sa iyang kasuko, sa wala magdugay nagpili si Haring Ahasuero ug babaye nga Judio nga ang pangalan si Ester aron mahimong bag-o niyang asawa ug rayna.


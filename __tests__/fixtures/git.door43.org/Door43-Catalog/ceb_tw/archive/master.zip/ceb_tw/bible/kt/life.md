# kinabuhi, mabuhi, buhi,

Kini nga mga pulong nagtumong sa pisikal nga buhi, dili patay. Gigamit sad sila nga sumbingay nga nagtumong sa tawo nga buhi sa espirituhanong bahin. Ang mga naghisgot sa ubos magpatin-aw kung unsa ang buot ipasabot sa "lawasnon nga kinabuhi" ug "espirituhanon nga kinabuhi."  

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "kinabuhi" pwede hubaron nga "pagkabuhi" o "tawo" o "kalag" o "nilalang" o "kasinatian."
* Ang pulong nga "mabuhi" pwede hubaron sa "magpuyo" ( o "nagpuyo") o "anaa."
* Ang mga pulong nga "katapusan sa iyang kinabuhi" pwede sad hubaron nga "sa dihang miundang siya nga "mabuhi."
* Ang sumbingay nga "giluwas ang ilang kinabuhi" pwede hubaron nga "gitugutan sila nga mabuhi" o  "wala sila patya."
* Ang sumbingay nga "gitahan nila ang ilang kinabuhi " pwede hubaron nga "gibutang nila ang ilang kaugalingon sa peligro" o "nagbuhat sila ug butang nga pwede nilang ikamatay."


# Felipe nga apostol

Si Felipe nga apostol, ang orihinal nga usa sa mga dose ka mga disipulo ni Jesus.

* Si Felipe gikan sa lungsod sa Betsaida; Gipaila-ila niya si Nataniel kang Jesus.
* Usa ka higayon nangutana si Felipe kang Jesus kung unsaon pagpakaon sa 5,000 ka mga tawo.
* Sa ulahing panihapon sa Kasaulugan sa Pagsaylo diin si Jesus mikaon kauban sa iyang mga disipulo, nagsulti siya mahitungod sa Dios nga iyang Amahan. Gihangyo ni Felipe nga ipakita kanila ang iyang Amahan. 
* Sa pipila ka mga pinulungan pwede ispelingon ang ngalan ni Felipe sa lainlaing pamaagi sa lain pang Felipe (nga ebanghelista) aron dili makalibog.


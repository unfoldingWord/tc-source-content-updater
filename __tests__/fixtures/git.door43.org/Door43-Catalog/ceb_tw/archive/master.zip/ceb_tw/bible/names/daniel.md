# Daniel

Si Daniel usa ka Israelitang propeta nga niadatong batan-ong lalaki pa siya, gibihag  siya sa hari sa Babilonia nga si Nabucodonosor niadtong mga ika 600 ka tuig sa wala pa gipanganak si Cristo.

* Kini nahitabo niadtong panahon nga gibihag sa Babilonia ang daghang mga Israelita gikan sa Juda sulod sa 70 ka tuig.
* Gihatagan si Daniel sa Babiloniahanong ngalan nga Beltesasar.
* Si Daniel usa ka dungganon ug matarong nga batan-ong lalaki nga mituman sa Dios.
* Gihatagan si Daniel sa Dios ug abilidad nga makasabot sa pipila ka mga damgo o talan-awon alang sa mga hari sa Babilonia.
* Tungod niini nga abilidad ug tungod sa iyang dungganon nga kinaiya, si Daniel gihatagan ug taas nga posisyon sa pagpangulo didto sa Babilonia.
* Paglabay sa daghang mga tuig, gilimbongan sa mga kaaway ni Daniel ang hari sa Babilonia nga si Darius nga maghimo ug balaod nga idumili ang pagsimba kang bisan kinsa gawas sa hari. Padayon nga nag-ampo si Daniel sa Dios, mao nga gidakop siya ug gilabay ngadto sa yungib sa mga leon. Apan giluwas siya sa Dios ug wala gyud siya masakitan.


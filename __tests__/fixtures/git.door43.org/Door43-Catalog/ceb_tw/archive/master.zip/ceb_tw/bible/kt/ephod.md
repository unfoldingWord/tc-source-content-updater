# Epod

Ang epod usa ka bisti nga gisul-ob sa mga pari nga Israelita ibabaw sa ilang mga sinina. Maigo kini sa ilang mga abaga ug nagtabon sa ilang lawas hangtod sa ilang paa. Gihigtan kini dapit sa hawak gamit ang bakus o bigkis.

* Kini nga bisti sa pari nindot ug mahal kaayo, giartihan ug bulawan, ug hilo o tanod nga azul, purpura, ug pula.
* Ang tabon sa dughan sa pari nakabutang sa atubangan sa epod. Sa likod sa tabon sa dughan gitipigan sa "Urim ug Tumim", nga mga bato nga gigamit sa pagpangutana sa Dios kung unsa ang iyang kabubut-on mahitungod sa usa ka butang.
* Si Gideon naghimo ug epod nga bulawan ug nahimo kini nga diosdiosan nga gisimba sa mga Israelita.


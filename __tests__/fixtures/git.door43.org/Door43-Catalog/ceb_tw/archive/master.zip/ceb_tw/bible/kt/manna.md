# mana

Ang mana nigpis nga sama sa pan nga gihatag sa Dios sa mga Israelita sa kamingawan pagkahuman nga mibiya sila sa Ehipto.

* Ang mana daw sama sa gagmay nga pan nga puti ug nigpis kaayo nga kada buntag makit-an sa ilalom sa yamog. Kada adlaw ang mga Israelita manguha ug mana gawas sa Adlaw sa Igpapahulay ug sakto lang gyud nga makakaon matag-usa anang adlawa.
* Sa adlaw usa moabot ang Adlaw nga Ipagpahulay, ang Dios nag-ingon sa mga Israelita nga doblehon nila ang ilang kuhaon aron dili na sila manguha sa sunod nga adlaw.
* Ang pulong nga "mana" buot ipasabot "unsa man kini?"

Mga Sugyot sa Paghubad:

* Uban nga paagi sa paghubad niini nga pulong pwede ang"nigpis ug puti nga pagkaon" o "pagkaon gikan sa langit.
* Hunahunaa sad kung giunsa kini nga pulong  paghubad sa lokal o nasodnong pinulongan.


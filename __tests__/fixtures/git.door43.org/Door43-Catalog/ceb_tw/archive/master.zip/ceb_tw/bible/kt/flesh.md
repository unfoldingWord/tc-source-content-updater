# Unod

Sa Biblia, ang pulong nga "unod" literal nga nagtumong sa kaunoran sa lawas sa tawo o mananap.

* Migamit sad ang Biblia sa pulong nga "unod" nga sumbingay nga nagtumong sa tanang mga tawo o tanang linalang nga adunay kinabuhi.
* Sa Bag-ong Kasabotan, ang pulong nga "unod" gigamit sa pagtumong sa pagkamakasasala sa mga tawo. Kasagaran kining gigamit nga nagtandi sa ilang espirituhanong bahin. 
* Ang sumbingay nga, "kaugalingong unod ug dugo" nagtumong sa usa ka tawo nga kadugo sa usa ka tawo, sama sa ginikanan, mga igsoon, anak, o apo.
* Ang sumbingay nga "unod ug dugo" nagtumong sad sa katigulangan sa usa ka tawo o mga kaliwat.
* Ang mga pulong nga, "usa ka unod" nagtumong sa pisikal nga panaghiusa sa lalaki ug babaye sa kaminyoon.

Mga Sugyot sa Paghubad

* Sa konteksto sa lawas sa mananap, ang "unod" pwede hubaron nga "lawas" o "panit" o "karne."
* Kung gigamit sa kinatibuk-an nga nagtumong sa tanang mga adunay kinabuhi nga mga linalang, kini nga pulong pwede hubaron nga “mga buhing linalang" o "tanan nga mga buhi."
* Kung kinatibuk-ang nagtumong sa mga tawo, kini nga pulong pwede hubaron nga "katawhan" o "mga tawo" o "tanan nga adunay kinabuhi."
* Ang sumbingay nga, "unod ug dugo" pwede hubaron nga "paryente" o "pamilya" o "kadugo" o "banay sa pamilya." Aduna say konsteksto sa diin pwede kini hubaron nga "mga katigulangan" o "kaliwat."
* Sa ubang mga pinulongan basin adunay sumbingay nga parehas ang ipasabot sa "unod ug dugo."
* Ang sumbingay nga, "mahimong usa ka unod" pwede hubaron nga, "nahiusa sa sekswal" o "mahimong usa ka lawas" o "mahimong usa ka tawo sa lawas ug espiritu." Tan-awa gyud nga ang hubad niini nga sumbingay aron sigurado nga sakto kini sa pinulongan ug kultura nga ihubad.


# Kedesh

Ang Kedesh siyudad sa Canaan nga gisakop sa mga Israelita sa dihang misulod sila sa Canaan.

* Ang Kedesh naa sa amihanang bahin sa teritoryo sa Israel ug gihatag kini sa tribu ni Naptali.
* Ang Kedesh gigahin nga siyudad nga taguanan adtong nakapatay nga wala nila tuyoa ug dinhi sad ang mga paring Levita namuyo.


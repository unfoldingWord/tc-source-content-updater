# Magtutudlo

Ang pulong nga "Magtutudlo" literal nga nagpasabot sa, "akong agalon" o "akong magtutudlo."

* Titulo kini sa pagtahod nga gigamit sa pagtagad sa lalaki nga Judio nga magtutudlo sa relihiyon, hilabi na sa magtutudlo sa mga balaod sa Dios.
* Usahay parehas nga gitawag si Jesus ug Juan Bautista nga "Magtutudlo" sa ilang mga disipulo.

Mga Sugyot sa Paghubad

* Ang pamaagi sa paghubad niini nga pulong pwede sad ang, "Akong Agalon" o "Akong Magtutudlo"o "Halangdong Magtutudlo " o "Magtutudlo sa Relihiyon." Ang ubang mga pinulongan pwede nga dakoon ang unang letra niini nga titulo kung gigamit kini sa pag-abi-abi, samtang ang uban dili nila kini himoon.
* Ang pinulongan nga hubaron pwede nga aduna say pinasahi nga pamaagi nga kasagarang gigamit sa pagtagad sa magtutudlo.
* Siguraduha gyud nga ang hubad niini nga pulong dili mogawas nga si Jesus usa ka magtutudlo sa eskuwelahan.
* Hunahunaa sad kung giunsa paghubad ang "Magtutudlo" sa Biblia sa hubad nga duol sa pinulongan o nasudnong pinulongan.


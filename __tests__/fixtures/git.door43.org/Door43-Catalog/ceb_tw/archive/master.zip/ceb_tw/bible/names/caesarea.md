# Cesarea

Importante nga siyudad ang Cesarea sa kabaybayonan sa Dagat sa Mediteraneo, mga 39 kilometro habagatan sa bukid nga Carmel ug mga 120 kilometro amihang-kasadpan sa Jerusalem.

* Ang Cesarea nahimong kapital nga siyudad sa probinsiya nga Judea nga gisakop sa mga taga Roma sa panahon nga gipanganak si Jesus.

Si apostol Pedro unang nagwali sa mga Gentil sa Cesarea.
Si Pablo naglayag gikan sa Cesarea ngadto sa Tarso ug miaagi sad niini nga siyudad sa duha ka mga biyahe niya isip misyonero.


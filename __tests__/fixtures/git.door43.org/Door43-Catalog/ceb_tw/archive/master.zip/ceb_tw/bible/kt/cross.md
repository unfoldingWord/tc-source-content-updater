# krus

Sa panahon sa Biblia, ang krus usa ka kahoy nga poste nga giugbok sa yuta nga adunay kahoy nga gababag sa ibabaw.

* Sa panahon sa Empiryo sa Roma, patyon sa gobyerno sa Roma ang mga kriminal pinaagi sa paghigot o paglansang kanila sa krus unya ibilin sila didto hangtod nga mamatay.
* Sayop nga gipasanginlan si Jesus ug mga krimen nga wala niya gibuhat ug gipatay siya sa mga Romano sa krus.
* Timan-i nga kini nga pulong lahi gyud nga pulong sa berbo nga "cross" sa Ingles, nga nagpasabot sa pagtabok sa pikas kilid sama sa suba o lawa.

Mga Sugyot sa Paghubad:

* Kini nga pulong mahimong hubaron nga gamiton ang pulong sa pinulongan nila nga maghulagway sa porma sa krus.
* Hunahunaa kung mahimong ihulagway ang krus nga butang diin didto patyon ang mga tawo, sama sa "poste sa pagpatay" o "kahoy sa kamatayon."
* Hunahunaa sad kung giunsa paghubad niini nga pulong  sa Biblia sa lokal o nasudnong pinulongan.


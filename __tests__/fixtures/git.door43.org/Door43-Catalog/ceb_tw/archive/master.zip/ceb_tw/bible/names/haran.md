# Haran

Si Haran mao ang manghod ni Abraham ug amahan ni Lot.

* Haran sad ang ngalan sa lungsod diin nagpuyo kadali lang si Abram ug ang iyang pamilya samtang nagbyahe sila gikan sa siyudad sa Ur ngadto sa Canaan.


# Ceretihanon

Ang Ceretihanon mga tawo nga tingali nagpuyo sa parte sa Filistia. Gisulat sad nga "Keritihanon" sa ubang dapit.

* Uban nga paggamit niini nga pulong dunay koneksyon sa Peletihanon, nga nagtumong sa espisyal nga mga sundalo gikan sa kasundalohan ni Haring David nga diin gigahin kini sila aron magbantay kaniya.
* Si Benaia, anak nga lalaki ni Jehoiada, nga membro sa sinaligan nga mga corporal ni David, mao ang pangulo sa Ceretihanon ug mga Peletihanon.
* Ang mga Ceretihanon nagpabilin nga kauban ni David sa dihang kinahanglan niya nga mopalayo sa Jerusalem tungod sa pagrebilde ni Absalom.


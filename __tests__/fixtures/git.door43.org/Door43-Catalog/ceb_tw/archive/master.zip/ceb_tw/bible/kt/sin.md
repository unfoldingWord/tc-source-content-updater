# sala, makasasala, pagpakasala

Ang pulong nga "sala" nagtumong sa mga binuhatan, hunahuna, ug pulong nga batok sa kabubut-on ug balaod sa Dios. Ang sala pwede sad magtumong sa wala pagbuhat sa butang nga gusto sa Dios nga buhaton nato.

* Ang sala moa ang bisan unsa nga atong gibuhat nga wala mituman o wala makapahimuot sa Dios, bisan ang mga butang nga wala mahibaloi sa ubang tawo.
* Ang mga hunahuna ug binuhatan nga misupak sa kabubut-on sa Dios gitawag nga "makasasala."
* Tungod kay nakasala si Adan, ang tanang tawo nga natawo adunay makasasala nga kinaiya nga maoy nagmando kanila. Usahay ang pulong nga "sala" nagtumong niini nga makasasalang kinaiya. Gitawag sad kini nga "unod" sa Biblia.
* Ang "makasasala" mao ang tawo nga makasala mao nga kini nga pulong pwede gamiton sa matag tawo.
* Usahay, ang pulong nga "mga makasasala" gigamit sa mga relihiyosong tawo sama sa mga Pariseo aron magtumong sa mga tawo nga dili makatuman sa balaod sumala sa ilang kinahanglan buhaton matod sa mga Pariseo.
* Ang pulong nga "makasasala" gigamit sad aron magtumong sa mga tawo nga giisip nga mas makasasala pa kaysa ubang tawo. Pananglitan, gigamit kini nga tawag alang sa mga tigkolekta ug buhis ug mga babayeng nagbaligya ug dungog.

Mga Sugyot sa Paghubad:

* Ang pulong nga "sala" pwede hubaron sa pulong nga nagpasabot nga "dili pagtuman sa Dios" o "pagsupak sa kabubut-on sa Dios" o "dautang batasan o hunahuna."
* Ang "pagpakasala" pwede sad hubaron nga "dili pagtuman sa Dios" o "pagbuhat ug sayop."
* Depende sa konteksto, ang pulong nga "makasasala" pwede hubaron sa mga pulong nga nagpasabot nga "tawo nga nakasala" o "tawo nga nagbuhat ug sayop nga mga butang" o "tawo nga wala mituman sa Dios" o "tawo nga wala mituman sa balaod."
* Ang pulong nga "mga makasasala” pwede hubaron sa pulong nga nagpasabot nga "makasasala kaayo nga mga tawo" o "mga tawo nga giisip nga mga makasasala gyud" o "imoral nga mga tawo."
* Ang mga pamaagi sa paghubad sa mga "tigkolekta ug buhis ug mga makasasala" pwede nga "tawo nga mokolekta ug kwarta alang sa gobyerno, ug uban pang makasasala gyud nga mga tawo" o "makasasala gyud nga mga tawo, apil ang mga tigkolekta ug buhis."


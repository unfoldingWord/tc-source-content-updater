# Gibea

Ang Gibea ngalan sa siyudad nga makita sa amihang dapit sa Jerusalem ug habagatan sa Bethel.

* Ang Gibea naa sa yuta nga sakop sa tribo ni Benjamin.
* Lugar kini sa dagkong gubat sa mga Benjamihanon ug sa mga Israelita.


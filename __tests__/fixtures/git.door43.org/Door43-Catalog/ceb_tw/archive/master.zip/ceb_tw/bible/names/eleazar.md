# Eleazar

Sa Biblia, adunay pipila ka mga lalaki nga gingalan ug Eleazar.

* Si Eleazar ang ikatulo nga anak nga lalaki ni Aaron nga igsoon ni Moises. Kadtong namatay na si Aaron, si Eleazar ang nahimong kinatas-ang pari sa Israel.
* Eleazar sad ang ngalan sa usa sa mga gitawag nga "mga kusgan nga katawhan" ni David.
* Ang usa pa nga Eleazar mao ang usa sa katigulangan ni Jesus.


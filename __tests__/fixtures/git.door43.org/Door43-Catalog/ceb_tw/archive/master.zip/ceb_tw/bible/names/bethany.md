# Betania

Ang lungsod sa Betania naa sa tiilang dapit sa sidlakang kilid sa bukid sa Olivo, nga wala pay 2 ka milyas sidlakan sa Jerusalem.

* Ang Betania duol sa dalan nga tunga-tunga sa Jerusalem ug Jerico.
* Ang mga suod nga higala ni Jesus nga si Lazaru, si Marta, ug si Maria nagpuyo sa Betania.
* Sa daghan nga mga panahon, si Jesus nagpalagpas ug gabii sa Betania.
* Ang Betania nailhan kaayo nga lugar nga diin gibanhaw ni Jesus si Lazaru gikan sa pagkamatay.


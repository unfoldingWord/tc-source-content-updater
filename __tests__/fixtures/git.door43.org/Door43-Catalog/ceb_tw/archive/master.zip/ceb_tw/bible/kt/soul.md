# kalag

Ang kalag mao ang naa sa sulod, dili makita ug walay katapusan nga parte sa usa ka tawo. Nagtumong kini sa dili makita nga parte sa tawo ug nagpasabot nga "espiritu."

* Ang mga pulong nga "kalag" ug "espiritu" pwede nga adunay duha ka lainlaing mga konsepto o pwede sad nagtumong sa parehas nga konsepto.
* Ang mga tawo lang ang adunay mga kalag; walay pakisayran sa mga mananap nga aduna silay mga kalag.
* Kung ang usa ka tawo mamatay, ang iyang kalag mobiya sa iyang lawas.
* Ang pulong nga "kalag" usahay gigamit nga nagtumong sa usa ka tawo. Pananglitan, "ang kalag nga makasasala" nagpasabot nga usa ka tawo nga makasasala" ug ang "naluya ang akong kalag" nagpasabot nga "gikapoy ako."

Mga Sugyot sa Paghubad:

* Ang pulong nga "kalag" pwede sad hubaron nga "sulod nga pagkatawo."
* Sa pipila ka mga konteksto, "ang akong kalag" pwede hubaron nga "Ako."
* Kasagaran ang pulong nga "ang kalag" pwede hubaron nga "ang usa ka tawo" o "siya" o "niya," depende sa konteksto.
* Sa pipila ka mga pinulungan tingali adunay usa lang nga pulong sa paghubad sa mga pulong nga "kalag" ug "espiritu."
* Sa Hebreo 4:12, ang sumbingay sa mga pulong nga "magtunga sa kalag ug sa espiritu" pwede magpasabot nga "mailhan pag-ayo ug pagpakita sa tinuod nga kinaiya sa usa ka tawo."


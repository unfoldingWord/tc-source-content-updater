# Cornelio

Si Cornelio usa ka lalaking dili Judio nga opisyal sa militar sa Romanong kasundalohan.

* Kanunay siyang gaampo sa Dios ug manghinatagon sa mga pobre.
* Pagkadungog ni Cornelio ug sa iyang pamilya kang apostol Pedro nga nagpahayag sa maayong balita, nahimo silang mga tumutuo kang Jesus.
* Si Cornelio ug ang mga tawo sa iyang panimalay ang unang mga dili Judio nga nahimong mga tumutuo.
* Ang pagkakabig ni Cornelio sa pagtuo nagpakita nga si Jesus mianhi aron luwason sad ang mga dili Judio.


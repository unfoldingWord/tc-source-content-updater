# adlaw sa paghukom

Ang pulong nga "adlaw sa paghukom" nagtumong sa moabot nga panahon nga  hukman sa Dios ang matag tawo.

* Gihimo sa Dios ang iyang anak nga si Jesu Cristo nga hukom sa tanang mga tawo.
* Sa adlaw sa paghukom, maghukom si Cristo sa mga tawo pinaagi sa iyang matarong nga kinaiya.

Mga Sugyot sa Paghubad

* kini nga pulong pwede sad hubaron nga "panahon sa paghukom' tungod kay pwede kini nagtumong sa labaw pa sa usa ka adlaw.
* Ang ubang pamaagi sa paghubad niini nga pulong pwede sad, "ang ulahing panahon ang Dios maghukom sa tanan nga mga tawo."
* Gisulat nga kapital kini nga pulong sa ubang hinubaron aron sa pagpakita nga kini ngalan sa pinasahi nga adlaw o panahon: "Adlaw sa Paghukom" o "Panahon sa Paghukom."


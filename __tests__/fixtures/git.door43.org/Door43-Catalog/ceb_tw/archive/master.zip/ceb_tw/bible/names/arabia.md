# Arabia, taga-Arabia

Ang Arabia ang labing daku nga dawis sa kalibutan nga adunay sukod nga hapit mag 3,000,000 kilometro kwadrado. Naa kini sa habagatan sa Israel, tunga tunga sa gitawag nga Pula nga Dagat ug gitawag nga "Persian Gulf".

* Sumala kang Apostol Pablo, ang bukid sa Sinai naa sa Arabia.
* Ang anak ni Abraham nga si Ismael ug ang iyang mga kaliwat nagpuyo dapit sa amihan-kasadpan sa Arabia.
* Human nga gipanguluhan ni Moises ang mga Israelita nga nigawas sa Ehipto, naglibotlibot sila sa 40 ka tuig sa disyerto sa Arabia.
* Human nga nahimong tumutuo si Pablo kang Jesus, nipuyo siya ug pipila ka tuig sa disyerto sa Arabia.


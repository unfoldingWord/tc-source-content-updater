# Abiatar

Si Abiatar mao ang kinatas-ang pari sa nasod sa Israel sa panahon ni Haring David ug Haring Solomon. 

* Nag-alagad si Abiatar kauban ang pari nga si Zadok. 
* Kaniadtong gipamatay ni Haring Saul ang mga pari, miikyas si Abiatar ug miadto kang David nga tua sa kamingawan. 
* Human sa pagkamatay ni David, nisupak si Abiatar ni Solomon pinaagi sa pagtabang kang Adonias sa pagsulay sa pag-ilog sa gingharian ni Solomon. 
* Tungod niini, gitangtang ni Solomon si Abiatar sa pagkapari. 

(Tan-awa sad ang: [[rc://ceb/obe/other/zadok]], [[rc://ceb/obe/other/saul]])]], [[rc://ceb/obe/other/david]], [[rc://ceb/obe/other/solomon]], [[rc://ceb/obe/other/adonijah]])


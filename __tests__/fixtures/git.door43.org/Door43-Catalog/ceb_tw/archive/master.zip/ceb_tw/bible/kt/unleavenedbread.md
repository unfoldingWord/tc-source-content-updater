# pan nga walay patubo

Ang pan nga walay patubo giluto nga walay levadura, o uban pang mga pampatubo.

* Sa Daang Kasabotan, ang pan nga walay patubo labing ilado sa panahon nga giingnan sa Dios ang mga Israelita sa paghawa ug dalidali sa Ehipto nga dili na maghulat sa ilang pan nga moalsa. Sukad niadto nga panahon, gigamit na ang pan nga walay patubo sa ilang tinuig nga Kasaulogan sa Pagsaylo sa ilang paghinumdom kung giunsa nila pag-ikyas nga gadalidali gikan sa Ehipto.
* Gigamit ni apostol Pablo ang pulong nga sumbingay nga "pan nga walay patubo" aron awhagon ang mga kaubanang tumutuo sa pagpanginabuhi nga kinasingkasing ug matinud-anon sa uban.
* Sama nga ang pan nga adunay patubo naghulagway sa presinsya sa sala ug daan nga pamaagi sa pagkinabuhi, ang pan nga walay patubo naghulagway sad sa pagtangtang sa sala ug pagkinaubhi sa pamaaagi nga nagpasidungog sa Dios.

Mga Sugyot sa Paghubad

* Ang ubang pamaagi sa paghubad niini nga pulong pwede sad, "pan nga walay levadura" o "lapad nga pan nga wala moalsa."
* Siguraduha gyud nga dili mausab ang paghubad niini nga pulong kung giunsa nimo paghubad ang pulong nga "adunay patubo."


# demonyo, dautan nga espiritu, dili hinlo nga espiritu

Kining tanan nga mga pulong nagtumong sa mga demonyo nga mga espiritu nga nagsupak sa kabubut-on sa Dios.

* Gilalang sa Dios ang mga anghel aron mag-alagad kaniya. Sa dihang ang yawa nagrebelde batok sa Dios, ang pipila ka mga anghel nagrebelde sad ug gipahawa gikan sa langit. Gituohan nga ang mga demonyo ug daotan nga mga espiritu mao kining mga "nangahagbong nga mga anghel."
* Usahay kini nga mga demonyo gitawag nga "dili hinlo nga espiritu." Ang pulong nga "dili hinlo" nagpasabot nga "dili putli" o "daotan" o "dili balaan."
* Tungod kay ang mga demonyo nag-alagad sa yawa, nagbuhat sila sa daotan nga mga butang. Usahay nagpuyo sila sulod sa mga tawo ug gimanduan sila.
* Ang mga demonyo mas gamhanan kaysa mga tawo, apan dili sama sa pagkagamhanan sa Dios.

Mga Sugyot sa Paghubad

* Ang pulong nga "demonyo" mahubad sad nga "daotan nga espiritu."
* Ang pulong nga "dili hinlo nga espiritu" mahubad sad nga "dili putli nga espiritu" o "makadaot nga espiritu" o "daotan nga espiritu."
* Siguraduha nga ang pulong o mga pulong nga gigamit sa paghubad niini nga pulong lahi sa pulong nga nagtumong sa yawa.
* Hunahunaa sad kung giunsa paghubad ang pulong nga "demonyo" sa lokal o nasudnong pinulongan.


# Pulong sa Dios, Pulong ni Yahweh, Pulong sa Ginoo, Kasulatan

Ang mga pulong nga "pulong sa Dios" nagtumong sa bisan unsa nga giingon sa Dios sa mga tawo. Apil niini ang gisulti ug gisulat nga mensahe.

* Paglabay sa daghang katuigan ang mga pulong sa Dios nasulat na, ang mga tawo padayon gihapon sa pagbasa niini nga kasulatan ug makahibalo sa mensahe sa Dios.
* Ang pulong nga "kasulatan" nagtumong sa naisult nga pulong sa Dios nga iyang giingo sa mga tawo nga isulat nila.
* Ang duol nga mga pulong niini nga "pulong ni Yahweh" ug "pulong sa Ginoo" kasagarang nagtumong sa piho nga pulong gikan sa Dios nga gihatag sa mga propeta ug uban pa nga mga tawo sa Biblia.
* Usahay kini mahisgotan nga "ang pulong o "ang akong pulong" o "ang imong pulong” (kung naghisgot kini mahitungod sa pulong sa Dios).
* Sa Bag-ong Kasabotan, gitawag si Jesus nga “ang Pulong" ug "Pulong sa Dios." Kini nga titulo nagpasabot nga si Jesus nagpadayag kung kinsa ang Dios, tungod kay Dios siya.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pamaagi sa paghubad niini nga pulong pwede ang "ang mensahe ni Yahweh" o "mensahe sa Dios" o "ang mga katudluan gikan sa Dios."
* Mas natural siguro sa ubang pinulongan sa paghimo niini nga pulong nga  " mga pulong sa Dios" o ang " mga pulong ni Yahweh.


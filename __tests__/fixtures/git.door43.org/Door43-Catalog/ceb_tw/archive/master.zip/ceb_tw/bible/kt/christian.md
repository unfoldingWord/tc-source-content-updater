# Kristohanon

Pipila ka tuig ang milabay pagkahuman nga miadto na si Jesus sa langit, ang mga tawo gihimo nila ang pulong nga "Kristohanon" nga buot ipasabot, "tigsunod ni Cristo."

* Didto sa siyudad sa Antoquia ang mga alagad ni Jesus unang gitawag nga "mga Kristohanon."
* Ang Kristohanon, tawo nga mituo nga si Jesus anak sa Dios, ug misalig kaniya nga maoy moluwas kaniya gikan sa mga sala.
* Sa atong kapanahonan karon, kasagaran ang pulong nga "Kristohanon" gigamit sa tawo nga membro sa Kristohanong relihiyon, apan wala gyud gasunod kang Jesus. Dili kini mao ang buot ipasabot sa pulong nga "Kristohanon" sa Biblia.
* Tungod kay ang pulong nga "Kristohanon" sa Biblia kanunay kini nga nagtumong sa usa ka tawo nga tinuod ang pagtoo kang Jesus, ang Kristohanon gitawag sad nga "tumutuo."

Mga Sugyot sa Paghubad

* Kini nga pulong pwede hubaron nga "misunod kang Cristo" o "gasunod kang Cristo" o sama sa "tawo nga iya ni Cristo."
* Seguradohon gyud nga ang hubad niini nga pulong lahi sa mga pulong nga gigamit ngadto sa disipulo o apostol.
* Magmatngon sa paghubad niini nga pulong nga nagtumong sa tanang tawo nga mituo kang Jesus, dili lang sa pipila ka mga grupo.
* Tan-awa sad kung giunsa kini paghubad sa Biblia sa lokal o nasudnong nga pinulongn.


# Absalom

Si Absalom mao ang ikatulo nga anak ni Haring David. Nailhan siya tungod sa iyang pagkagwapo ug pagkamasuk-anon.

* Niadtong gilugos ang igsoon ni Absalom nga si Tamar sa ilang igsoon sa amahan nga si Amnon, nagplano si Absalom nga ipapatay si Amnon.
* Human mapatay si Amnon, milayas si Absalom ngadto sa dapit sa Gesur (nga diin gikan iyang inahan nga si Maaca) ug nagpuyo siya didto sulod sa tulo ka tuig. Unya gipabalik siya ni Haring David sa Jerusalem, apan wala niya tuguti si Absalom nga makigkita kaniya sa duha ka tuig.
* Giaghat ni Absalom ang ubang mga tawo nga mosukol kang Haring David ug nangulo siya ug rebelyon batok kang David.
* Nakiggubat ang kasundalohan ni David batok kang Absalom ug napatay siya. Nasubo kaayo si David pagkahitabo niini.


# Artaxerxes

Si Artaxerxes usa ka hari nga naghari sa nasod sa Persia gikan sa mga tuig nga 464- 424 sa wala pa gipanganak si Cristo.

* Sa panahon nga naghari si Artaxerxes, ang mga Israelita gikan sa Juda gipapugos silag puyo sa Babilonia diin sa adto nga panahon kontrolado kini sa Persia.
* Gitugutan ni Artaxerxes si Esdras nga pari ug uban nga mga pangulo sa mga Hudio nga molakaw sa Babilonia ug mobalik sila sa Jerusalem aron itudlo ang Balaod sa Dios sa mga Israelita.
* Pagkahuman niining panahuna, gitugutan sad ni Artaxerxes si Nehemiah nga tigtagay sa iyang bino nga mobalik sa Jerusalem aron sa pagpangulo sa mga Hudio nga magtukod ug balik sa mga paril nga gapalibot sa siyudad.
* Timan-i nga dili kini parehas kang haring Xerxes.


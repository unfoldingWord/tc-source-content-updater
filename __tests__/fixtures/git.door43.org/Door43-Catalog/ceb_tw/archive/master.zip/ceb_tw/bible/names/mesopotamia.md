# Mesopotamia, Aram Naharaim

Ang Mesopotamia mao ang yuta taliwala sa mga Suba sa Tigris ug Eufrates. Ang nahimutangan niini karon mao ang nasod nga Iraq.

* Sa Daang Kasabotan, kini nga dapit gitawag nga "Aram Naharaim."
* Ang pulong nga "Mesopotamia" nagpasabot nga "taliwala sa mga suba." Ang mga pulong nga "Aram Naharaim" nagpasabot nga "sa duha ka suba."
* Si Abraham nagpuyo sa mga siyudad sa Ur ug Haran didto sa Mesopotamia usa pa siya nibalhin sa yuta sa Canaan.
* Ang Babilonia usa sad ka importante nga siyudad sa Mesopotamia.
* Ang rehiyon nga gitawag nga "Caldea" parte sad sa Mesopotamia.


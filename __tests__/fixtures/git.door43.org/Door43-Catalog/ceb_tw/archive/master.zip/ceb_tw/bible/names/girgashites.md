# Gergesehanon

Ang Gergesehanon tribo sa Canaan nga mga kaliwat ni Canaan, nga anak ni Ham nga anak ni Noe.

* Ang Gergesehanon gihisgutan sa pipila ka higayon sa Daang Kasabotan sa listahan sa mga kaliwat ni Noe ug sa iyang tulo ka mga anak.
* Ang Gergesehanon usa sa pipila ka mga grupo sa tawo nga gitawag nga "mga Canaahanon."


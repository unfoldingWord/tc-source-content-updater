# ginoo, agalon, sir

Ang pulong nga "ginoo" nagtumong sa usa ka tawo nga adunay panag-iya o awtoridad labaw sa usa ka tawo.

* Kini nga pulong usahay gihubad nga "agalon" kung nagtumong kang Jesus o sa usa ka tawo nga adunay mga ulipon.
* Sa pipila ka bersiyon sa Ingles gihubad kini nga "sir" sa konteksto nga diin ang usa ka tawo matinahuron nga nagpasidungog sa usa ka tawo nga mas taas ang kahimutangan.

Mga Sugyot sa Paghubad:

* Kini nga pulong kinahanglan hubaron nga "agalon” kung kini nagtumong sa tawo nga adunay panag-iya nga mga ulipon. Pwede sad kini gamiton sa usa ka ulipon kung kasulti niya ang tawo nga iyang gi-alagaran.
* Kung kini nagtumong kang Jesus, pwede kini hubaron nga "agalon" kung ang konteksto nagpakita nga ang buot ipasabot "magtutudlo sa relehiyon."
* Kung ang tawo makigsulti kang Jesus apan wala makaila kaniya nga "Ginoo" pwede hubaron lang nga "sir." Kini nga hubad pwede sad gamiton sa uban nga mga konteksto sa pagtumong nga matinahuron nga makigistorya ngadto sa gitawag nga tawo.  
* Kung nagtumong sa Dios nga Amahan o kang Jesus, kini nga pulong gisulat nga "Ginoo."


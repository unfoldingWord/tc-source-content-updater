# balaod, balaod ni Moises, balaod sa Dios, balaod ni Yahweh

Kining tanan nga mga pulong nagtumong sa mga sugo ug mga pahimatngon nga gihatag sa Dios kang Moises aron tumanon sa mga Israelita. Ang pulong nga "balaod" ug ang "balaod sa Dios" gigamit sad kasagaran nga nagtumong sa tanan nga mga butang nga buot sa Dios nga tumanon sa iyang katawhan.

* Depende sa konteksto, ang "balaod" pwede magtumong sa:
* Napulo ka mga Sugo nga gisulat sa Dios sa mga papan nga bato alang sa mga Israelita.
* ang tanan nga balaod nga gihatag kang Moises
* ang unang lima ka libro (ni Moises) sa Daang Kasabotan.
* ang kinatibuk-an sa Daang Kasabotan (gitumong sad nga "kasulatan" sa Bag-ong Kasabotan).
* tanan nga pahimatngon ug kabubut-on sa Dios.
* Ang mga pulong nga “ang balaod ug mga propeta" gigamit sa Bag-ong Kasabotan nga nagtumong sa Hebreo nga kasulatan (o "Daang Kasabotan").

Mga Sugyot sa Paghubad

* Kini nga mga pulong pwede sad hubaron gamit ang "mga balaod" kay sila nagtumong man sa daghan nga mga pahimatngon.
* Ang "balaod ni Moises" pwede hubaron nga "mga balaod nga giingon sa Dios kang Moises nga ihatag sa mga Israelita."
* Depende sa konteksto, "ang balaod ni Moises" pwede hubaron nga "balaod nga giingon sa Dios kang Moises" o "mga balaod sa Dios nga gisulat ni Moises" o "ang mga balaod nga giingon sa Dios kang Moises nga ihatag sa mga Israelita."
* Mga paagi sa paghubad sa "ang balaod" o "mga balaod sa Dios" pwede sad ang "mga balaod gikan sa Dios" o "mga sugo nga gihatag sa Dios" o "tanan nga butang nga gisugo sa Dios" o "tanan nga mga pahimatngon sa Dios."
* Ang mga pulong nga "balaod ni Yahweh" pwede hubaron nga "mga balaod ni Yahweh" o "mga balaod nga giingon ni Yahweh nga tumanon" o "mga balaod gikan kang Yahweh" o "mga gisugo ni Yahweh."


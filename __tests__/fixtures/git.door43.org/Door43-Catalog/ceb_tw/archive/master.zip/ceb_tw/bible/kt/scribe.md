# eskriba, mga eksperto sa balaod sa mga Judio

Ang mga eskriba mga opisyales nga ang katungdanan mao ang pagsulat o pagkopya sa mga importante nga dokumento sa gobyerno o relihiyon.

* Ang mga eskriba mao ang responsable sa pagkopya ug pagpatunhay sa mga libro sa Daang Kasabotan.
* Ang mga eskriba sad ang nagkopya, nagpatunhay ug nagpasabot sa mga relihiyosong opinyon ug komentaryo mahitungod sa balaod sa Dios.
* Usahay, ang mga eskriba mga importante nga opisyal sa gobyerno.
* Apil sa mga importanteng eskriba nga gihisgotan sa Biblia sila Baruc ug Esdras.


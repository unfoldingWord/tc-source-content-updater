# mira

Ang mira usa ka pahumot nga gihimo gikan sa tagok sa kahoy.

* Ang mira gigamit nga insenso, pahumot, ug pahumot alang sa pag-andam sa mga patay nga lawas aron ilubong.
* Ang mira usa sa mga gasa nga gihatag sa mga maalamong lalaki kang Jesus niadtong natawo siya.
* Gihatagan si Jesus ug bino nga adunay gisagol nga mira aron mamenosan ang sakit niadtong gilansang siya sa krus.


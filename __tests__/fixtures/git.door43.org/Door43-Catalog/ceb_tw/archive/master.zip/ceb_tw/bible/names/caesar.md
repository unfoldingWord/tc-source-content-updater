# Cesar

Ang Cesar apelyedo kini. Ang usa ka tawo nga ginganlan Agusto Cesar nahimong unang tagapagmando sa imperyo sa Roma. Tungod kaniya, ang "Cesar" nahimo sad nga titulo nga gihatag sa mga tagamando sa imperyo sa Roma.

* Si Agusto Cesar mao ang tagamando sa imperyo sa Roma niadtong gipanganak si Jesus.
* Si Tiberius Cesar ang tagamando niadtong hamtong na si Jesus.
* Kung gamiton ang "Cesar” ingon nga titulo, pwede kini hubaron nga "Hari" o "Emperador" o "Czar" o "Kaiser"
* Kung ang "Cesar" gamiton nga apelyedo pwede lang kini hubaron nga "Cesar."


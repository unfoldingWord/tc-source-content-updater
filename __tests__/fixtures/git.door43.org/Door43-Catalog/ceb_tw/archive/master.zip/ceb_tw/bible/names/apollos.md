# Apolos

Si Apolos usa ka Judio gikan sa siyudad sa Alexandria sa Gresya. Daghan sad siyang nahibaw-an mahitungod sa kasulatan sa Hebreo ug maayo kaayo mosulti nga madani ang mga mamati.

* Gitudluan si Apolos sa duha ka kristiyano diha sa Efeso nga si Aquila ug Priscilla.
* Gihatagan ni Pablo ug importansiya kung giunsa niya (Pablo), ni Apolos, ug ang uban nga mga magtutudlo nga kabahin sila sa grupo nga nagkuyog nga nagtrabaho sa ani sa Dios.


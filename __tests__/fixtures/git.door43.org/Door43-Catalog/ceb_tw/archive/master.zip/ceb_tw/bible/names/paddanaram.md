# Paddan Aram

Ang Paddan Aram usa ka ngalan sa rehiyon diin nagpuyo ang pamilya ni Abraham usa sila mibalhin sa Canaan.

* Ang pamilya sa igsoon nga lalaki ni Abraham nga si Nahor nagpabilin sa Paddan Aram. Ilado sila nga mga "taga-aram" ug ang ilang mga pinulungan gitawag sa Ingles nga "Aramaic."
* Ang siyudad nga Haram makita sa Paddan Aram ug mao kini ang lugar diin nagpuyo ang igsoon nga lalaki ni Rebecca nga si Laban.
* Ang Paddan Aram tingali makita sa rehiyon sa Siria karong panahona o sa habagatang-sidlakan sa Turkey.


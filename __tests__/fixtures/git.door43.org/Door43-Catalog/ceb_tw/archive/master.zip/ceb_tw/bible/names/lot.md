# Lot

Sa Biblia, si Lot pag-umangkon nga lalaki ni Abraham.

* Si Lot ang gigikanan sa mga Moabitanhon ug mga Amonihanon.


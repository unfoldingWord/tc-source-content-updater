# Beelzebu

Si Beelzebu pangulo sa mga demonyo ug lain nga ngalan ni Satanas.

* Si Beelzebu gisulat nga Beelzebub sa ubang mga bersiyon sa Biblia.
* Si Beelzebu pwede sad hubaron nga "Satanas" o "yawa" o "ang dautan."


# Etiopia

Ang Etiopia usa ka nasod sa Africa nga naa sa habagatan sa Ehipto, nga giutlanan sa kasadpanan sa suba nga Nile ug sa sidlakan sa Dagat nga Pula.
Ang tawo nga gikan sa Etiopia gitawag ug taga-Etiopia.

* Ang Etiopia adtong una pa kaayong panahon nahimutang sa habagatan sa Ehipto ug lakip niini ang yuta nga karon kabahin na sa pipila ka mga moderno nga mga nasod sa Africa, sama sa Sudan, moderno nga Etiopia, Somalia, Kenya, Uganda, Sentrong Republika sa Africa, ug Chad.
* Sa Biblia, ang Etiopia usahay gitawag ug "Cush" o "Nubia."
* Ang nasod sa Etiopia ('Cush') ug Ehipto kanunay nga gihisgutan sa Biblia, tungod kay duol ra sila sa usa'g-usa ug ang ilang mga katawhan susama siguro ug gigikanan.
* Gipaadto sa Dios si Felipe nga evangilista sa usa ka kamingawan aron siya magsangyaw sa maayong balita mahitungod kang Jesus sa usa ka eunoco nga taga Etiopia.


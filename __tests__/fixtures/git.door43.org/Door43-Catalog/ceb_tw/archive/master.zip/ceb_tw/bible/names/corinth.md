# Corinto, taga-Corinto

Ang Corinto usa ka siyudad sa Gresya nga mga 50 ka milya sa kasadpanan sa Atens. Ang mga taga-Corinto mao ang mga tawo nga nagpuyo sa Corinto.

* Ang Corinto mao ang lugar diin nagpuyo ang usa sa mga unang kristohanong iglesia.
* Ang mga libro sa Bag-ong Kasabotan nga 1 ug 2 Taga-Corinto gisulat alang sa iglesia sa Corinto.
* Sa iyang unang pagbyahe isip misyonero, nagpuyo si Pablo sa Corinto sulod sa mga 18 ka bulan.
* Nagkita sila Pablo ug Aquila ug Priscila samtang didto si Pablo sa Corinto.
* Ang ubang mga unang pangulo sa iglesia nga adunay kalabotan sa Corinto mao sila Timoteo, Tito, Apolos, ug Silas.


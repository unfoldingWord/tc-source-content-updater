# Josue

Adunay pipila ka mga tawo sa Israel sa panahon sa Biblia nga Josue ang mga ngalan. Ang labing ilado nga Josue ang anak ni Nun nga katabang ni Moises ug sa kadugayan nahimong importanteng pangulo sa katawhan sa Dios.

* Usa si Josue sa dose ka mga espiya nga gipadala ni Moises sa pag-usisa sa Gisaad nga Lugar.
* Uban ni Caleb, nagpakita ug kaisog ug pagsalig sa Dios si Josue sa iyang pagdasig sa mga Israelita sa pagtuman sa mando sa Dios sa pagsulod sa Gisaad nga Lugar ug gipilde ang mga Canaanon.
* Paglabay sa daghang katuigan, paghuman ni Mioses namatay, gipili sa Dios si Josue sa pagpangulo sa mga tawo sa Israel paadto sa Gisaad nga Lugar.
* Sa una ug labing inila nga pakiggubat batok sa mga Canaanon, si Josue ang nangulo sa Israelita sa pagpilde sa siyudad sa Jerico, sama sa giingon sa Dios kaniya.
* Sa Daang Kasabotan sa libro ni Josue gisulat ang mahitungod sa mga panghitabo sa panahon sa pagpangulo ni Josue, apil ang pagsakop sa Gisaad nga Lugar ug sa pagbahinbahin sa yuta sa tribu sa Israel.
* Adunay lain nga Josue nga gihisgutan sa Daang Kasabotan sa libro ni Hageo ug Zacarias. Kini nga Josue usa ka kinatas-ang pari nga mitabang sa pagtukod pag-usab sa parel sa Jerusalem. Anak siya ni Josadak.


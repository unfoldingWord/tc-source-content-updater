# Walay pagtuo

Ang pulong nga "walay pagtuo" nagpasabot sa walay pagtuo o wala mituo.

* Kini nga pulong gigamit sa paghulagway sa mga tawo nga wala mituo sa Dios nga makita sa ilang imoral nga binuhatan.
* Gi-akusahan ni propeta Jeremias ang mga Israelita sa walay pagtuo ug sa dili pagtuman sa Dios.
* Nagsimba sila ug mga diosdiosan ug misunod sa ubang dili diosnong batasan sa ubang mga katawhan nga wala magsimba o magtuman sa Dios.

Mga Sugyot sa Paghubad

* Depende sa konteksto ang, "walay pagtuo" pwede hubaron nga "maluibon" o "dili magtutuo" o "masupilon sa Dios" o " dili motuo."
* Ang pulong nga "walay pagtuo" pwede hubaron nga "dili motuo" o "dili matinumanon" o "masinopakon sa Dios."


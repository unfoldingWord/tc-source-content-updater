# salmo

Sagrado nga alawiton ang salmo, kasagaran balak nga adunay musika. Ang libro sa Daang Kasabotan nga Mga Salmo adunay koleksyon niini nga mga kanta nga gisulat sa mga Israelita.

* Si Moises ug si Haring David nagsulat sa mga salmo nga gigamit sa nasod nga Israel sa ilang pagsimba sa Dios.
* Ang mga salmo pwede gamiton sa pagpahayag sa kalipay, pagtuo, ug pagtahod, ug mga kasakit ug kaguol.
* Sa Bag-ong Kasabotan, gisugo ang mga Kristohanon sa pagkanta sa mga salmo sa Dios ingon nga pagsimba.


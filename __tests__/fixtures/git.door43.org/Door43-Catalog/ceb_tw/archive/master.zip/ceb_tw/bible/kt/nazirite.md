# Nazareo, Panaad sa mga Nazareo

Kasagaran, ang Nazareo usa ka lalaki nga nanumpa sa panaad sa mga Nazareo. Pwede sad manumpa ang babaye niini nga panaad.

* Ang panaad sa mga Nazareo apil ang paglikay sa bisan unsang ilimnon o pagkaon nga hinimo sa ubas ug dili pagputol sa iyang buhok sulod sa pipila ka gisabotan nga mga adlaw, semana o bulan. Gidili sad siya nga moduol sa patay nga lawas.
* Paglabay sa gikinahanglan nga panahon ug natuman na ang panaad, moadto ang Nazareo sa usa ka pari ug maghatag ug halad. Apil niini ang pagputol ug pagsunog sa iyang buhok. Undangon na sad ang ubang mga gidili.
* Si Samson ilado nga lalaki sa Daang Kasabotan nga usa ka Nazareo.
* Basin si Juan Bautista Nazareo sad niadtong buhi pa siya.
* Posible nga ang apostol Pablo nanumpa sad niini nga panaad.


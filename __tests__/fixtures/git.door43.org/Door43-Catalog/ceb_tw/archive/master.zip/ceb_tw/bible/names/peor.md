# Peor, Bukid sa Peor, Baal sa Peor

Ang Peor mao ang ngalan sa bukid sa rehiyon sa Moab nga naa sa sidlakan sa Asin nga Dagat. Mao sad kini ang lugar nga gipuy-an sa mga tribu ni Reuben.

* Ang ngalan nga "Bet Peor" mao ang lain nga ngalan sa siyudad sa Peor.
* Ang "Baal sa Peor" mao ang diosdiosan sa mga Amobihanon nga ilang gisimba sa Bukid sa Peor.


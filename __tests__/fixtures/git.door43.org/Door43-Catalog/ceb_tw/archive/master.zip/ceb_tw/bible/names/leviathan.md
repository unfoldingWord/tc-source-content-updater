# Leviatan

Ang pulong nga "Leviatan" nagtumong sa dako kaayong mananap nga gihisgutan sa unang mga sulat sa Daang Kasabotan.

* Ang Leviatan gihulagway nga dako kaayong nilalang, kusgan ug makahahadlok ug ang tubig sa palibot niya kaya niyang "pabulaon". Ang hulagway niini daw sama sa mananap nga gitawag ug "dinasaur."
* Si propeta nga Isaias nagtumong sa Leviatan nga "ang bitin nga makalupad." 
* Si Job nagsulat mahitungod sa Leviatan sumala sa iyang kaugalingong kasinatian, pwede nga buhi pa kini nga mananap sa panahon niya.


# paghigugma

Ang paghigugma sa usa ka tawo mao ang pag-atiman adto nga tawo ug paghimo ug mga butang nga mapuslanon alang kaniya. Adunay lainlain nga buot ipasabot sa "paghigugma" nga ang ubang mga pinulongan mogamit ug lainlain nga pulong: 

1. Ang klase sa paghigugma nga gikan sa Dios sentro sa kaayohan sa uban, bisan dili kini mapuslanon sa iyang kaugalingon. Kini nga klase sa paghigugma magatiman sa uban, bisan unsa pa ang ilang nahimo. Ang Dios mismo gugma ug maoy kakuhaan sa tinu-od nga paghigugma.
  * Gipakita ni Jesus kini nga paghigugma pinaagi sa pagsakripisyo sa iyang kinabuhi aron tubuson kita gikan sa sala ug sa kamatayon. Gitudlu-an sad niya ang iyang mga sumusunod nga higugmaon ang uban nga may pagsakripisyo.
  * Kung higugmaon sa usa ka tawo ang uban sama niini nga klase nga paghigugma, uban niini ang mga binuhatan nga nagpakita nga ang usa ka tawo naghunahuna kung unsa ang himuon aron nga ang ubang tawo matabangan o molambo. Kini nga klase sa paghigugma lakip ang pagpasaylo sa sala sa uban.
  * Sa ULB, ang pulong nga "paghigugma" nagtumong sa sakripisyohanon nga klase sa paghigugma sa Dios, gawas kung gisulti sa Translation Notes ang lain nga buot ipasabot niini.
2. Adunay lain nga pulong sa Bag-ong Kasabotan nga nagtumong sa inig-soon nga paghigugma o paghigugma sa higala o miyembro sa pamilya. Natural kini nga paghigugma taliwala sa mga higala ug mga kaigsoonan o paryente.
  * Sa Ingles nga mga pulong nga "they love to sit in the most important seats in the banquet" o "gihigugma nila ang molingkod sa halandong lingkuranan sa kumbira", kini nagpasabot nga sila "mas ganahan" o "gusto nila kaayo" kini ilang buhaton.
3. Ang pulong nga "paghigugma" pwede sad magtumong sa gugma taliwala sa lalaki ug babaye.

Mga Sugyot sa Paghubad:

* Gawas kung gisulti sa "Translation Note" nga adunay lain nga buot ipasbot ang paghigugma, ang pulong nga "paghigugma" sa ULB nagtumong sa sakripisyohanong gugma nga gikan sa Dios.
* Ang uban nga mga pinulongan pwede nga adunay pinasahe nga pulong sa dili makaugalingon nga klase nga paghigugma sa Dios sa katawhan ug gitabangan niya ang katawhan aron himuon sad nila sa uban ang paghigugma. Mga paagi sa paghubad niini pwede ang "matinud-anon nga pag-atiman" o "pag-atiman nga dili makaugalingon" o "paghigugma gikan sa Dios." Siguraduhon nga ang pulong nga gamiton sa paghubad sa paghigugma sa Dios apil ang kinaiya nga dili nakati-on sa kaugalingon nga kahimtang, kalimtan ang kaugalingon alang sa kapuslanan sa uban, ug higugmaon ang uban bisag unsa ang ilang nabuhat.
* Usahay ang Ingles nga pulong nga "love" nagtumong sa pag-atiman pag-ayo sa usa mga tawo alang sa iyang mga higala ug mga miyembro sa pamilya. Ang uban nga pinulongan pwede hubaron kini uban sa pulong o mga pulong nga buot ipasabot, "gusto kaayo" o "mag-amping sa" o "adunay hilabihan nga paghigugma."
* Sa konteksto nga diin ang "paghigugma" gigamit sa pagpakita sa hilabihan nga pagpalabi sa usa ka butang, pagkaon, o kalihokan, pwede kini hubaron pinaagi sa "hilabihan nga pagkagusto" o "gusto kaayo" o "hilabihan nga tinguha."
* Ang uban nga mga pinulongan aduna sad siguro'y lain nga pulong nga nagtumong sa lalom nga pagbati o paghigugma taliwala sa bana ug asawa.
* Daghan nga pinulongan kinahanglan gyud ipahayag ang "paghigugma" pinaagi sa kalihokan. Pananglitan, pwede nilang hubaron ang "mapasiyensyahon ang paghigugma, maluluy-on ang paghigugma" sama sa "dihang ang tawo mahigugma sa usa ka tawo, mapasiyensyahon siya kaniya ug maluluy-on o maayo kaniya."


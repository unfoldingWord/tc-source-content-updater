# Hageo

Hageo ang ngalan sa propeta sa Juda sa panahon nga nibalik ang mga Judio sa Israel gikan sa pagkabihag sa Babilonia.

* Sa panahon niadtong nagtagna si Hageo, si Haring Uzias mao ang naghari sa Juda.
* Gi-awhag ni Hageo ang mga Judio nga magsugod ug tukod pag-usab sa templo.
* Ang libro nga Hageo mao sa Daang Kasabotan kauban sa mga gitawag nga "mugbong kasulatan sa mga propeta."


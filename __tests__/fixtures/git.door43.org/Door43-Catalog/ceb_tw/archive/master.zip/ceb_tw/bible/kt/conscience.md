# konsensya

Ang konsensya mao ang parte sa panghunahuna sa tawo nga diin ipahibalo sa Dios nga nagbuhat siya ug sala. Hatagan siya sa Dios ug pagsabot sa iyang kaugalingon kung unsay sakto ug sayop.

* Naghatag ang Dios sa mga tawo ug konsensya aron tabangan sila sa pagkahibalo sa kalainan sa sakto ug sayop.
* Ang tawo nga mituman sa Dios giingon nga adunay "putli" o "tin-aw" o "hinlo" nga konsensya.
* Kung adunay tawo nga ibali wala ang ilang konsensya ug dili na makonsensiya kung makasala siya, gitawag kini sa Biblia nga "gikubalan" o "walay pagbati" o "hugaw" nga konsensya.
* Kung kinahanglan, pwede hubaron kini nga pulong gamit ug daghang mga pulong nga maghatag ug sama nga pasabot.


# Efraim

Si Efraim ika duha nga anak nga lalaki ni Jose. Ang iyang mga kaliwat, ang Efraimanhon, usa sila sa dose ka mga tribu sa Israel.

* Ang tribu ni Efraim usa sa napulo ka mga tribu nga makita sa norte dapit sa Israel.
* Usahay ang ngalan nga Efraim gigamit sa Biblia nga nagtumong sa tibuok nga gingharian sa norteng bahin sa Israel.
* Ang Efraim kabukiran nga lugar. Pipila sa mga gihubad nagtumong sa "mga bukid sa Efraim."


# Amoz

Si Amoz ang amahan sa propetang si Isaias.

* Ang mga higayon nga gihisgotan siya sa Biblia mao lang ang pag-ila kang Isaias nga "anak ni Amoz."
* Kini nga ngalan lahi sa ngalan ni propetang Amos ug kinahanglan lahi ang pag-ispeling niini.


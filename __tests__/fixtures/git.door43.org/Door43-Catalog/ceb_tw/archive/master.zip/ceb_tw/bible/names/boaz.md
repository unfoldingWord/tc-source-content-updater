# Boaz

Si Boaz bana ni Ruth, kaapu-apuhan ni haring David ug katigulangan ni Jesu Cristo.

* Nabuhi si Boaz sa panahon nga ang Israel adunay pay mga hukom (tunga-tunga sa ika 14 nga siglo ug sa ika 11nga siglo sa wala pa gipanganak si Cristo.)
* "Gitubos" ni Boaz si Ruth, nga balo sa usa ka layo niyang paryente. Hulagway kini sa pagtubos nga gihimo ni Jesus.


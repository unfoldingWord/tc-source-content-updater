# Betuel

Si Betuel anak ni Nahor nga igsoon ni Abraham.

* Si Betuel amahan ni Rebeka ug ang iyang igsoon si Laban.
* Aduna say lungsod nga gitawag ug Betuel nga nahimutang  sa habagatan sa Judea, dili layo sa lungsod sa  Beerseba.


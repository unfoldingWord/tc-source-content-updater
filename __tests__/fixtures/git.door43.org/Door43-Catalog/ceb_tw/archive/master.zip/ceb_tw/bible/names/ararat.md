# Ararat

Sa Bibliya, ang "Ararat" mao ang ngalan sa usa ka lugar, usa ka gingharian ug mga bukid.

* Ang "lugar sa Ararat" posible nga naa dapit sa amihan-timugan sa nasod nga mao karon ang gitawag nga Turkey.
* Ang Ararat maoy giila nga mga bukid diin nidunggo ang arka ni Noe pagkahuman nihunas ang dakong baha.
* Sa panahon karon, ang bukid nga gitawag nga "Bukid sa Ararat" maoy gituohan nga "kabukiran sa Ararat" sa Biblia.


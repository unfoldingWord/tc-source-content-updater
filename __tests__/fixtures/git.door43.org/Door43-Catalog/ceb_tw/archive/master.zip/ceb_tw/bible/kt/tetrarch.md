# gobernador

Ang gobernador mao ang opisyal nga nangulo sa usa ka dibisyon sa Imperyo sa Roma. Ang matag gobernador ubos sa awtoridad sa Imperor sa Roma.

* Ang titulo nga "gobernador" gikan sa kamatuoran nga ang matag gobernador mangulo sa usa sa upat ka mga dibisyon.
* Ang matag dibisyon adunay usa o daghang mga probinsiya sama sa Galilea o Samaria.
* Ang "gobernador" pwede hubaron nga "pangulo."


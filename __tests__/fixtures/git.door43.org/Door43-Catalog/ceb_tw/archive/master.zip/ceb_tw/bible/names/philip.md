# Felipe nga ebanghilista

Sa naunang Kristohanong Iglesia sa Jerusalem, si Felipe mao ang usa sa mga pito ka mga pangulo nga pinili aron ampingan ang mga kabus ug nanginahanglan nga mga Kristohanon, labi na ang mga balo.

* Gigamit sa Dios si Felipe aron magsangyaw sa maayong balita sa mga tawo sa daghang mga lainlaing mga lungsod sa mga probinsiya sa Judea ug Galilea, apil ang taga-Ethiopia nga nasugat niya sa disyerto sa dalan sa Gaza gikan sa Jerusalem.
* Paglabay sa katuigan si Felipe nagpuyo sa Caesarea niadtong si Pablo ug ang iyang mga kauban mipuyo sa ilang balay sa ilang pagbalik didto sa Jerusalem.
* Kadaghanan sa mga tawong maalamon sa Biblia nagtuo nga si Felipe nga ebanghilista dili parehas sa Felipe nga apostol ni Jesus. Ang pipila sa mga pinulungan mas migamit ug lainlaing mga ispeling alang sa mga ngalan sa niining duha ka mga tawo aron maklaro nga dili sila pareho.


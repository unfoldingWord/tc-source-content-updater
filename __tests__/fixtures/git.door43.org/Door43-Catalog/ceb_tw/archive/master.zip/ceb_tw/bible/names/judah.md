# Juda

Si Juda ika-upat sa dose ka mga anak ni Jacob. Ang iyang inahan si Lea.

* Ang mga kaliwat ni Juda nahimong tribu sa Juda.
* Ang pulong nga "Judio" gikan sa ngalan nga "Juda."
* Adtong ang nasod sa Israel natunga paghuman sa paghari ni Solomon, ang gingharian sa Juda nahimutang sa habagatang bahin.


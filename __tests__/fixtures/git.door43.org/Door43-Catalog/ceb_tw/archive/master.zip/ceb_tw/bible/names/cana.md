# Cana

Ang Cana usa ka baryo o lungsod sa probinsiya sa Galilea, mga siyam ka milya amihanan sa Nasaret.

* Ang buot pasabot sa pulong nga "Cana" "lugar sa mga tangbo."
* Ang Cana mao ang lugar nga diin gapuyo si Nathaniel, usa sa dose nga apostol.
* Si Jesus mitambong sa usa ka kasal sa Cana, ug didto gihimo niya ang una niyang milagro o "timaan", diin nga gihimo niya nga bino ang tubig.
* Pagkahuman niadtong panahona, si Jesus mibalik sa Cana ug nakigkita sa usa ka opisyal nga gikan sa Caparnaum nga naghangyo nga ayuhon ang iyang lalaki nga anak.


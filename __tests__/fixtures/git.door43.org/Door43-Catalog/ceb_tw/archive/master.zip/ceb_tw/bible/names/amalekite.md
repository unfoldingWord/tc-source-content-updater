# Amalecahanon

Ang mga Amalecahanon mga grupo sa katawhan nga nagbalhinbalhin sa ilang pagpuyo ug nipanaw sa habagatan nga bahin sa Canaan, gikan sa disyerto sa Negev hangtod sa nasod sa Arabia.

* Kini nga grupo sa katawhan tingali mga kaliwat ni Amalek, ang apo ni Esau.
* Kaaway gyud sa mga Amalecahanon ang Israel sukad niadtong una nga mianha ang mga Israelita sa Canaan aron mopuyo didto.
* Si Saul ug David parehas nga nangulo sa ilang kasundalohan batok sa mga Amalecahanon. Gisupak ni Saul ang Dios pinaagi sa pagtago sa uban nga mga butang nga nahakut nila sa pagkig-away nila sa mga Amalecahanon ug sa wala pagpatay niya sa hari sa mga Amalecahanon nga mao untay gisugo sa Dios kaniya.
* Sa wala magdugay, gipatay sa Dios kining mga tawhana nga kanunay mangawat sa Israel ug sa ubang mga grupo sa katawhan.


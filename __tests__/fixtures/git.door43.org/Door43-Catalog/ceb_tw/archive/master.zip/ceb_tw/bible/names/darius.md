# Dario

Ang Dario ngalan sa pipila ka mga hari sa Persia. Posible nga titulo ang "Dario" imbes nga ngalan.

* Si "Dario nga taga-Media" mao ang hari nga gilimbongan aron ilabay ang propetang si Daniel ngadto sa yungib sa mga leon ingon nga silot niya sa pagsimba sa Dios.
* Si "Dario nga taga-Persia" nitabang sa pagtukod ug balik sa templo sa Jerusalem niadtong panahon ni Esdras ug Nehemias.


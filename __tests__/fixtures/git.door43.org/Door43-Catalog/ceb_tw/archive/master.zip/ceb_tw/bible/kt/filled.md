# napuno sa Balaang Espiritu

Ang pulong nga "napuno sa Balaang Espiritu" usa ka panultihon nga sumbingay nga nagpasabot nga ang Balaang Espiritu naghatag ug gahum sa usa ka tawo aron tumanon niya ang kabubut-on sa Dios.

* Ang mga pulong nga "napuno sa" usa ka sumbingay nga kasagarang nagpasabot nga "kontrolado sa"
* Ang mga tawo "puno sa Balaang Espiritu" kung sila mosunod sa giya sa Balaang Espiritu ug magsalig gyud kaniya sa pagtabang kanila sa pagbuhat kung unsay buot sa Dios.

Mga Sugyot sa Paghubad

* Kini nga pulong pwede hubaron nga, "gihatagan ug gahum sa Balaang Espiritu" o "kontrolado sa Balaang Espiritu." Apan kinahanglan dili murag namugos ang Balaang Espiritu sa tawo sa pagbuhat sa iyang gimando.
* Ang mga pulong sama sa "napuno siya sa Balaang Espiritu" pwede hubaron nga, "nagkinabuhi gyud siya pinaagi sa gahum sa Espiritu" o "gigiyahan gyud siya sa Balaang Espiritu" o "nag-uban gyud kaniya ang Balaang Espiritu."
* Kini nga pulong susama ang gipasabot sa sumbingay nga "magkinabuhi pinaagi sa Espiritu," apan ang "puno sa Espiritu" naghatag ug gibug-aton sa hingpit nga pagtugot sa tawo sa Balaang Espiritu nga sakopon o impluwensyahan ang iyang kinabuhi. Mas maayo gyud nga kini nga duha ka sumbingay hubaron sa lainlain nga pamaagi, kung pwede.


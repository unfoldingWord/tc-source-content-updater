# Babel

Ang Babel usa nga pangulo nga siyudad sa rehiyon nga ginganlag Shinar didto sa habagatang bahin sa Mesopotamia. Sa kadugayan ang Shinar ginganlang Babilonia.

* Ang siyudad nga Babel gitukod sa apo sa tuhod ni Ham nga si Nimrod nga maoy nangulo sa rehiyon sa Shinar.
* Ang mga tawo sa Shinar nahimong mapahitas-on ug nagdesisyon nga magtukod ug taas kaayo nga tore nga abot hangtod langit. Kadugayan nailhan kini nga "Torre sa Babel."
* Tungod kay ang mga tawo nga gatukod sa torre dili gusto nga mokatag sila sama sa gimando kanila sa Dios, gilibog niya ang ilang pinulongan aron dili sila magsinabtanay. Mao kini ang hinungdan nga nagkatibulaag sila sa tibuok kalibutan.
* Ang  pulong nga "Babel" gikan sa pulong nga "kalibog," nga gitawag sa dihang gilibog sa Dios ang pinulongan sa mga tawo.


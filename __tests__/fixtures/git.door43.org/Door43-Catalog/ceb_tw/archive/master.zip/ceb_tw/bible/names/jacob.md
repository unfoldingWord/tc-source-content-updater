# Jacob, Israel

Si Jacob ang kamanghuran sa kaluhang mga lalaking anak ni Isaac ug Rebecca.

* Ang ngalan nga Jacob nagpasabot nga "malimbongon" o "limbonganon."
* Si Jacob marunong ug malimbongon. Nakakita siya ug mga pamaagi aron makuha ang mana nga katungod ug panalangin alang sa kamagulangang anak gikan sa iyang igsoon nga si Esau.
* Nasuko si Esau ug giplano niya nga iyang patyon si Jacob, mao nga gibiyaan ni Jacob ang iyang natawhan nga yuta. Apan wala nagdugay mibalik siya ug nagkinabuhi nga malinawon uban ang iyang igsoon.
* Giusab sa Dios ang ngalan ni Jacob nga Israel, nga nagpasabot "nakigbisog siya sa Dios."
* Nagpadayon ang pakigsabot sa Dios kang Abraham ug sa iyang mga kaliwat gikan sa anak nga lalaki ni Abraham nga si Isaac, hangtod sa anak nga lalaki ni Isaac nga si Jacob.
* Adunay dose ka mga anak nga lalaki si Jacob. Ang ilang mga kaliwat nahimong dose ka mga tribu sa Israel.


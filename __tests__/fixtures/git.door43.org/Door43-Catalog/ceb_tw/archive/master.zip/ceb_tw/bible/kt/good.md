# maayo, pagkamaayo

Ang pulong nga "maayo" adunay lainlain nga mga buot ipasabot depende sa konteksto. Daghang pinulungan mogamit ug lainlain nga mga pulong sa paghubad niini nga lainlain nga mga buot ipasabot. 

* Kasagaran, ang mga butang giingon nga maayo kung motugma kini sa kinaiya, katuyoan, ug kabubut-on sa Dios.
* Ang usa ka butang "maayo" kung kini makapahimuot, maayo kaayo, makatabang, angayan sa usa ka butang, mapuslanon, o "moral nga matarong.
* Ang yuta nga "maayo" pwede tawagon nga "tabunok" o "mabungahon."
* Ang "maayo" nga abot pwede nga "dagaya" nga abot.
* Ang tawo pwede mahimong "maayo" sa iyang gihimo kung hanas sa iyang tahas o trabaho, sama sa "maayo nga mag-uuma."
* Sa Biblia, kasagaran nga buot ipasabot sa "maayo" kasagaran suwahi sa "daotan." Ang pulong nga "pagkamaayo" kasagaran nagtumong sa moral nga pagkamaayo o matarung sa hunahuna ug sa mga buhat.
* Ang pagkamaayo sa Dios nagtumong kung giunsa niya sa pagpanalangin sa iyang katawhan pinaagi sa paghatag kanila ug maayo ug mapuslanon nga mga butang. Pwede sad nga nagtumong kini sa moral nga kahingpitan.

Mga Sugyot sa Paghubad

* Kung unsa ang kasagaran nga pulong sa "maayo" sa pinulungan nga hubaron kinahanglan gamiton gyud kini kung tugma ug natural, labi na sa konteksto nga diin suwahi kini sa daotan.  
* Depende sa konteksto, uban nga paagi sa paghubad niini nga pulong pwede sad ang "kaayo" o "maayo kaayo" o "makapahimuot sa Dios" o "matarung" o "mapuslanon."
* Ang "Maayo nga yuta" pwede hubaron nga, "tabunok nga yuta" o "mabungahon nga yuta"; ang "maayo ang abot" pwede hubaron nga "dagaya nga ani" o "dako ang abot."
* Ang mga pulong nga "magbuhat ug maayo sa" buot ipasabot maghimo ug usa ka butang nga kaayohan sa uban ug pwede sad hubaron nga "magmaayo sa" o "tabang" o "kaayohan" sa usa ka tawo.

.* Depende sa konteksto, mga paagi sa paghubad sa pulong nga "pagkamaayo" pwede sad ang "panalangin" o "kaayohan" o "moral nga kahingpitan" o "pagkamatarong" o "kaputlian."


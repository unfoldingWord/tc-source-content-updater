# tunglo, gitunglo

Ang pulong nga "tunglo" nagpasabot sa paghimo ug paagi aron mahitabo ang dili maayong ngadto sa usa ka tawo o butang nga gitunglo.

* Ang tunglo mahimong pamahayag nga adunay dautan nga mahitabo sa usa ka tawo o butang.
* Ang pagtunglo sa usa ka tawo mahimong pagpahayag sa tinguha nga mahitabo ang dili maayong mga butang kanila.
* Mahimo sad kini magtumong sa pagsilot o ubang dili maayo nga himoon sa usa ka tawo sa lain nga tawo.

Mga Sugyot sa Paghubad:

* Kini nga pulong mahimong hubaron nga “maghimo ug paagi nga adunay dili maayo nga mahitabo kang” o "pagpahayag nga adunay dili maayo nga mahitabo kang" o "manumpa sa pagbuhat ug dautan ngadto kang."
* Sa konteksto sa pagtunglo sa Dios sa iyang masinupakon nga katawhan, mahimo kining hubaron nga, "silotan pinaagi sa pagtugot nga mahitabo ang mga dili maayong mga butang."
* Ang pulong nga "gitunglo" kung gamiton sa paghulagway sa mga tawo, mahimo hubaron nga "gisilotan pag-ayo."


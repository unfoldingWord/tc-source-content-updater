# Ahias

Ahias ang ngalan sa pipila ka lainlaing mga lalaki sa Daang Kasabotan.  Mao kini sila:

* Ahias ang ngalan sa usa ka pari sa panahon ni Saul.
* Ahias sad ang ngalan sa sekretaryo sa panahon nga naghari si Haring Solomon.
* Ahias sad ang ngalan sa propeta gikan sa Silo nga nagtagna nga matunga sa duha ka gingharian ang nasod sa Israel.
* Ahaias sad ang ngalan sa amahan ni Haring Baasa sa Israel.


# Judas Iscariote

Si Judas Iscariote usa sa mga dose ka apostoles ni Jesus. Siya ang nagbudhi kang Jesus sa mga pangulo sa Judio.

* Ang ngalan nga "Iscariote" pwede nagpasabot nga "gikan sa Keriot," nga nagtumong sa syudad nga diin si Judas midako.
* Kawatan si Judas Iscariote, siya ang nagdumala sa kwarta sa mga apostoles ug kanunay nga gikawatan niya kini aron gamiton alang sa iyang kaugalingon.
* Gibudhian ni Judas si Jesus pinaagi sa pagsulti sa mga pangulo sa relihiyon nila kung asa si Jesus aron madakpan nila.
* Paghuman gisilotan sa mga pangulo sa relihiyon si Jesus nga mamatay, nagbasol si Judas nga iyang gibudhian si Jesus ug nagpakamatay siya.
* Aduna say lain nga mga tawo sa Biblia nga Judas ang ngalan nila sama sa igsoon ni Jesus ug ang usa sa dose ka mga disipolo.


# Filistihanon

Ang mga Filistihnon mao ang grupo sa mga tawo nga nagpuyo sa rehiyon nga Filistia dapit sa kabaybayonan sa Dagat sa Mediteranean.

* Ang siyudad sa Asdod mao ang amihanang dapit sa Filistia ug ang siyudad nga Gaza naa sa habagatang dapit.
* Ang Filistihanon tingali nailhan sa kadaghanang mga tuig tungod sa ilang pakiggiyera batok sa mga Israelita.
* Si haring David kasagaran nangulo sa pakiggubat batok sa mga Filistihanon apil niadtong panahon nga siya batan-on pa diin gipildi niya ang Filistihanon nga manggugubat nga si Goliat.


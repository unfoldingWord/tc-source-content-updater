# Jeroboam

Si Jeroboam usa sa una nga hari sa ginghariang sa amihanang Israel. Gipanguluhan niya ang napulo ka mga tribu sa Israel nga misupak ug mibulag gikan sa habagatang mga tribu nga Juda ug Benjamin.

* Si Jeroboam usa sa mga opisyales ni Haring Solomon nga misupak kaniya nga maoy hinungdan nga ang napulo ka mga tribu sa Israel nabulag gikan sa duha ka lain nga mga tribu.
* Si Jeroboam usa gyud ka daotan nga hari. Nagbutang siya ug mga diosdiosan ug giawhag niya ang mga tawo sa gingharian sa Israel nga mosimba kanila, imbes nga simbahon si Yahweh sa templo sa Jerusalem.
* Ang ubang mga hari sa gingharian sa Israel misunod sa daotan nga ehemplo ni Jeroboam.


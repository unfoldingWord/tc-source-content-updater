# Jonas

Si Jonas usa ka propeta nga Hebreonon sa Daang Kasabotan.

* Ang libro nga Jonas estorya mahitungod niadtong gipaadto sa Dios si Jonas sa Ninebe.
* Nagsulti ang Dios kang Jonas sa pag-adto sa Ninebe ug sultihan ang mga tawo sa pagsalikway sa ilang mga sala.
* Mibalibad si Jonas ug misakay ug barko nga moadto sa laing nasod.
* Ang mga tawo sa barko naglabog kang Jonas pagawas sa barko, ug gitulon siya sa dakong isda.
* Si Jonas tulo ka adlaw sa sulod sa tiyan sa dako nga isda.
* Miadto si Jonas sa Ninebe ug nagwali, ug gisalikway nila ang ilang mga sala.


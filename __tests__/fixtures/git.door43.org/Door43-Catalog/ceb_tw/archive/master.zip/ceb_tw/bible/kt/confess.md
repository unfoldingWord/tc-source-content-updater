# isugid, pagsugid

Ang isugid nagpasabot sa pag-angkon o pagpahayag nga tinuod ang usa ka butang. Ang "pagsugid" usa ka pahayag o pag-angkon nga tinuod ang usa ka butang.

* Ang pulong nga "isugid" magtumong sa isog nga pagsulti sa kamatuoran mahitungod sa Dios. Mahimo sad kini magtumong sa pag-angkon nga nakasala kita.
* Miingon ang Biblia nga kung isugid sa mga tawo ang ilang mga sala sa Dios, pasayloon niya sila.
* Gisulat ni Santiago nga apostol nga kung isugid sa mga tumutuo ang ilang mga sala sa usa'g usa, makahatag kini ug espirituhanong pagka-ayo.
* Nagsulat sad si apostol Pablo sa mga taga-Filipos nga sa umaabot nga panahon, ang tanan nga mga tawo mosugid o mopahayag nga si Jesus ang Ginoo.
* Miingon sad si Pablo nga kung isugid sa mga tawo nga si Jesus ang Ginoo ug motoo nga gibanhaw siya sa Dios gikan sa patay, maluwas sila.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang paghubad sa "isugid" mahimong "angkonon" o "magpamatuod" o "ipahayag" o "ipaila" o "ipamatuod."
* Ang lainlaing paghubad sa "pagsugid" mahimong "pagpahayag" o "testimonya" o "pahayag mahitungod sa among gituohan" o "pag-angkon sa sala."


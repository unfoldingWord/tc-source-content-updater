# himaya, mahimayaon

Kasagaran, ang pulong nga "himaya" buot pasabot pasidungog, katahom ug hilabihang pagkagamhanan. Bisan unsang butang nga adunay himaya giingon nga "mahimayaon."

* Usahay ang "himaya" nagtumong sa mga butang nga dako ang pagkamahinungdanon ug importansiya. Sa uban nga konteksto nagtumong sa katahom, kahayag o paghukom.
* Pananglitan, ang mga pulong nga "himaya sa mga pastol" nagtumong sa maayo kaayo nga sabsabanan nga diin ang ilang mga karnero daghan ug sagbot nga makaon.
* Ang himaya gigamit labi na sa paghulagway sa Dios, nga mahimayaon kaayo labaw kang bisan kinsa o sa unsa man nga butang niining kalibutan. Tanan sa iyang kinaiya nagpakita sa iyang himaya ug sa iyang katahom.
* Ang mga pulong nga "sa paghimaya sa" buot ipasabot naghinambog mahitungod sa o magpasigarbo sa usa ka butang.

Mga Sugyot sa Paghubad

* Depende sa konteksto, lain nga mga paagi sa paghubad sa "himaya" pwede ilakip ang "katahom" o "kahayag" "pagkahalangdon" o "hilabihan ka dako kaayo" o "hilabihan ug bili."
* Ang pulong nga "mahimayaon" pwede hubaron nga "puno sa himaya" o "grabe ang pagkabililhon" o "nagasidlak nga kahayag" o "hilabihan ang pagkahalangdon."
* Ang sumbingay nga "maghatag ug himaya sa Dios" pwede sad hubaron nga "pasidunggan ang iyang pagkagamhanan" o "dayega ang Dios tungod sa iyang katahom" o "isugilon sa uban kung unsa kagamhanan ang Dios."
* Ang mga pulong nga "maghimaya sa" pwede sad hubaron nga "pagdayeg" o "magpasigarbo sa" o "maghinambog mahitungod sa" o "magkalipay sa."


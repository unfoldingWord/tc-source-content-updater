# nasudlan ug demonyo

Ang tawo nga nasudlan ug demonyo adunay demonyo o daotan nga espiritu nga nagmando sa iyang gibuhat o gihunahuna.

* Kasagaran ang nasudlan ug demonyo nga tawo gipasakitan ang iyang kaugalingon tungod kay ang demonyo maoy gatinguha nga buhaton kini.
* Si Jesus giayo ang mga tawo nga nasudlan ug demonyo pinaagi sa pagpahawa sa demonyo kanila.

Mga Sugyot sa Paghubad

* Ang uban nga pamaagi sa paghubad niini nga pulong pwede sad nga, "kontrolado sa demonyo" o "kontrolado sa daotan nga espiritu" o "adunay daotan nga espiritu nga nagpuyo sa sulod."


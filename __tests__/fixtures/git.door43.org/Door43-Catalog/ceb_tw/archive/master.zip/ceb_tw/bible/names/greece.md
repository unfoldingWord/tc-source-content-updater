# Grecia

Sa panahon sa Bag-ong Kasabotan, ang Grecia usa ka probinsiya sa Imperyong Romano.

* Sama sa nasod sa Grecia karon, makita kini sa peninsula nga gilibotan sa mga Dagat nga Mediteraneo, Aegea, ug Ionia.
* Daghang mga iglesia ang natukod sa Grecia sa unang siglo. Apil niini ang mga iglesia nga gisugdan ni apostol Pablo sa mga siyudad sa Corinto, Tesalonica, ug Filipos.
* Ang mga tawo nga gikan sa Grecia gitawag nga mga Griego. Daghan sad ang mga tawo gikan sa laing Romanong probinsiya nga nagsulti ug Griego, apil ang pipila ka mga Judio.


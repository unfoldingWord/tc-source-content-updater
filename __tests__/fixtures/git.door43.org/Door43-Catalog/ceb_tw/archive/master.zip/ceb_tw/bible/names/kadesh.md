# Cades

Ang Cades o Cades-Barnea ngalan sa usa ka importanteng siyudad sa kasaysayan sa Israel nga naa sa lugar nga karon nasod sa Syria.

* Ang Cades usa ka tubigang dapit sa tunga sa kamingawan sa Zin.
* Si Abraham niagi sa Cades sa iyang mga biyahe. 
* Nagkampo sad ang mga Israelita sa Cades sa ilang paglibutlibot sa kamingawan.
* Si Moises wala tugoti nga makasulod sa gisaad nga yuta kadtong dito sila Cades tungod sa iyang pagsupak sa sugo sa Dios mahitungod sa tubig nga magagikan sa bato.


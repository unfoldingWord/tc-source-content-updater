# Ekron

Ang Ekron usa ka daku nga siyudad sa mga Filistihanon nga makita sa siyam ka mga milya ilaya gikan sa dagat sa Medeteraneo.

* Ang templo sa diosdiosan nga si Beelzebub anaa sa Ekron.
* Kaniadto ang arka sa pagkigsaad gidala sa Ekron niadtong gikuha kini sa mga Filistihanon.
* Pagkahuman sa grabe nga sakit ug kamatayon nga nahitabo sa siyudad, gipadala sa mga Filistihanon ang arka balik sa Israel.


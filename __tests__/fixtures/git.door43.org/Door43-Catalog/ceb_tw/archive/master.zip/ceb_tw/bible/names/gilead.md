# Gilead

Ang Gilead ngalan sa rehiyon nga bukiron sa sidlakan sa suba sa Jordan, nga diin nagpuyo ang ubang tribo sa mga Israelita nga kaliwat nila Gad, Reuben, ug Manase.

* Gitawag sad kini nga rehiyon nga "bukid sa Gilead" tungod kay bungturonon kini nga lugar.
* Ang "Gilead" ngalan sad sa pipila ka mga tawo sa Daang Kasabotan. Ang usa niini mao ang apo ni Manase.


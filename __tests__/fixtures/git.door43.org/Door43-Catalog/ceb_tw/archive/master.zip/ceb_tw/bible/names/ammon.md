# Ammon, Amonihanon, Babaye nga taga-Ammon

Ang mga "katawhan sa Ammon" o mga "Amonihanon" mga kaliwat ni Ben-ammi, ang anak nga lalaki ni Lot sa iyang kamanghuran nga anak nga babaye.

* Ang pulong nga "babaye nga taga-Ammon" nagtumong gyud sa babaye nga Amonihanon. Mahimo kini nga hubaron nga "Amonihanon nga babaye."
* Ang mga Amonihanon nagpuyo sa sidlakan sa Suba sa Jordan ug mga kaaway sila sa mga Israelita.
* Sa usa ka higayon, mikuha ang mga Amonihanon ug propeta nga ang ngalan si Balaam aron tungloon ang Israel, apan wala kini tuguti sa Dios.


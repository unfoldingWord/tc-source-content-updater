# espiritu, espirituwal

Ang pulong nga "espiritu" nagtumong sa dili pisikal nga parte sa usa ka tawo nga dili makita. Kung mamatay ang usa ka tawo, ang iyang espiritu mobiya sa iyang lawas.

* Ang pulong nga "espiritu" pwede magtumong sa usa ka linalang nga walay pisikal nga lawas, labi na ang daotan nga mga espiritu.
* Ang espiritu sa usa ka tawo mao ang nakaila sa Dios ug mituo Kaniya.
* Sa kinatibuk-an ang pulong nga "espirituwal" naghulagway sa bisan unsa nga butang sa dili pisikal nga kalibutan.
* Sa Biblia ang pulong nga "espirituwal" nagtumong sa bisan unsa nga butang nga adunay kalabotan sa Dios, partikular ang Balaan nga Espiritu. 
* Pananglitan, ang "espirituwal nga pagkaon" nagtumong sa mga katudluan sa Dios nga nagpabaskog sa espiritu sa mga tawo, ang "espirituwal nga kaalam" nagtumong sa kaalam ug matarung nga batasan nga gikan sa gahum sa Balaan nga Espiritu.
* Ang Dios usa ka espiritu ug naglalang sa ubang mga espiritu nga walay pisikal nga mga lawas.
* Ang mga anghel mao ang linalang nga mga espiritu, apil kadtong nagsupak batok sa Dios ug nahimo nga daotan nga mga espiritu.
* Ang pulong nga "espiritu sa" pwede sad magpasabot nga "adunay kinaiya sa," sama sa "espiritu sa kaalam."

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang ubang mga pamaagi sa paghubad sa "espiritu" pwede nga "kalag" o "nilalang nga walay pisikal nga lawas" o "sulod nga bahin" o "sulod nga pagkatawo."
* Sa pipila ka mga konteksto, ang pulong nga "espiritu" pwede hubaron nga "daotan nga espiritu" o "linalang nga daotang espiritu."
* Usahay ang pulong nga "espiritu" gigamit sa paghulagway sa mga pagbati sa usa ka tawo sama sa "nasubo ang akong espiritu nga naa sa akong sulod nga pagkatawo." Pwede sad kini hubaron nga "nasubo ang akong espiritu" o "nasubo ako kaayo."
* Ang mga pulong nga "espiritu sa" pwede hubaron nga "kaalam sa" o "kinaiya sa" o "impluwensiya sa."
* Depende sa konteksto, ang "espirituwal" pwede hubaron nga "walay lawas" o "gikan sa Balaang Espiritu" o "sa Dios" o "mga parte sa dili pisikal nga kalibutan."
* Kining tanan posible nga mga hubad niini nga mga pulong.
* Ang giingon nga  espirituwal nga gatas mao ang pagkaon nga espirituwal.


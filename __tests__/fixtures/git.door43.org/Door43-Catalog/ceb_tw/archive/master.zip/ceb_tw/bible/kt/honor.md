# pasidungong, pasidunggan

Ang pulong nga "pasidungong" nagtumong sa pagtahod, pagtamod, o balaan nga pagtahod nga gihatag ngadto sa Dios o sa tawo.

* Gimandoan sa Dios ang mga Kristohanon nga pasidunggan ang uban apan dili mangita ug pasidungog alang sa ilang kaugalingon.
* Gimandoan ang mga anak nga pasidunggan ang ilang mga ginikanan ug apil niini ang pagtahod ug pagtuman.
* Ang "pasidungog ug himaya" kasagaran dungan nga gigamit hilabi na kung nagtumong kang Jesus. Pwede nga duha kini nga pamaagi sa pagtumong sa parehas lang nga butang.
* Ang pagpasidungog sa Dios apil ang pagtuman kaniya ug pagkinabuhi sa pamaagi nga nagpakita kung unsa siya kagamhanan.

Mga Sugyot sa Paghubad:

* Pwede sad nga ang ubang pamaagi sa paghubad sa pulong nga "pasidungog" mao ang "pagtahod" o "pagtamod" o "taas nga pagtan-aw."
* Ang pulong nga "pasidunggan" pwede hubaron nga "magpakita ug pinasahi nga pagtahod kang" o "dayegon" o "magpakita ug taas nga pagtan-aw kang" o "labihang paghatag ug bili."


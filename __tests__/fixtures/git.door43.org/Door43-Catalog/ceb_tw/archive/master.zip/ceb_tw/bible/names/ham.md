# Ham

Si Ham mao ang ikaduha sa tulo ka mga anak nga lalaki ni Noe nga gihisgotan sa Daang Kasabotan.

* Kaniadtong naglunop nga natabonan ang tibuok kalibutan, si Ham ug ang iyang mga igsoon uban ni Noe ug ang ilang mga asawa sa sulod sa arka.
* Pagkahuman sa lunop, adunay higayon nga wala gyud gitahod ni Ham ang iyang amahan nga si Noe. Tungod niini, gitunglo ni Noe ang anak ni Ham nga si Canaan ug ang tanan niyang kaliwat nga sa kadugayan nahimong mga Canaanehanon.


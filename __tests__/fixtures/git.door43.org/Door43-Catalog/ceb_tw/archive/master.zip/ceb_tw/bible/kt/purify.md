# Putli, Paglimpyo, Paghinlo

Ang pagka-"putli" nagpasabot sa pagka-walay sayop o walay nasagol nga dili angay unta didto. Ang paglimpyo sa usa ka butang mao ang paghinlo niini ug pagtangtang sa tanan nga nagpahugaw niini.

* Mahitungod sa balaod sa Daang Kasabotan, ang "paglimpyo" ug "paghinlo" nagtumong gyud sa paghinlo sa nagpahugaw sa butang o tawo sumala sa ritwal, sama sa sakit, mga likido nga mogawas sa tawo, o pagpanganak.
* Aduna say balaod sa Daang Kasabotan nga giingon kung unsaon pagpalimpyo sa mga tawo gikan sa sala, kasagaran sa pagsakripisyo ug mananap. Dili kini molangtog ug kinahanglan balik-balikon ang sakripisyo.
* Sa Bag-ong Kasabotan, kasagaran ang paglimpyo nagtumong sa pagkahinlo gikan sa sala.
* Ang bugtong nga pamaagi nga ang mga tawo hingpit ug permanante nga malimpyohan sa sala mao ang paghinulsol ug pagdawat sa pagpasaylo sa Dios pinaagi sa pagsalig kang Jesus ug sa iyang sakripisyo.

Mga Sugyot sa Paghubad

* Ang pulong nga "paglimpyo" pwede hubaron nga "paghimo nga putli" o "limpyo" o "limpyohan sa tanang hugaw" o "pagtangtang sa tanang mga sala."
* Ang mga pulong sama sa, "sa dihang ang panahon sa ilang paghinlo nahuman na" pwede hubaron nga, "niadtong nahinloan na ang ilang kaugalingon pinaagi sa paghulat sa gikinihanglan nga mga adlaw."
* Ang mga pulong nga, "naghatag ug paghinlo alang sa sala" pwede hubaron nga, "naghatag ug pamaagi aron hingpit nga mahinloan sa ilang sala."
* Ang ubang pamaagi sa paghubad sa "paghinlo" pwede sad, ang  "espirituhanong paghugas" o "nahimong limpyo sumala sa ritwal."


# tigpakaaron-ingnon, pagpakaaron-ingnon

Ang pulong nga "tigpakaaron-ingnon" nagtumong sa usa ka tawo nga nagbuhat ug mga butang nga nagpakita ug pagkamatarong, apan sekreto nga nagbuhat ug mga dautan nga mga pamaagi. Ang pulong nga "pagpakaaron-ingnon" nagtumong sa kinaiya nga naglimbong sa mga tawo nga maghunahuna nga ang usa ka tawo matarong.

* Ang mga tigpakaaron-ingnon gusto nila nga nakita sila nga nagbuhat ug maayo nga mga butang aron hunahunaon sa mga tawo nga maaayo sila nga mga tawo.
* Kasagaran ang tigpakaaron-ingnon mosaway sa ubang mga tawo nga nagbuhat ug makasasala nga mga binuhatan nga sila mismo nagbuhat sad.
* Gitawag ni Jesus nga tigpakaaron-ingnon ang mga Pariseo tungod kay nagbuhat sila sa mga relihiyoso nga mga butang sama sa pagsul-ob sa mga pipila ka mga sinina ug pagkaon ug pipila ka mga pagkaon, apan dili sila maloloy-on ug patas sa mga tawo.
* Ang tigpakaaron-ingnon gasaway sa sayop sa ubang mga tawo, apan wala siya moangkon sa iyang kaugalingong mga sayop.

Mga Sugyot sa Paghubad:

* Pipila sa mga pinulungan adunay sumbingay sama sa "doble kara" nga nagtumong sa usa ka tigpagkaaron-ingnon o mga buluhaton sa tigpakaaron-ingnon.
* Ang lain nga pamaagi sa paghubad sa "tigpakaaron-ingnon" mahimong apil ang, "limbongan" o "nagpakaaron-ingnon" o "mapahitas-on, malimbongon nga tawo."
* Ang pulong nga "tigpakaaron-ingnon" mahimong hubaron pinaagi sa, "pagpanglingla" o "dili matinud-anon nga mga buluhaton" o "nagpakaaron-ingnon."


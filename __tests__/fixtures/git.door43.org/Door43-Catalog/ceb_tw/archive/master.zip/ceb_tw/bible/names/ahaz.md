# Achaz

Si Achaz usa ka dautang hari nga nagmando sa gingharian sa Juda sukad 732  hangtod sa 716 ka tuig una pa gipanganak si Cristo. Kini mga 140 ka tuig usa pa gidala ang mga tawo sa Israel ug Juda nga mga dinakpan ngadto sa Babilonia.

* Samtang iyang gimandoan ang Juda, nagtukod ug altar si Achaz aron magsimba sa mga diosdiosan sa mga taga-Assyria nga maoy hinungdan nga mitalikod ang mga tawo gikan sa tinuod nga Dios, nga si Yahweh.
* Si Haring Achaz 20 anyos ang iyang edad niadtong nagsugod siya ug paghari sa Juda, ug nangulo siya sulod sa 16 ka tuig.


# Templo

Ang templo usa ka tinukod nga gilibutan ug mga hawanan nga pinaril. Ang mga Israelita moadto sa templo aron mag-ampo ug maghatag ug sakripisyo sa Dios. Naa kini sa Bukid sa Moriah sa siyudad sa Jerusalem.

* Kasaragaran ang pulong nga "templo" nagtumong sa tibuok templo apil ang mga hawanan nga nagpalibot sa pinakalabing importante nga tinukod sa templo. Usahay nagtumong lang kini sa tinukod ug dili apil ang mga hawanan.
* Ang templo adunay duha ka mga kuwarto, ang dapit nga Balaan ug ang dapit nga Labing Balaan.
* Gisulti sa Dios nga ang templo ingon nga iyang puloy-anan. 
* Sa Bag-ong Kasabotan, ang pulong nga "templo sa Balaang Espiritu" gigamit nga nagtumong sa mga tumutuo kang Jesus, tungod kay nagpuyo kanila ang Balaang Espiritu.

Mga Sugyot sa Paghubad:

* Kasagaran kung ang pulong nag-ingon nga ang mga tawo "naa sa templo," nagtumong kini sa mga hawanan gawas sa templo. Pwede kini hubaron nga "naa sa hawanan sa templo."
* Kung magtumong sa tinukod mismo, ang ubang mga tighubad ilang hubaron ang "templo" nga "tinukod nga templo," aron maklaro kung unsay gitumong.
* Ang mga pamaagi sa paghubad sa "templo" pwede nga, "Balaan nga balay sa Dios" o " sagrado nga lugar sa pagsimba."
* Kasagaran sa Biblia, ang templo nagtumong sa "ang balay ni Yahweh" o "ang balay sa Dios."


# alagad, pag-alagad/buluhaton

Sa Biblia, ang mga pulong nga "alagad" ug "pag-alagad/buluhaton" nagtumong sa pag-alagad sa uban pinaagi sa pagtudlo kanila mahitungod sa Dios ug pag-atiman sa ilang espirituhanong panginahanglan. Ang pulong nga "alagad" pwede sad magtumong sa tawo nga nag-alagad sa mga tawo sa pagtudlo ug pag-atiman sa ilang espirituhanong panginahanglan.

* Sa Daang Kasabotan, ang mga pari "nag-alagad" sa Dios didto sa templo pinaagi sa paghalad ug mga sakripisyo kaniya.
* Ang ilang "buluhaton" apil ang pag-atiman sa templo ug paghalad ug mga pag-ampo ngadto sa Dios alang sa mga katawhan. 
* Sa Bag-ong Kasabotan, ang "alagad" sa maayong balita mao ang tawo nga nagtudlo sa uban sa mensahe sa kaluwasan pinaagi sa pagtuo kang Jesus. Usahay ang alagad gitawag nga "ulipon."
* Ang buluhaton nga pag-alagad sa mga tawo pwede mag-apil sa espirituhanon nga pag-alagad kanila pinaagi sa pagtudlo mahitungod sa Dios.
* Pwede sad kini magtumong sa pag-alagad sa mga tawo sa ilang pisikal nga panginahanglanon, sama sa pag-atiman sa mga masakiton ug paghatag ug pagkaon sa mga pobre.

Mga Sugyot sa Paghubad:

* Sa konteksto sa pagministro sa mga tawo, ang "pagministro" pwede hubaron nga "pag-alagad" o "pag-atiman" o "pagtagbo sa mga panginahanglan ni."
* Kung nagtumong sa pagministro sa templo, ang pulong nga "ministro" pwede hubaron nga "pag-alagad sa Dios didto sa templo" o "paghalad ug mga sakripisyo sa Dios alang sa mga katawhan."
* Sa konteksto sa pagministro sa Dios, pwede kini hubaron nga "pag-alagad" o "pagtrabaho alang sa Dios."
* Ang mga pulong nga "nagministro sa" pwede hubaron nga "nag-atiman kang" o "naghatag kang" o "nagtabang."


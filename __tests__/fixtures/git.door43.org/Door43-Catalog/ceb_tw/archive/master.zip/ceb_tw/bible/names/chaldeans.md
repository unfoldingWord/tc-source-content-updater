# Caldea, Caldehanon

Ang rehiyon sa Caldea naa sa habagatan sa Babilonia. Ang mga tawo nga nagpuyo niini nga yuta gitawag nga Caldehanon.

* Ang siyudad sa Ur nga diin si Abraham gagikan, makit-an kini sa Caldea.
* Mga 600 ka tuig una pa gipanganak si Cristo, ang Caldea nailhan nga Babilonia.
* Pila ka tuig pagkahuman niini nga panahon, ang Jerusalem napildi ug ang mga Israelita gidala sa Babilonia. 
* Napulo ka tuig gikan sa pagkapildi sa Jerusalem, ang hari sa Babilonia nga si haring Nabucodonosor giguba niya ang templo didto.
* Ang mga tawo nga nagpuyo sa Babilonia usahay gitawag gihapon nga mga "Caldehanon."


# Josaphat

Adunay duha ka tawo nga Josaphat ang mga ngalan sa Daang Kasabotan.

* Ang ilado kaayo nga tawo niini nga ngalan mao si haring Josaphat nga ika-upat nga hari nga nangulo sa gingharian sa Juda.
* Gipabalik niya ang kalinaw taliwala sa Juda ug Israel, ug giguba niya ang mga halaran sa mga diosdiosan.
* Ang usa pa nga Josaphat mao ang katabang sa administrasyon ni haring David ug Haring Solomon.


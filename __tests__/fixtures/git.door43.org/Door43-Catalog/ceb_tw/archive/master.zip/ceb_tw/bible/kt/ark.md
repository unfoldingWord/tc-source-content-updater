# Arka

Kasagaran, ang arka nagtumong sa kahon nga rektangglo nga hinimo sa kahoy aron kabutangan o maampingan ang gisulod nga butang ani. Ang arka pwede nga daku o gamay, depende kung unsa ang iyang gamit.

* Sa Biblia, ang pulong nga "ark" sa Ingles nagtumong sa "arka sa pakigsaad" o ang barko nga gibuhat ni Noe aron makaikyas sa lunop sa tibuok kalibutan.
* Ang Hebreo nga pulong nga gigamit sa arka ni Noe parehas nga pulong nga gigamit sa basket o kahon nga gibutangan kang Moises adtong bata pa kaayo siya. Gitago siya sa inahan niya sa usa ka kahon nga gipalutaw sa suba sa Nile. Ang mga pulong nga "ang arko sa kasabotan", lain nga Hebreo nga pulong ang gigamit sa "arka".
* Depende sa konteksto, "ang arka" pwede mahubad sa pulong nga "kahon", "kaban" o "daku kaayo nga barko".


# Disipulo

Ang pulong nga "disipulo" nagtumong sa usa ka tawo nga nakig-uban ug dugay nga panahon sa usa ka magtutudlo aron makakat-on sa kinaiya ug katudloan sa magtutudlo.

* Ang mga tawo nga gasunod-sunod kang Jesus nga naminaw ug nagtuman sa iyang mga katudloan, gitawag nga iyang mga "disipulo."
* Si Juan Bautista aduna say mga disipulo.
* Sa panahon sa ministeryo ni Jesus, adunay mga disipulo nga misunod kaniya ug naminaw sa iyang mga katudloan.
* Nagpili si Jesus ug dose ka mga disipulo aron mahimo nga iyang tigsunod, kining dose nga mga lalaki gitawag nga iyang mga "apostoles."
* Ang dose ka mga apostoles ni Jesus nagpadayon nga gitawag nga iyang mga "disipulo" o "ang dose."
* Kadtong paadto na si Jesus sa langit, gimanduan niya ang iyang mga disipulo nga magtudlo sa ubang mga tawo kung unsaon nga mahimo sad sila nga disipulo ni Jesus.
* Ang bisan kinsa nga motuo kang Jesus ug motuman sa iyang mga katudloan gitawag nga iyang mga disipulo.

Mga Sugyot sa Paghubad

* Ang pulong nga "disipulo" pwede hubaron pinaagi sa pulong o mga pulong nga nagpasabot nga "sumusunod" o "estudyante" o "magkat-on."
* Siguraduha nga ang paghubad niini nga pulong dili lang nagtumong sa estudyante nga magkat-on sulod sa klase.
* Ang paghubad niini nga pulong kinahanglan sad nga lain sa paghubad sa "apostol."


# katawhan sa Dios, akong mga katawhan

Ang pulong nga "katawhan sa Dios" nagtumong sa mga tawo nga gipili sa Dios gawas sa kalibutan aron makabaton ug pinasahi nga relasyon kaniya.

* Kung ang Dios mag-ingon nga "ang akong mga katawhan" gitumong niya ang mga tawo nga iyang pinili ug adunay relasyon kaniya.
* Ang mga katawhan sa Dios mao ang mga pinili niya ug gigahin sa kalibutan aron magkinabuhi sa pamaagi nga makapahimuot kaniya. Gitawag sad niya sila nga iyang mga anak.
* Sa Daang Kasabotan ang 'katawhan sa Dios" nagtumong sa nasod sa Israel nga pinili sa Dios ug gigahin gikan sa ubang mga nasod sa kalibutan aron mag-alagad ug magtuman kaniya.
* Sa Bag-ong Kasabotan, "ang mga katawhan sa Dios" nagtumong sa tanang mituo kang Jesus ug gitawag nga Iglesia. Kini nag-apil sa mga Judio ug mga Gentil.

Mga Sugyot sa Paghubad:

* Ang pulong nga "mga katawhan sa Dios" pwede hubaron nga "mga tawo nga nagsimba sa Dios" o "mga tawo nga nag-alagad sa Dios" o "mga tawo nga iya sa Dios."
* Ang ubang mga pamaagi sa paghubad sa "akong katawhan" sa dihang giingon sa Dios, pwede nga "ang mga tawo nga akong pinili" o "ang mga tawo nga nagsimba kanako" o "akong mga tawo."
* Parehas sad nga ang, "imong katawhan" pwede hubaron nga "ang mga tawo nga naa kanimo" o "ang pinili nimo nga imong katawhan."
* Mao sad sa pulong nga "iyang katawhan" pwede hubaron nga "mga tawo nga naa kaniya" o "mga tawo nga gipili sa Dios aron mahimo nga iyang kaugaligon."


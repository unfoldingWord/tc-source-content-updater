# ngalan

Sa Biblia, ang pulong nga "ngalan" gigamit sa pipila ka mga sumbingay:

* Sa ubang mga konteksto, ang "ngalan" pwede magtumong sa dungog sa usa ka tawo, sama sa "maghimo kita ug ngalan alang sa atong kaugalingon."
* Ang pulong nga "ngalan" pwede sad magtumong sa paghinumdom sa usa ka butang. Pananglitan, ang "putlon ang mga ngalan sa mga diosdiosan" nagpasabot sa pagguba niadtong mga diosdiosan aron dili na sila mahinumdoman o simbahon.
* Ang pagsulti "sa ngalan sa Dios" nagpasabot sa pagsulti nga adunay gahum ug awtoridad sa Dios o ingon nga iyang representante.
* Ang "ngalan" sa usa ka tawo pwede magtumong sa tibuok nga pagkatawo, sama sa "walay laing ngalan ubos sa langit nga pinaagi niini maluwas kita." (Tan-awa sa: [[rc://ceb/ta/man/translate/figs-metonymy]])

Mga Sugyot sa Paghubad:

* Ang mga pulong sama sa "ang iyang maayong ngalan" pwede hubaron nga "ang iyang maayong dungog."
* Ang pagbuhat sa usa ka butang "sa ngalan ni" pwede hubaron nga "adunay awtoridad ni" o "adunay pagtugot ni" o "ingon nga representante " niadto nga tawo.
* Ang mga pulong nga "maghimo ug ngalan alang sa atong kaugalingon" pwede hubaron nga "magpahibalo sa daghang tawo mahitungod kanato" o "magpahunahuna sa mga tawo nga kita importante kaayo."
* Ang sumbingay nga "tawgon ang iyang ngalan" pwede hubaron nga "hinganlan siya" o "hatagan siya sa ngalan."


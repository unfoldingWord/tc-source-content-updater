# ilansang sa krus

Ang mga pulong nga "ilansang sa krus" nagpasabot sa pagpatay sa usa ka tawo pinaagi sa pagbutang kaniya sa krus unya ibilin siya aron nga mag-antos nga adunay dakong kasakit ug mamatay.

* Ang tawo igapos o ilansang sa krus. Ang mga gilansang nga mga tawo mamatay tungod kay mahutdan ug dugo o kay dili na kaginhawa.
* Ang karaan nga Imperyong Romano kasagarang nigamit niini nga pamaagi sa pagpatay aron silotan ug patyon ang mga dautan kaayong mga kriminal o mga nisupil sa awtoridad sa ilang gobyerno.
* Ang mga pangulo sa relihiyon sa mga Judio nihangyo sa Romanong gobernador nga suguon ang iyang mga sundalo nga ilansang sa krus si Jesus. Mao nga gilansang si Jesus sa krus sa mga sundalo. Nag-antos siya didto sulod sa unom ka oras ug unya namatay.

Mga Sugyot sa Paghubad:

* Ang pulong nga "ilansang sa krus" pwede hubaron nga "patyon sa krus" o "patyon pinaagi sa paglansang sa krus."


# Jesse

Si Jesse mao ang apo nga lalaki ni Boaz. Siya ang amahan ni haring David.

* Si Jesse gikan sa lungsod sa Bethlehem ug sa tribu nga Juda.
* Si Isaias naghatag ug taas nga propesiya mahitugod sa usa sa mga kaliwat ni Jesse.
* Si Jesus mao ang kaliwat ni Jesse nga maoy nagtuman niadto nga propesiya.


# tuo nga kamot

Ang pulong nga "tuo nga kamot" sumbingay nga nagtumong sa halangdon nga katungdanan sa tuong kilid sa usa ka pangulo o importante nga tawo.

* Ang tuo nga kamot gigamit sad ingon nga simbolo sa gahum, awtoridad o kusog.
* Ang Biblia naghulagway kang Jesus nga naglingkod "sa tuo nga kamot sa" Dios nga Amahan isip ulo sa lawas sa mga tumutuo (ang Iglesia) ug nagkontrolar isip nga tagamando sa tanan nga gilalang.
* Ang tuo nga kamot sa tawo gigamit sa pagpakita sa pinasahi nga dungog sa dihang ibutang kini sa ulo sa usa ka tawo nga gihatagan ug panalangin (sama sa gihimo ni Israel sa anak ni Jose nga si Efraim).  
* Ang pag-alagad sa tuohang kamot sa usa ka tawo nagpasabot nga ang iyang pag-alagad makatabang kaayo ug importante kaayo adto nga tawo.

Mga Sugyot sa Paghubad:

* Kung ang "tuo nga kamot" dili pareho ang buot ipasabot sa pinulongan nga hubaron, adunay uban nga paagi sa paghubad niini pwede ang "gahum" o "awtoridad" o "halangdon nga katungdanan" o "katabang" o sumbingay sa pinulongan nga parehas ang buot ipasabot.
* Kung mahitungod kang Yahweh, ang mga pulong nga "sa iyang tuo nga kamot ug sa iyang kusgan nga bukton" sumbingay kini nga pinulongan nga nagtumong sa gahum ug hilabihan nga kusog. Kining duha nga pamaagi sa pagsulti naghatag ug importansiya sa gahum ug kakusog sa Dios.


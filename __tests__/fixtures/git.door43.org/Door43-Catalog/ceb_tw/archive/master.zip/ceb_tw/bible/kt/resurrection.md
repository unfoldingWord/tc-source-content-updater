# pagkabanhaw

Ang pulong nga "pagkabanhaw" nagtumong sa pagbuhi pag-usab pagkahuman nga namatay.

* Ang pagbanhaw sa usa ka tawo buot ipasabot pagkabuhi pag-usab sa usa ka tawo, ang Dios lang ang adunay gahum sa paghimo niini.

* Ang pulong nga "pagkabanhaw" kasagaran nagtumong sa pagkabuhi ni Jesus pag-usab pagkahuman nga siya namatay.

* Sa dihang si Jesus miingon, "ako ang pagkabanhaw ug ang kinabuhi" buot ipasabot nga siya ang kakuhaan sa pagkabanhaw, ug mao ang makapabuhi sa mga tawo pag-usab. 

Mga Sugyot sa Paghubad:

* Ang pulong nga "pagkabanhaw" pwede sad hubaron nga "nabuhi pag-usab" o "buhi na usab pagkahuman nga namatay."
* Ang literal nga buot ipasabot niini nga pulong mao "ang pagbangon" o "gibangon."


# Lea

Si Lea usa sa mga asawa ni Jacob. Inahan siya sa napulo ka mga lalaking anak nga nahimong pipila sa mga tribo sa Israel.

* Ang amahan ni Lea si Laban nga igsoong lalaki sa asawa ni Isaac nga si Rebeka.

* Bisag si Lea wala kaayo higug-maa ni Jacob sama kang Raquel, ang Dios madagaya nga gipanalanginan siya ug daghan nga mga anak.


# Isaac

Si Isaac ang anak nga lalaki ni Abraham ug Sarah nga gisaad sa Dios nga ihatag kanila bisan mga tigulang na sila.

* Gisaad sa Dios nga ang pakigsaad nga gihimo niya kang Abraham magpadayon kang Isaac ug sa tanang niyang mga kaliwat sa walay katapusan.
* Gisulayan sa Dios ang pagtuo ni Abraham kaniadtong giingon sa Dios kaniya nga ihalad si Isaac.
* Si Jacob anak nga lalaki ni Isaac nga adunay dose ka mga anak nga lalaki. Sa kadugayan ang ilang mga kaliwat nahimong dose ka mga tribu sa nasod sa Israel.
* Ang ngalan nga Isaac nagpasabot nga "mikatawa siya." Kaniadtong giingnan sa Dios si Abraham nga siya ug si Sarah maadunahan ug anak, mikatawa si Sara tungod kay pareho na silang tigulang.


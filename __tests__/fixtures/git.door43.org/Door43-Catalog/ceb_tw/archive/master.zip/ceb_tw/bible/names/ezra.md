# Esdras

Si Esdras usa ka Israelita nga pari ug eksperto sa balaod sa Judio nga nagtala sa kasaysayan sa pagbalik sa mga Israelita sa Jerusalem gikan sa Babilonia diin ang mga Israelita nabihag sa 70 ka mga tuig.

* Git ala ni Esdras kini nga bahin sa kasaysayan sa Israel sa libro nga gitawag nga Esdras. Tingali siya sad ang nagsulat sa libro nga gitawag nga Nenemias, kay kining duha ka mga libro usa ra ka libro adtong una.
* Sa dihang mibalik na si Esdras sa Jerusalem gitukod niya pag-usab ang Balaod, kay ang mga Israelita mihunong sa pagtuman sa balaod sa Adlaw sa igpapahulay ug nakigminyo sila sa mga babaye nga nagsunod sa paganong relihiyon.
* Mitabang sad si Esdras sa pagtukod sa templo nga giguba sa mga taga Babilonia sa dihang nadakpan nila ang katawhan sa Jerusalem.
* Aduna pay duha ka tawo nga Esdras ang pangalan nga nahisgutan sa Daang Kasabotan.


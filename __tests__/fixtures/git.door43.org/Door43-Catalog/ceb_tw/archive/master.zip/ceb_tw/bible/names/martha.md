# Marta

Si Marta usa ka babaye nga taga Betania nga misunod kang Jesus.

* Si Marta adunay igsoon nga babaye nga si Maria ug igsoon nga lalaki nga si Lazaro, nga misunod sad kang Jesus.
* Usa ka higayon si Marta hasol kaayo sa pag-andam ug pagkaon, samtang ang iyang igsoon nga si Maria milingkod ug naminaw sa gitudlo ni Jesus.
* Sa dihang namatay si Lazaro, si Marta nag-ingon kang Jesus nga mituo siya nga si Jesus mao ang Cristo nga anak sa Dios.


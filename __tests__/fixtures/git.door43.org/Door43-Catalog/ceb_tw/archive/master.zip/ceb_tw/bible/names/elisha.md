# Eliseo

Si Eliseo usa ka propeta sa Israel sa panahon nga naghari sila Ahab, Ahaziah, Jehoram, Jehu, Jehoahaz, ug Jehoash.

* Gisultian sa Dios si propeta Elias nga dihogan niya si Eliseo isip propeta.
* Kadtong si Elias gidala na sa langit, si Eliseo nahimong propeta sa Dios sa mga hari sa Israel.
* Nagbuhat si Eliseo ug mga milagro, sama sa pag-ayo sa usa ka tawo nga taga Syria nga adunay sangla ug sa pagbanhaw niya sa anak sa usa ka babaye nga taga Sunam.


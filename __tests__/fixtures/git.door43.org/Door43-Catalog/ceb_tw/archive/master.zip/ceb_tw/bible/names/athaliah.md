# Athaliah

Si Athaliah ang daotan nga asawa ni Jehoram nga hari sa Juda. Siya ang apo nga babaye ni Omri nga usa sad ka daotan nga hari sa Israel.

* Kadtong namatay na si Jehoram, ang anak nga lalaki ni Athaliah nga si Ahaziah maoy mipuli nga hari. 
* Sa dihang namatay na si Ahaziah, nagplano si Athaliah nga patyon ang tanan nga pamilya sa hari. Apan ang usa sa iyang mga apo nga lalaki nga si Joas, giluwas sa iyang iyaan.


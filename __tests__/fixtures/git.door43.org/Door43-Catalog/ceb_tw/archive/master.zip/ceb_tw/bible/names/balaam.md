# Balaam

Si Balaam usa ka pagano nga propeta sa panahon nga ang mga Israelita nagkampo sa Suba sa Jordan nga nag-andam nga mosulod sa yuta sa Canaan.

* Si Balaam gikan sa siyudad sa Petor nga naa sa rehiyon palibot sa Suba sa Euprates.
* Ang Midiahanon nga hari nga si Balak, nahadlok sa pwersa ug kadaghan sa mga Israelita mao nga gisuholan niya si Balaam aron tungluon sila.
* Ang Dios nagpadala ug anghel aron pugngan si Balaam ug wala niya gitugutan nga iyang tungluon ang Israel, apan hinuon gimanduan niya nga panalanginan sila.
* Gipugngan sa Dios si Balaam nga himuon kini pinaagi sa pagpadala sa anghel nga mobabag sa iyang dalan aron ang iyang asno wala mosugot nga magpadayon.
* Sa pagtuman sa mga panudlo sa Dios, gipanalanginan ni Balaam ang mga Israelita imbes nga tungluon sila.
* Ang usa sa labing talagsaon nga bahin sa istorya mao ang paghatag sa Dios ug abilidad sa asno nga makigsulti kang Balaam.


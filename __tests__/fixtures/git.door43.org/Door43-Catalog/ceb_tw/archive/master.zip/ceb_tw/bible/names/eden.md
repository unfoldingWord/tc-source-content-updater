# Eden, hardin sa Eden

Ang Eden usa ka lugar adtong una nga panahon nga adunay hardin diin gipapuyo sa Dios ang una nga lalaki ug babaye.

* Kini nga hardin parte lang sa rehiyon nga ginganlang "Eden".
* Wala nahibal-an ang sakto nga lokasyon niini.
* Ginganlan sad kini nga "hardin ni Yaweh."
* Ang pulong nga "Eden" gikan sa pulong nga Hebreo nga nagpasabot nga "magpakalipay sa".


# tabon sa katagbawan

Ang "tabon sa katagbawan" mao ang tinabla nga bulawan nga gigamit nga pangtakob sa ibabaw sa arka sa pakigsaad. Sa Ingles nga paghubad, kasagaran nagtumong kini nga "takob sa katagbawan."

* Ang tabon sa katagbawan adunay mga 115 sentimetro ang katas-on ug 70 sentimetro ang kalap-don.
* Ang ibabaw sa tabon sa katagbawan adunay duha ka bulawan nga kerubin nga nag-akob ang ilang mga pako.
* Nag-ingon si Yaweh nga iyang tagbuon ang mga Israelta didto sa ibabaw sa tabon sa katagbawan, ilawom sa tinuy-od nga mga pako sa kerubin. Ang kinatas-ang pari lang ang gitugtan nga mohimo niini kay siya ang tinugyanan sa mga tawo.
* Usahay kini nga tabon sa katagbawan nagtumong nga "lingkuranan sa kalooy" kay kini nagpahayag sa kalooy sa Dios sa iyang pagbalik aron luwason ang makasasala nga tawo.

Mga Sugyot sa Paghubad

* Mga lain nga paghubad niini nga pulong mao ang, "tabon sa arka diin ang Dios nagsaad sa pagtubos" o "lugar diin ang Dios nag-ula" o "tabon sa arka diin ang Dios nagpasaylo ug nagpahauli."
* Gapasabot sad nga "lugar sa pagpasig-uli."
* Ikompara kini nga pulong kung giunsa nimo paghubad "pagtabon sa sala," pagpasig-uli," ug "katubsanan."


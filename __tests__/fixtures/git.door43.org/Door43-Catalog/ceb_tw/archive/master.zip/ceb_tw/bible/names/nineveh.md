# Neniva, Nenivahanon

Ang Neniva mao ang kapital nga siyudad sa Asiria. Ang Nenivahanon mao ang tawo nga nagpuyo sa Neniva.

* Gipadala sa Dios ang propeta nga si Jonas aron pasidad-an ang mga Nenivahanon nga isalikway ang ilang dautang mga binuhatan. Gibuhat kini nila ug wala sila gilaglag sa Dios.
* Kadugayan, ang mga taga-Asiria miundang ug alagad sa Dios. Ilang gibuntog ang gingharian sa Israel ug gidala ang mga tawo ngadto sa Neniva.


# Jeremias

Si Jeremias usa ka propeta sa Dios sa gingharian sa Juda.

* Sama sa kasagaran nga mga propeta, si Jeremias pirmi nga nagpasidaan sa mga tawo nga silotan sila sa Dios tungod sa ilang mga sala.
* Gitagna ni Jeremias nga pildihon sa mga taga-Babilonia ang Jerusalem nga maoy nagpasuko sa mga tawo sa Juda kang Jeremias. Mao nga gibutang siya sa uga nga atabay ug gipasagdan siya didto hangtod siya mamatay. Apan ang hari sa Juda gisugo ang iyang mga ulipon aron luwason si Jeremias gikan sa atabay.


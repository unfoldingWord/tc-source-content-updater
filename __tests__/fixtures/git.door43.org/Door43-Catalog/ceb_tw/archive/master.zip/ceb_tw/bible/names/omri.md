# Omri

Si Omri usa ka kumander sa mga kasundaluhan nga nahimong ika-unom nga hari sa Israel.

* Nangulo si Omri sulod sa 12 ka mga tuig sa siyudad sa Tirzah.
* Sama sa tanang mga hari sa Israel nga nauna sa iyaha, si Ormi usa ka daotan kaayo nga hari nga nangulo sa mga tawo sa Israel sa pagsimba sa daghan nga mga diosdiosan.
* Si Ormi ang amahan sa daotan sad nga hari nga si Ahab.


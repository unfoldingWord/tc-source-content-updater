# Suba sa Jordan

Ang Suba sa Jordan midagayday gikan sa amihanan paingon sa habagatan, ug maoy sidlakan nga utlanan sa lugar nga gitawag ug Canaan.

* Karon, ang Suba sa Jordan nagbahin sa Israel sa kasadpan ug Jordan sa sidlakan.
* Ang Suba sa Jordan midagayday sa dagat sa Galileo ug mihinong sa Patay nga Dagat.
* Sa dihang gidala ni Josue ang Israel sa Canaan, kinahanglan nila motabok sa suba sa Jordan bisan nagbaha kini ug lalom kaayo. Tungod kay lalom kaayo ug lisod sa pagtabok, milagro nga gipahunong sa Dios ang tubig sa pagdagayday aron makatabok sila.


# walay maikasulti

Ang pulong nga "walay maikasulti" literal nga giingon nga "walay ikabasol." Gigamit kini sa pagtumong sa usa ka tawo nga kinasingkasing nga nagtuman sa Dios apan wala kini nag-ingon nga kadto nga tawo walay sala.

* Si Abraham ug si Noe nailhan nga walay maikasulti ang Dios sa ila.
* Ang tawo nga adunay repotasyon nga "walay maikasulti" naggawi sa pamaagi nga naghatag ug pasidungog sa Dios.
* Sumala sa usa ka bersikulo, ang tawo nga walay maikasulti ang uban mahitungod sa iya mao ang "tawo nga adunay kahadlok sa Dios ug milikay sa dautan."

Mga Sugyot sa Paghubad

* Pwede sad kini hubaron nga, "walay sayop sa iyang kinaiya" o "hingpit nga mituman sa  Dios" o "paglikay sa sala" o "milikay sa mga dautan."


# Juan Bautista

Si Juan anak ni Zacarias ug Elisabet. Tungod kay ang "Juan" kumon nga ngalan, kasagaran gitawag siya ug "Juan Bautista" aron malahi siya sa ubang mga ginganlang Juan, sama ni Apostol Juan.

* Si Juan usa ka propeta nga gipadala sa Dios sa pag-andam sa mga tawo sa pagtuo ug sa pagsunod sa Mesias.\\
* Miingon si Juan sa mga tawo nga maghinulsol sila sa ilang mga sala, mobalik sa Dios, ug sa pag-undang sa pagpakasala aron maandam sila sa pagdawat sa Mesias.\\
* Si Juan nagbautismo ug daghang mga tawo sa tubig nga timaan nga sila naghinulsol sa ilang mga sala ug sa paglikay nila sa mga sala.\\
* Gitawag si Juan nga "Juan Bautista" tungod kay daghang mga tawo ang iyang gibautismohan.\\
* Siguraduha gyud nga ang mga tawo nakasabot nga ang Ingles nga "John the baptist" wala nagtumong sa iglesia niini nga ngalan. Maayo siguro nga ingnon, "Juan nga tig Bautismo" o, "Juan nga Magbabautismo."


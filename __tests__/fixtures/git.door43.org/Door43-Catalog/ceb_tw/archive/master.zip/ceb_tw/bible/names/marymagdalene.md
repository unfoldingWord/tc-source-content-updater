# Maria Magdalena

Si Maria Magdalena misugod sa pagsunod kang Jesus pagkahuman nga gipalayas ni Jesus ang mga demonyo gikan kaniya.
  

* Si Maria Magdalena ug ang uban pa nga mga babaye mitabang sa pagsuporta kang Jesus ug sa iyang mga apostoles pinaagi sa paghatag ug mga pagkaon kanila.
* Si Maria Magdalena ug ang uban pa nga mga babaye mao ang unang nakakita kang Jesus pagkahuman nga siya mibangon gikan sa mga patay.


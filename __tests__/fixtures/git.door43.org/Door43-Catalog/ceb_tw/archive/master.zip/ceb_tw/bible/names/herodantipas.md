# Herodes Antipas

Si Herodes Antipas mao ang Romanong pangulo sa Judea niadtong panahon ni Jesus. Usahay gitawag siya nga "Haring Herodes" bisan kung dili gyud siya tinuod nga hari.

* Adunay pipila ka mga tawo nga "Herodes" sa Biblia. Si Haring Herodes nga Pangulo mao ang amahan ni Herodes Antipas. Siguradoha nga klaro sa paghubad nga kining duha ka Herodes lahi nga mga tawo.
* Si Herodes Antipas nangulo sa ika-upat nga bahin sa Imperyong Romano mao nga gitawag sad siya nga "Herodes nga Gobernador."
* Si Antipas mao ang Herodes nga nagsugo nga patyon si Juan Bautista pinaagi sa pagpunggot.
* Siya sad ang Herodes nga naglutos kang Jesus una pa siya gilansang sa krus.


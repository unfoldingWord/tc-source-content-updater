# Beerseba

Sa panahon sa Daang Kasabotan, ang Beerseba usa ka siyudad nga nahimutang mga 45 ka milyas sa habagatang-kasadpan sa Jerusalem sa deserto nga karon gitawag na nga Negev.

* Ang deserto nga nagpalibot sa Beerseba usa ka kamingawan nga dapit nga diin si Hagar ug si Ismael naglibot-libot pagkahuman nga gipalayas sila ni Abraham palayo sa iyang balongbalong.
* Ang ngalan niini nga siyudad nagpasabot "ang atabay sa pagpanumpa." Ginganlan kini sa dihang si Abraham  nanumpa nga dili niya silotan ang mga tawo ni haring Abimelech sa ilang pag-ilog sa usa sa mga atabay ni Abraham.


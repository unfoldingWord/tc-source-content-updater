# pagluwas, luwas

Ang pulong nga "pagluwas" nagtumong sa pagpanalipod sa usa ka tawo o butang aron dili makasinati ug dautan o kasakit.  Ang "mahimong luwas" nagpasabot nga mapanalipdan sa kasakit o kakuyaw.

* Ang pulong nga "rescue" sa Ingles adunay sama nga pasabot apan kasagaran nagpasabot kini nga ang usa ka tawo gikuha gikan sa sitwasyon diin nakasinati na siya daan ug kasakit.
* Sa pisikal nga bahin, ang mga tawo pwede maluwas gikan sa kasakit, kakuyaw o kamatayon.
* Sa espirituhanong bahin, kung "naluwas" ang usa ka tawo, nagpasabot kini nga pinaagi sa kamatayon ni Jesus sa krus, gipasaylo na siya sa Dios ug giluwas siya gikan sa silot sa impiyerno tungod sa iyang sala.
* Ang mga tawo makaluwas sa ubang tawo gikan sa kakuyaw, apan ang Dios lang ang makaluwas sa mga tawo sa walay kataposang pagsilot sa ilang mga sala.

Mga Sugyot sa Paghubad:

* Ang mga pamaagi sa paghubad sa "pagluwas" apil ang “ipalayo” o "panalipdan sa kasakit" o "kuhaon gikan sa kasakit" o "ilikay sa kakuyaw."
* Ang pulong nga "luwas" pwede hubaron nga "gipanalipdan sa kasakit" o "luwas sa kasakit" o "anaa sa lugar nga walay makapasakit."
* Ang pulong nga "pagluwas" pwede sad hubaron nga "pagkuha gikan sa."


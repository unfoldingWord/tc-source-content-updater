# Dalila

Si Dalila usa ka Filistihanong babaye nga gihigugma ni Samson apan dili siya asawa niya.

* Gisuholan si Dalila sa mga Filistihanon nga limbongon si Samson aron sultihan siya niya kung unsaon nga maluya si Samson. Niadtong nawala na ang iyang kakusog, gidakop siya sa mga Filistihanon.
* Mas gihigugma ni Dalila ang kwarta kaysa kang Samson.


# Balaang Espiritu, Espiritu sa Dios, Espiritu sa Ginoo

Kini nga mga pulong tanan nagtumong sa Balaang Espiritu nga Dios. Siya ang tinuod nga Dios daan na nga anaa nga walay sinugdanan ug walay kataposan ingon nga Amahan, Anak, ug Balaang Espiritu.

* Ang Balaang Espiritu gitawag sad nga "ang Espiritu" ug "ang Espiritu ni Yahweh" ug "ang Espiritu sa kamatuoran."
* Tungod kay Dios ang Balaang Espiritu, balaan gyud siya, putli sa tanan, ug moral nga walay sayop sa tanan niyang kinaiya ug tanan niyang gibuhat.
* Uban ang Amahan ug ang Anak, naglihok ang Balaang Espiritu sa paglalang sa kalibotan. 
* Niadtong nibalik sa langit ang Anak sa Dios nga si Jesus, gipadala sa Dios ang Balaang Espiritu ngadto sa iyang mga katawhan aron pangulohan, tudloan, hupayon, ug hatagan sila ug gahum nga magbuhat sa kabubut-on sa Dios.
* Gigiyahan sa Balaang Espiritu si Jesus ug gigiyahan sad niya ang tanan nga mitoo kang Jesus.

Mga Sugyot sa Paghubad:

* Kini nga pulong pwede hubaron sa mga pulong nga gigamit sa paghubad sa "balaan" ug "espiritu."
* Ang mga pamaagi sa paghubad niini nga pulong pwede ang "Putli nga Espiritu" o "Espiritu nga Balaan" o "Dios Espiritu."


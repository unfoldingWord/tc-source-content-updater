# Horeb

Ang Bukid sa Horeb mao ang lain nga ngalan sa Bukid sa Sinai diin gihatag sa Dios kang Moises ang mga papan nga bato diin gisulat ang napulo ka mga sugo. 

* Ang Horeb mao ang lugar diin nakita ni Moises ang nagdilaab nga sampinit niadtong nag-atiman siya sa mga karnero.
* Kini sad ang lugar diin giingnan sa Dios si Moises nga bunalan niya ang bato aron maghatag kini ug tubig alang sa mga Israelita nga giuhaw sa ilang paglibotlibot sa disyerto.
* Wala nahibaw-an ang sakto nga lugar niini nga bukid, apan pwede nga makita kini sa habagatang bahin sa "Peninsula" sa Sinai. 
* Gituohan sa ubang mga eskolar nga ang "Horeb" mao gyud ang ngalan sa bukid ug ang " Bukid sa Sinai" nagtumong sa lugar kung asa dapit kini sa disyerto sa Sinai.


# Kamanduan

Ang pulong nga "kamanduan" nagtumong sa gahum, pagmando, o awtoridad ngadto sa mga tawo, mga mananap, o lugar.

* Si Jesu Cristo adunay kamaduan sa tibuok kalibutan, isip nga propeta, pari, ug hari.
* Napildi sa kahangturan ang kamanduan ni Satanas pinaagi sa pagkamatay ni Jesu Cristo sa krus. 
* Sa panahon sa paglalang, nag-ingon ang Dios nga ang tawo adunay kamanduan sa mga isda, mga langgam, ug sa tanang gilalang sa kalibutan.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang ubang mga pamaagi sa paghubad niini nga pulong mahimong apil ang "awtoridad" o "gahum" o "pagmando."
* Ang mga grupo sa pulong nga "adunay kamanduan" pwede mahubad nga "maghari" o "magdumala."


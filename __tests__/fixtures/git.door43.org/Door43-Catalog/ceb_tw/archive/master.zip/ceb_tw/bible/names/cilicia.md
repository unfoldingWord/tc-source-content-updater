# Cilicia

Ang Cilicia gamay nga probinsiya sa Roma nga makit-an sa sidlakan nga bahin sa gitawag karon sa bag-ong panahon nga nasod sa Turkey. Giutlanan niya ang Dagat nga Aegean.

* Ang apostol nga si Pablo, lungsoranon sa siyudad sa Tarso nga naa sa Cilicia.
* Si Pablo mipuyo pipila ka tuig sa Cilicia pagkahuman sa pagkatagbo niya kang Jesus sa dalan sa Damasco.
* Ang uban nga mga Judio sa Cilicia kauban niadtong mga nagsukmat kang Esteban.


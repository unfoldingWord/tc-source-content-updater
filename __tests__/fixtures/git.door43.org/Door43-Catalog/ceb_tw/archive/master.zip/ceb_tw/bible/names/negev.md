# Negev

Ang Negev usa ka disyerto nga rehiyon sa habagatan nga bahin sa Israel.

* Ang orihinal nga pulong nagpasabot nga "Ang Habagatan" ug ingon niini ang paghubad sa ubang mga bersyon sa Biblia nga Ingles.
* Pwede nga lahi kini nga habagatang rehiyon sa Disyerto sa Negev karon.
* Niadtong nagpuyo si Abraham sa siyudad sa Cades, didto siya sa Negev o habagatan nga dapit.
* Ang mga Judio nga tribo sa Juda ug Simeon nagpuyo niini nga lugar sa habagatang rehiyon.
* Ang kinadak-ang siyudad sa rehiyon sa Negev mao ang Berseba.


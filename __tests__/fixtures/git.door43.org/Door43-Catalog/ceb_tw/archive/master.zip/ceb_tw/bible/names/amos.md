# Amos

Si Amos usa ka Israelitang propeta nga nagpuyo sa panahon ni Haring Uzzia sa Juda. Nabuhi sad siya sa panahon ni propetang Isaias.

* Usa gitawag nga propeta, si Amos nagpuyo sa gingharian sa Juda nga usa ka pastol ug magtatanom ug mga egira.
* Si Amos nagpropesiya sa mauswagon nga gingharian sa norteng dapit sa Israel mahitungod sa ilang dili matarong nga tinagdan sa mga tawo.


# panagtigom

Ang pulong nga "panagtigom" nagtumong sa mahigalaong pakig-usa sa mga tawo nga susama ug gusto ug kasinatian.

* Sa Biblia, ang pulong nga "panagtigom" kasagarang nagtumong sa panaghiusa sa mga tumutuo kang Cristo.
* Ang Kristohanonong panagtigom usa ka relasyon nga giambitan sa mga tumutuo sa usa'g usa pinaagi sa ilang relasyon kang Cristo ug sa Balaang Espiritu.
* Ang unang mga Kristohanon nagpakita sa ilang panagtigom pinaagi sa pagpaminaw sa katudloan sa pulong sa Dios, ug sa tingub nga pag-ampo ug pinaagi sa pakig-ambit sa ilang mga kabtangan ug pagkaon nga dungan.
* Ang mga Kristohanon aduna say panagtigom sa Dios pinaagi sa ilang pagtuo kang Jesus ug sa iyang sakripisyo nga pagkamatay sa krus nga nagtangtang sa babag taliwala sa Dios ug sa mga tawo.

Mga Sugyot sa Paghubad

* Ang pamaagi sa paghubad sa "panagtigom" pwede sad "pakig-ambitay" o "relasyon sa usa'g usa" o "panag-uban" o "kumonidad sa mga Kristohanon."


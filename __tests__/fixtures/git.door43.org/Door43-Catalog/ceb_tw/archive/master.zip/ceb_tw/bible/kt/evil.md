# Dautan, Madinauton, Pagkamadinautan

Ang pulong nga "dautan" ug "madinauton" nagtumong kini sa tanan nga mga nagsupak sa balaang kinaiya ug kabubuton sa Dios.

* Ang "dautan" mas naghulagway sa batasan sa usa ka tawo, ang "madinauton" mas magtumong sa binuhatan o kalihukan sa usa ka tawo. Apan, pareparehas lang ang ipasabot niining duha nga mga pulong.
* Ang pulong nga "pagkamadinautan" nagtumong sa pagkatawhanon sa mga tawo nga naghimo ug dautang mga kalihukan.
* Ang resulta sa pagkadautan makita pag-ayo sa pagdagmal sa ubang mga tawo pinaagi sa pagpatay, pangawat, pagbutangbutang o pagkamabangis ug dili maayo nga pagtratar sa uban.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pulong nga "dautan" ug "madinautan" pwede hubaron nga "dili maayo" o "makasasala" o "imoral."
* Ang ubang pamaagi sa paghubad niini pwede sad, "dili buotan" o "dili matarong" o "dili moral."
* Siguraduha gyud nga ang pulong o mga pulong nga gigamit sa paghubad niini nga pulong mohaom sa konteksto nga uyon sa pinulongan nga hubaron.


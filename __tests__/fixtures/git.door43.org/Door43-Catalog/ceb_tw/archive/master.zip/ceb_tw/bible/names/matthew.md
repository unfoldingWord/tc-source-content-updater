# Mateo

Mateo ang ngalan nga gihatag kang Levi, nga anak ni Alpeo. Si Mateo ang usa sa dose nga gipili ni Jesus nga mahimong mga apostoles niya.

* Si Mateo maniningil sa buhis nga gikan sa Capernaum usa niya nahimamat si Jesus.

* Gisulat ni Mateo ang Ebanghelyo nga nagdala sa iyang ngalan.


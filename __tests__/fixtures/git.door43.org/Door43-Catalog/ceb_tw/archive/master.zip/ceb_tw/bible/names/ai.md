# Ai

Sa panahon sa Daang Kasabotan, Ai ang ngalan sa usa ka lungsod sa Canaan nga anaa mga 8 kilometro sa amihanang-kasadpanan sa Jericho. Duol sad ang Ai sa Bethel.

* Pagkahuman mapildi ang Jericho, nangulo si Josue sa mga Israelita sa pag-atake sa Ai apan napildi ang Israel.
* Gipadayag sa Dios ang pagsupak ni Achan kay nangawat siya ug mga linaglag sa Jericho ug gisugo sa Dios ang mga Israelita nga patyon siya ug ang iyang pamilya. Pagkahuman nila ug buhat niadto,  gitugutan sa Dios ang mga Israelita nga pildehon ang lungsod sa Ai sa ikaduha nila nga pag-atake.


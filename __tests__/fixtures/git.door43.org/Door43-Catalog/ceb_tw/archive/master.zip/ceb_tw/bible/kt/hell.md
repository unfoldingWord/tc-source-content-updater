# impiyerno, lanaw sa kalayo

Ang impyerno mao ang kataposang lugar sa walay kahumanang kasakit ug pag-antos diin silotan sa Dios ang tanang misupak batok kaniya ug misalikway sa iyang plano sa pagluwas kanila pinaagi sa sakripisyo ni Jesus. Gitawag sad kini nga "lanaw sa kalayo."

* Gihulagway ang impyerno nga lugar sa kalayo ug grabe gyud nga kasakit.
* Si Satanas ug ang mga dautang espiritu nga misunod kaniya ilabay didto sa impiyerno aron silotan nga walay kataposan.
* Ang mga tawo nga dili motuo sa sakripisyo ni Jesus sa ilang sala ug dili mosalig kaniya aron luwason sila, silotan sa impiyerno hangtod sa kahangtoran.

Mga Sugyot sa Paghubad:

* Tingali kinahanglan lahi ang paghubad sa mga pulong nga "impiyerno" ug "lanaw sa kalayo" tungod kay lainlain ang ilang mga konteksto.
* Ang ubang mga pinulongan dili makagamit sa "lanaw" alang sa "lanaw sa kalayo" tungod kay amg lanaw nagtumong lang sa tubig.
* Ang pulong nga "impiyerno" pwede hubaron nga "lugar sa pagsilot" o "kataposang lugar sa kangitngit ug kasakit."
* Ang pulong nga "lanaw sa kalayo" pwede hubaron nga "dagat nga kalayo" o "dako kaayong kalayo."


# balay ni David

Ang mga pulong nga "balay ni David" sumbingay kini nga nagtumong sa pamilya o kaliwat ni Haring David.

* Pwede sad kini hubaron nga, "ang mga kaliwat ni David."
* Tungod kay si Jesus kaliwat ni David, apil siya sa "balay ni David."
* Usahay ang "balay ni David" nagtumong sa mga tawo nga nabuhi uban sa pamilya ni David.
* Sa miagi nga panahon usahay kini nga pulong kasagaran nagtumong sa tanang kaliwat, apil kadtong mga nangamatay na.
* Tan-awa sad ang pulong sa [[:En:obe:other:house]].


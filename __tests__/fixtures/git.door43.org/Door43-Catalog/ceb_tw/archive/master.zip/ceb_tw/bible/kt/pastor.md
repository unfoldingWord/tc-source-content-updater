# Pastor

Ang pulong nga "pastor" literal nga sama sa pulong nga "pastol." Gigamit kini sama nga titulo alang sa usa ka tawo nga nangulo sa espirituhanon nga bahin sa grupo sa mga tumutuo.

* Sa Ingles nga bersyon sa Biblia, ang pulong nga "pastor" kausa lang nahisgutan sa libro sa taga-Efeso. Sama kini sa pulong nga gihubad nga "pastol" sa ubang bahin sa Biblia.
* Sa pipila ka mga pinulungan, ang pulong nga "pastor" pareho lang sa pulong nga "pastol."
* Sama sad kini sa pulong nga gigamit nga nagtumong kang Jesus ingon nga "maayo nga Pastol."

Mga Sugyot sa Paghubad:

* Mas maayo kung hubaron kini nga "pastol" sa pinulungan diin kini hubaron.
* Ang ubang mga pamaagi sa niini nga pulong pwede nga, "espirituhanong pastol" o "Kristuhanong pangulo nga gapastol."


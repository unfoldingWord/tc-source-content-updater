# kasingkasing

Sa Biblia, ang pulong nga "kasingkasing" kasagaran gigamit nga sumbingay aron magtumong sa hunahuna, pagbati, tumong, o kabubut-on sa usa ka tawo.

* Ang adunay "gahi ug kasingkasing" kasagaran nagpasabot nga ang usa ka tawo gahig ulo nga dili motuman sa Dios.
* Ang mga pulong nga "sa tibuok nako nga kasingkasing"  nagpasabot sa pagbuhat sa usa ka butang nga walay pagpugong nga gusto gyud niya tumanon ang iyang buhaton.
* Ang sumbingay nga "kinasingkasing" nagpasabot nga seryoso ang usa ka tawo sa pagbuhat niini sa iyang kinabuhi.
* Ang mga pulong nga “nagsubo ang kasingkasing” naghulagway sa tawo nga nasubo kaayo. Nasakitan kaayo ang ilang pagbati.

Mga Sugyot sa Paghubad:

* Ang ubang mga pinulongan migamit ug laing-laing parte sa lawas aron magpasabot niini nga mga ideya, sama sa "tiyan" o "atay" imbes nga kasingkasing.
* Ang ubang mga pinulongan mogamit ug usa ka pulong aron ipahayag ang maong mga ideya ug lain sad nga pulong alang sa uban nga ideya.  
* Kung walay ingon niini nga pasabot ang "kasingkasing" o lain pa nga bahin sa lawas ang ubang mga pinulongan, mahimong mogamit ug diretso ug dili sumbingay nga pamaagi. Isulti na lang nga "hunahuna" o "gibati" o "tumong" imbes nga mogamit ug sumbingay.
* Depende sa konteksto, ang mga pulong nga "sa akong tibuok nga kasingkasing" mahimong hubaron nga "sa akong tanang kusog" o "buhaton gyud ang tanan aron" o  "tanang paagi aron.”
* Ang mga pulong nga "kinasingkasing" mahimong hubaron nga "seryosohon" o "hunahunaon ug maayo."
* Ang sumbingay nga "gahi ug kasingkasing" pwede hubaron nga "gahig ulo o pagkamasinupakon" o "dili gyud motuman” o "padayon nga misupak sa Dios."
* Ang mga pulong nga "nagsubo ang kasingkasing” pwede sad hubaron nga "nasubo kaayo" o "nakabati ug sobra nga kasakit."


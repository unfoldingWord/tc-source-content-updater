# Goliat

Si Goliat dako kaayo nga sundalo sa kasundalohan sa mga Filistihanon nga gipatay ni David gamit ang iyang lambuyog ug bato.

* Si Goliat naa sa mga duha o tulo ka metro ang gitas-on. Kasagaran gitawag siya nga higante tungod sa kadako sa iyang lawas.
* Bisan ug maayo kaayo ang mga hinagiban ni Goliat ug dako siya kaayo kung itandi kang David, ang Dios naghatag ug kabaskog ug katakos kaniya aron pildihon si Goliat.
* Gipadayag ang mga Israelita nga madaugon batok sa mga Filistihanon tungod sa kadaogan ni David batok kang Goliat.


# Miqueas

Si Miqueas usa ka propeta sa Juda mga 700 ka tuig sa wala pa gipanganak si Cristo, niadtong panahon nga si propeta Isaias nag-alagad sad sa Juda.

* Ang libro nga Miqueas duol sa kataposan sa Daang Kasabotan.
* Si Miqueas nagtagna mahitungod sa pagkalaglag sa Samaria pinaagi sa mga taga-Asiria.
* Gibadlong ni Miqueas ang mga katawhan sa Juda tungod sa dili nila pagtuman sa Dios ug gipasidad-an sila nga sulongon sila sa ilang mga kaaway.
* Natapos ang iyang pagtagna nga adunay mensahe sa paglaum sa Dios nga matinud-anon ug moluwas sa iyang katawhan.


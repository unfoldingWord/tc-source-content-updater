# Bukid sa Hermon

Ang Bukid sa Hermon mao ang ngalan sa kinatas-ang bukid sa Israel.

* Anaa kini sa amihanan sa Dagat sa Galilea, sa pinaka-amihanan nga utlanan taliwala sa Israel ug Siria.
* Ang ubang ngalan nga gihatag sa Bukid sa Hermon sa ubang mga grupo sa katawhan mao ang "Bukid sa Sirion" ug "Bukid sa Senir."
* Adunay tulo ka dagkong tumoy ang Bukid sa Hermon.


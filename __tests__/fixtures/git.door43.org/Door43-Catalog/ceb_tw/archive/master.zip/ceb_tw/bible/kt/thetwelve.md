# Ang dose, Ang onse

Ang pulong nga "ang dose" nagtumong sa dose ka mga tawo nga pinili ni Jesus nga iyang mga suod nga mga disipulo, o mga apostoles.

* Pagkahuman sa pagkabudhi ni Hudas kang Jesus ug dayon gipatay ang iyang kaugalingon, ang nahabilin nga mga apostoles gitumong nga "ang onse."
* Si Jesus adunay daghan pang ubang mga disipilo, apan ang titulo nga "ang dose" nagpaila sa mga misunod kang Jesus sulod sa iyang tulo ka mga tuig nga ministeryo.
* Ang mga ngalan niini nga mga dose nga mga apostoles natala sa Mateo 10, Marcos 3, ug Lukas 6.
* Sa panahon nga namatay na si Hudas ug wala pa sila kapili ug disipulo nga mopuli niya, gitawag sila nga "ang onse."

Mga Sugyot sa Paghubad:

* Sa daghang mga pinulungan mas maklaro ug mas natural kung idugang ang nombre ug ingnon nga "ang dose ka mga apostoles" o "ang dose ka mga suod nga disipulo ni Jesus."
* "Ang onse" pwede sad hubaron nga "Ang onse nga nahabilin nga mga disipulo ni "Jesus." 
* Ang uban pang paghubad pwede gamiton ang kapital nga letra aron ipakita nga kini gigamit ingon nga titulo, sama sa "ang Dose" ug "ang Onse."


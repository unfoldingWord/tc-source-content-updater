# kasal-anan

Ang pulong nga "kasal-anan" mao ang pulong nga parehas gyud sa pasabot sa pulong nga "sala," apan mas nagtumong kini sa tinuyuan nga mga sayop nga binuhatan o grabe nga pagkadaotan.

* Ang pulong nga "kasal-anan" literal nga nagpasabot nga gisukwahi o gituis (ang balaod). Natumong kini sa pagkawalay hustisya.
* Ang kasal-anan pwede mahulagway nga tinuyo, makadaot nga mga buluhaton sa ubang mga tawo.
* Ang ubang mga pasabot sa kasal-anan mao ang "pagkasukwahi" ug "pagkadaotan," parehas nga mga pulong nga naghulagway sa kahimtang sa grabe nga sala.

 Mga Sugyot sa Paghubad:

* Ang pulong nga "kasal-anan" pwede hubaron nga "pagkadaotan" o "sukwahi nga mga buluhaton" o "makadaot nga mga buluhaton."
* Kasagaran, ang "kasal-anan" kauban sa mga pulong sama sa "sala" ug "kalapasan" mao nga kinahanglang gyud nga adunay lainlaing mga pamaagi sa paghubad niini nga mga pulong.


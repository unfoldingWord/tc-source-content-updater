# Ang dagat, ang Dako nga Dagat, ang kasadpang dagat

Sa Bibilia, ang "Dako nga Dagat" o kasadpang dagat" nagtumong sa gitawag karon nga Dagat sa "Mediteraneo", diin mao kini ang hilabihan ka dako nga tubig nga nailhan sa mga tawo sa panahon sa Biblia.

* Ang Dako nga Dagat sa (Mediteraneo) giutlanan sa: Israel sa Sidlakan, Europa sa amihan ug kasadpan, ug Africa sa habagatan.
* Kini nga dagat importante gyud kaayo sa adtong una pa nga panahon sa negosyo ug pagbiyahe tungod kay giutlanan kini sa daghang mga nasod. Ang mga siyudad ug mga grupo sa mga tawo nga naa sa kabaybayon niini nga dagat adunahan kaayo tungod sa kadali nga makakuha ug mga produkto gikan sa ubang mga nasod pinaagi sa barko.
* Ingon nga ang Dako nga Dagat naa sa kasadpan sa Israel, usahay gitumong kini nga "kasadpang dagat."


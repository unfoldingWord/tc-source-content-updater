# Anak sa Tawo, anak sa tawo

Ang titulo nga "Anak sa Tawo" nailhan gyud nga gigamit ni Jesus sa pagtumong sa iyang kaugalingon. Sa Daang Kasabotan, ang pulong nga "anak sa tawo" usa sad ka pamaagi sa pagtawag sa usa ka tawo.

* Sa Daang Kasabotan, ang mga pulong nga "anak sa tawo" kasagaran nagpasabot nga "lalaki" o "tawo."
* Gigamit sa Dios ang "anak sa tawo" nga usa ka pagtawag, sama niadtong niingon siya kang propetang Ezequiel, "...ikaw, anak sa tawo, kinahanglan managna..." Kini nga klase sa pagtawag gigamit sa tibuok nga libro ni Ezequiel.
* Kasagaran nga gigamit ni Jesus kini nga pulong aron magtumong sa iyang kaugalingon imbes nga "Ako." Pwede sad kini nga mainubsanon nga pamaagi sa pagtumong sa kaugalingon niadto nga panahon.
* Ang propeta nga si Daniel nakakita ug panan-awon sa usa ka "anak sa tawo" nga nanaug gikan sa langit nga gipalibutan ug mga panganod ug kini nagtumong sa moabot nga Mesias. Si Jesus nag-ingon sad nga ang Anak sa Tawo mobalik sa umaabot nga adlaw nga gipalibutan sa mga panganod.
* Paglabay sa daghang katuigan pagkahuman niadto, ang apostol nga si Juan nakakita ug panan-awon sa "anak sa tawo" nga naglingkod sa mga panganod.
* Kini nga mga pagtumong sa Anak sa Tawo nga mobalik, naglingkod, o nagsakay sa mga panganod nagpakita nga si Jesus, Dios.

Mga Sugyot sa Paghubad:

* Sa dihang gigamit ni Jesus ang pulong nga "Anak sa Tawo," ang lain nga pamaagi sa paghubad niini pwede nga, "ang Usa nga nahimong usa ka tawo" o "ang Tawo nga gikan sa langit" o "ang usa nga gikan sa langit."
* Ang pipila sa mga tighubad usahay apilon ang "Ako" sa niini nga titulo.


# Japet

Si Japet usa sa tulo ka mga anak nga lalaki ni Noe nga nahisgutan sa Daang Kasabotan.

* Sa panahon sa lunop sa tibuok kalibutan nga mitabon sa tibuok yuta, si Japet ug ang iyang duha ka mga igsoon ang kauban ni Noe sa arka, uban ang ilang mga asawa.
* Dili klaro kung siya ang kinamanghuran o kinamagwangan nga igsoong lalaki.


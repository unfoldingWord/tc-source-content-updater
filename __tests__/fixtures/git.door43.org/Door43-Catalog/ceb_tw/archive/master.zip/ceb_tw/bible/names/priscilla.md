# Priscila

Si Priscila, Judio nga Kristohanon sa unang siglo kauban ang iyang bana nga si Aquila nga mitabang uban kang Pablo sa iyang trabaho nga misyonero.

* Nahimamat ni Pablo si Aquila ug Priscila sa Corinto.
* Nagpuyo si Priscila ug Aquila sa Roma sa mubo nga panahon.
* Nagtrabaho ang magtiayon isip tighimo ug tulda uban ni Pablo ug mitabang kaniya sa iyang trabaho nga misyonero.
* Silang duha ni Aquila ug Priscila gihisgutan sa Bag-ong Kasabotan sa pipila ka mga higayon isip katabang sa ministeryo ni Pablo.
* Si Priscila kasagaran nga gihisgutan nga ehemplo sa usa ka babaye nga magtutudlo sa naunang Iglesia.


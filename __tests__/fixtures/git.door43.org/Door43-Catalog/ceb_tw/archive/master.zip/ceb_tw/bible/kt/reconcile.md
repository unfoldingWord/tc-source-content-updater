# pasig-uli, pagpasig-uli

Ang pulong nga "pasig-uli" ug ang "pagpasig-uli" nagtumong sa "pakigdait" taliwala sa mga tawo nga kaniadto magkaaway.

* Sa Biblia, kini nga pulong kasagaran nagtumong sa Dios nga nagpasig-uli sa mga tawo kaniya pinaagi sa sakripisyo sa iyang Anak nga si Jesu Cristo.
* Tungod sa sala, nahimong kaaway sa Dios ang tanan nga mga tawo. Apan tungod sa iyang maluluy-on nga paghigugma, naghatag ang Dios ug paagi aron ang mga tawo mapasig-uli kaniya pinaagi kang Jesus.
* Pinaagi sa pagsalig sa sakripisyo ni Jesus isip bayad sa ilang sala, ang mga tawo pwede nga mapasaylo ug makigdait sa Dios.

Mga Sugyot sa Paghubad:

* Ang pulong nga "pasig-uli" pwede sad hubaron nga "pakigdait" o "ibalik ang maayo nga relasyon" o "hinungdan nga mahimong higala."
* Ang pulong nga "pagpasig-uli" pwede hubaron nga "ibalik ang maayo nga relasyon" o "pakigdait" o "hinungdan sa malinawon nga relasyon."


# Kora

Ang Kora ngalan sa duha ka lalaki sa Daang Kasabotan.

* Ang usa sa mga anak ni Esau ginganlan ug Kora. Nahimo siyang pangulo sa iyang kumonidad.
* Ang lain nga Kora kaliwat ni Levi nga nag-alagad sa tabernakulo isip pari. Nangabugho siya sa posisyon ug awtoridad nga gihatag sa Dios kang Moises ug Aron. 
* Nagluib siya kauban ni Datan ug Abiram aron danihon ang mga tawo sa Israel sa pagrebilde batok sa mga pangulo nga gihatag sa Dios kanila.


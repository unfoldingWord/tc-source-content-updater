# Awtoridad

Ang pulong nga "awtoridad" nagtumong sa gahum sa usa ka tawo nga makaimpluwensya ug makakontrolar ug lain nga tawo.

* Ang mga hari ug ang uban nga nangulo sa gobyerno adunay awtoridad sa mga tawo nga ilang gipanguluhan.
* Ang pulong nga "mga awtoridad" nagtumong sa mga tawo, mga gobyerno, o mga organisasyon nga adunay awtoridad sa mga sakop nila.

Mga Sugyot sa Paghubad

* Ang awtoridad pwede sad mahubad nga "nagkontrolar" o "katungod" o "kuwalipikasyon."
* Usahay ang pulong nga "awtoridad" gigamit nga nagpasabot sa "gahum" o "abilidad."
* Kung ang "awtoridad" gigamit nga magtumong sa mga tawo o organisasyon nga nangulo sa mga tawo, pwede kini mahubad nga "mga pinuno" o "mga nangulo" o "mga gamhanan."
* Ang mga pulong nga "sa iyang kaugalingong awtoridad" pwede sad mahubad nga, "naa siyay katungod nga mangulo sa iyang kaugalingon" o "base sa iyang kaugalingon nga kuwalipikasyon."


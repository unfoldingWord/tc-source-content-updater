# pagpakita, pagpadayag

Ang pulong nga "pagpakita" buot ipasabot hinungdan nga ang usa ka butang makita o mahibalo-an. Ang "pagpadayag" usa kini ka butang nga gipakita o gibutyag.

* Sa Biblia, ang pulong nga "pagpakita" kasagaran gigamit sa paghulagway kung giunsa sa pagpaila sa Dios ang iyang kaugalingon sa mga tawo. 

* Gipakita sa Dios ang iyang kaugalingon pinaagi sa tanan nga butang nga iyang gilalalang ug pinaagi sa iyang pakigsulti sa mga tawo pinaagi sa nasulti o nasulat nga mga mensahe.
* Daghang panahon sa Biblia, nga ang Dios nagpakita sad pinaagi sa mga damgo o mga panan-awon. Gipakita sad niya ang iyang kaugalingon ngadto sa mga tawo pinaagi sa mga damgo ug mga panan-awon niini nga panahon.
* Sa dihang si Pablo nagtumong sa pagdawat sa Ebanghelyo pinaagi sa "padayag gikan kang Jesu Cristo," gipasabot niya nga si Jesus ang nagpatin-aw kaniya sa Ebanghelyo.
* Ang libro nga gitawag nga "Pagpadayag" mahitungod kini sa pagpakita sa Dios sa mga mahitabo sa ulahi nga mga panahon. Gihimo niya kini pinaagi sa sumpay-sumpay nga mga panan-awon nga gihatag niya kang apostol Juan. 

Mga Sugyot sa Paghubad:

* Uban nga paagi sa paghubad sa "pagpakita" pwede ang "ipahibalo" o "gipahayag" o "klaro nga gipakita."
* Depende sa konteksto, posible nga mga paagi sa paghubad sa "pagpadayag" pwede ang "mensahe" o "pakigsulti gikan sa Dios" o "mga butang nga gipakita sa Dios" o "mga katudlu-an gikan sa Dios."
* Ang mga pulong nga "kung walay pagpadayag" pwede hubaron nga "sa dihang dili ipakita sa Dios ang iyang kaugalingon ngadto sa mga tawo" o "sa dihang ang Dios wala makigsulti sa mga tawo" o "sa mga tawo nga ang Dios wala makigsulti kanila."


# Abija

Abija ang ngalan sa usa ka hari sa Juda nga naghari gikan sa katuigan nga 915 hangtod sa 913 sa wala pa gipanganak si Cristo. Siya ang anak nga lalaki ni Haring Rehoboam. Naa say laing mga lalaki nga ginganlag Abija sa Daang Kasabotan. 

* Ang usa ka Abija sa Daang Kasabotan mao ang anak nga lalaki ni Samuel nga nangulo sa mga katawhan sa Israel sa Beersheba, kauban ang iyang igsoon nga si Joel. 
* Sila Abija ug Joel mga malimbongon ug hakog nga mga pangulo, mao nga nanghangyo ang mga tawo kang Samuel nga magpili ug hari aron pangulohan sila. 
* Kaniadtong panahon ni Haring David, ang ngalan sa usa sa mga pari sa templo si Abija.
* Abiha sad ang ngalan sa usa sa mga anak ni Haring Jeroboam. 
* Abiha sad ang ngalan sa kinatas-ang pari nga mibalik sa Jerusalem uban kang Zorobabel gikan sa pagkabinihag nila didto sa Babilonia.


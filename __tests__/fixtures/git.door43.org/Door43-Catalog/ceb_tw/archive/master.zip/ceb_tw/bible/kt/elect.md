# ang pinili, pinili nga katawhan, ang Pinili, gipili

Ang pulong nga, "gipili" literal nga nagpasabot nga "ang mga pinili" o "ang pinili nga mga tawo" ug nagtumong adtong mga pinili sa Dios o gipili nga mahimo niyang katawhan. "Ang Pinili" o "Ang Pinili sa Dios” titulo kini nga nagtumong kang Jesus, ang pinili nga Mesias.

* Gipili sa Dios ang mga tawo nga mahimong balaan, nga igahin niya sa katuyuan nga mamunga ug maayong espirituhanong bunga. Mao nga sila gitawag nga "ang mga gipili" o "ang pinili."
* Ang pulong nga "ang pinili" usahay gigamit sa Biblia nga nagtumong sa mga tawo nga sama nila ni Moises ug Haring David nga diin gipili sa Dios aron mangulo sa iyang katawhan. Gigamit sad kini nga nagtumong sa nasod sa Israel nga pinili nga katawhan sa Dios.
* Ang pulong nga "gipili" daan nga pulong nga ang literal nga buot pasabot "ang pinili" o "pinili nga mga tawo." Kung gamiton kini nga mga pulong sama sa "ang pinili nga babaye" ang buot pasabot lang niini "pinili."
* Sa daan nga Inglis nga mga bersyon sa Biblia, ang pulong nga "pinili" parehas nga gigamit sa Daan ug Bag-o nga Kasabotan sa paghubad sa pulong nga "ang pinili/mga pinili." Ang mga moderno nga mga bersyon migamit sa "gipili" sa Bag-ong Kasabotan lang, nga nagtumong sa mga tawo nga diin giluwas sa Dios pinaagi sa pagtoo kang Jesus. Sa uban nga teksto sa Biblia, literal ang ilang paghubad nga "mga pinili."

Sa Sugyot sa Paghubad

* Ang pulong nga "gipili" o "pinili nga mga tawo/katawhan" pwede sad nga hubaron nga "mga tawo nga gipili sa Dios" o "mga tawo nga gipili niya aron mahimong katawhan niya."
* Kung pwede, mas maayo nga hubaron kini nga pulong nga literal nga "pinili nga mga tawo" o "pinili nga katawhan."
* Kung nagtumong kang Jesus, "Ang Pinili" pwede sad hubaron nga, "Ang pinili sa Dios" o "ang  pinasahi nga gipili sa Dios nga Mesias" o "ang gipili  sa Dios."


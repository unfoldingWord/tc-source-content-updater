# amen, pagkatinood

Ang pulong nga "amen" gigamit aron maghatag ug importansiya o pagtagad sa unsa ang giingon sa tawo. Kasagaran hubaron kini nga "pagkatinood" kung si Jesus ang nagsulti niini.

* Kung gamiton sa kataposan sa pag-ampo, ang "amen" nagpahayag ug pag-uyon sa pag-ampo o tinguha nga matuman ang pag-ampo.
* Sa iyang pagtudlo, gigamit ni Jesus ang "amen" aron pamatud-an sa bag-o lang nga gisulti niya. Kasagaran sundan kadto niya ug "Ug ako misulti kaninyo" aron maghisgot na sad siya ug lain nga katudluan nga konektado sa iyang bag-o lang giingon.
* Ang uban nga mga Ingles nga bersyon naghubad niini nga "truly" o "pagkatinood." Gigamit kini aron hatagan ug importansiya ang usa ka butang o magpahayag nga matinud-anon o tinuod ang gisulti.

Mga Sugyot sa Paghubad:

* Hunahunaa kung ang pinulongan nga hubaron adunay pinasahi nga mga pulong nga gigamit aron maghatag ug importansiya sa unsay bag-o lang giingon.
* Kung gigamit sa kataposan sa pag-ampo o aron pamatud-an ang usa ka butang, mahimong hubaron ang "amen" nga "mao gyud na" o "hinaut unta mahitabo" o "tinuod kana."
* Kung moingon si Jesus ug "sa pagkatinood nag-ingon ako kaninyo," kini mahimong hubaron nga "matinud-anon akong gasulti kaninyo" o "Tinuod kana, ug ako miingon sad kaninyo."
* Ang mga pulong nga "Pagkatinood, pagkatinood nag-ingon ako kaninyo" mahimong hubaron nga "Nagsulti ako kaninyo niini nga matinud-anon gyud" o "Nagsulti ako kaninyo niini nga tininuod gyud" o "tinuod ang akong gisulti kaninyo."


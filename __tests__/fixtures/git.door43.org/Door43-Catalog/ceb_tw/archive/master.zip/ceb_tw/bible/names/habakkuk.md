# Habacuc

Si Habacuc usa ka propeta sa Daang Kasabotan nga tingali nabuhi sa kapanahunan sa paghari ni Haring Joakim sa Juda.

* Kini nga propeta nagsulat sa libro nga Habacuc una pa nabuntog ang Jerusalem sa mga taga-Babilonia niadtong mga 600 ka tuig sa wala pa gipanganak si Cristo.
* Kasagaran nagtagna si Habacuc mahitungod sa mga Caldehanon (taga-Babilonia) ug siya kadungan ni propetang Jeremias sa sinugdanan.
* Usa sa labing impluwensiyal nga pamahayag ni Habacuc mao ang: "ang matarong nga tawo magkinabuhi pinaagi sa iyang pagtuo."


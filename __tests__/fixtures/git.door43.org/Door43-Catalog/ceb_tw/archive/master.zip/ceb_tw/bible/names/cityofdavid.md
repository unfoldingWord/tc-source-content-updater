# Siyudad ni David

Ang "Siyudad ni David" lain kini nga ngalan sa Jerusalem ug sa Betlehem.

* Sa Jerusalem nagpuyo si David samtang gamando siya sa Israel.
* Sa Betlehem gipanganak si David.


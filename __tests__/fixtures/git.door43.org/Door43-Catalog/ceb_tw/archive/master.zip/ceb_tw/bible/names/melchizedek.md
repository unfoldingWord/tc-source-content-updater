# Melquisedec

Kaniadtong panahon nga nabuhi si Abram, si Melquisedec mao ang hari sa Salem (kadugayan gitawag nga Jerusalem). Gitawag sad siya nga "pari sa Dios nga Labing Taas."

* Ang ngalan ni Melquisedec nagpasabot nga "hari sa pagkamatarong."
* Niadtong nidaog si Abram sa panagsangga sa mga gamhanan nga mga hari, gipanalanginan ni Melquisedec si Abram ug gisilbihan niya si Abram ug pan ug bino.
* Unya gihatagan ni Abram si Melquisedec ug ika-pulo sa tanang kabtangan nga nakuha niya sa iyang pagkadaug.
* Sa Bag-ong Kasabotan, si Jesus gitawag nga pari "sa laray ni Melquisedec." Mahimo nga nagtumong kini sa kamatuoran nga si Jesus dili sama sa mga Israelitang pari nga nahimong pari tungod kay kaliwat sila ni Levi. Hinuon, siya ang atong Gamhanang Kinatas-ang Pari nga nahimong pari tungod gyud kay Dios siya ug dili tungod kay kaliwat siya sa usa ka tawo.


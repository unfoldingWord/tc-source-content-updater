# Eva

Mao kini ang ngalan sa unang babaye. Ang buot ipasabot sa iyang ngalan “kinabuhi” o “buhi.”

* Gihulma mismo sa Dios si Eva pinaagi sa gusok nga iyang gikuha gikan kang Adan.
* Si Eva gihimo aron mahimong “katabang” ni Adan. Kanunay nga nakig-uban si Eva kang Adan aron sa pagtabang kaniya sa trabaho nga gihatag kaniya.
* Si Eva gitintal sa bitin (Satanas) ug siya mao ang unang nakasala pinaagi sa pagkaon sa prutas nga giingon sa Dios nga dili kaunon.


# ulahing adlaw, ulahing mga adlaw, sa moabot nga mga adlaw

Ang pulong nga "ulahing mga adlaw" kasagaran nagtumong sa panahon nga si Jesus mobalik.

* Kini nga panahon wala gyu'y nakahilo kanus-a mahitabo o moabot.
* Ang "ulahing  adlaw" panahon kini sa pagbanhaw ug paghukom sa katapusan sa panahon.
* Si Jesus nag-saad sa iyang mga taga-sunod nga sila iyang bangunon ngadto sa kinabuhi "sa ulahi nga adlaw."

Mga Sugyot sa Paghubad:

* Ang pulong nga "ulahi nga mga adlaw" pwede sad hubaron nga "katapusan nga mga adlaw" o "katapusan nga mga panahon" o "sa pagkahuman sa panahon."
* Mga paagi sa paghubad sa "sa ulahi nga adlaw" pwede sad, "katapusan sa panahon sa kalibutan" o "panahon sa katapusan" o "ulahi nga panahon."


# kasabotan

Ang kasabotan usa ka pormal ug walay kausaban nga sabot taliwala sa duha ka partidos nga kinahanglan tumanon sa usa o duha nga partidos.

* Kini nga kasabotan mahimong taliwala sa mga tawo, taliwala sa grupo sa mga tawo, o taliwala sa Dios ug mga tawo.
* Kung maghimo ug kasabotan ang mga tawo sa usa'g usa, mosaad sila nga buhaton nila ang usa ka butang ug kinahanglan gyud kini nila buhaton.
* Ang mga ehemplo sa mga kasabotan sa mga tawo apil ang kasabotan sa pagminyo, mga kasabotan sa negosyo, ug mga kasabotan taliwala sa mga nasod.
* Sa Biblia, naghimo ang Dios ug pipila ka mga kasabotan uban sa iyang katawhan.
* Sa ubang mga kasabotan, nisaad ang Dios nga tumanon ang iyang bahin nga walay kinahanglan buhaton ang mga tawo. Pananglitan, niadtong gihimo sa Dios ang iyang kasabotan sa katawhan, nisaad siya nga dili na gyud niya gub-on ang kalibutan pinaagi sa paglunop sa tibuok kalibotan. Kini nga saad walay kinahanglang buhaton ang mga tawo.
* Sa ubang mga kasabotan, gisaad sa Dios nga tumanon lang niya ang iyang bahin kung tumanon siya sa mga tawo ug buhaton ang ilang bahin sa kasabotan.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang mga pamaagi sa paghubad niini nga pulong pwede nga "walay kausaban nga sabot" o "pormal nga pasalig" o "panumpa" o "kontrata."
* Basin ang ubang mga pinulongan adunay lain nga pulong alang sa kasabotan depende kung ang usa o parehas nga partidos naghimo ug saad nga kinahanglan gyud nila buhaton. Kung usa lang nga partido ang  kinahanglan motuman sa kasabotan, mahimo kining hubaron nga "saad" o "panumpa."
* Siguradoha nga ang paghubad niini nga pulong dili mogawas nga murag ang tawo ang nanguna sa kasabotan. Sa tanang mga kasabotan taliwala sa Dios ug katawhan, ang Dios ang una nga naghimo sa kasabotan.


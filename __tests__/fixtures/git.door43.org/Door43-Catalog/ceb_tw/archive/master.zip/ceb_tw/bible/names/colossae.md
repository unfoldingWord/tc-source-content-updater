# Colosas, taga-Colosas

Sa panahon sa Bag-ong Kasabotan, ang Colosas usa ka siyudad nga makita sa Romano nga probinsiya sa Phrygia, nga mao ang usa ka lugar nga gitawag karon nga habagatan-kasadpanan bahin sa Turkey. Ang mga taga-Colosas mga tawo nga nagpuyo sa Colosas.

* Naa sa mga 100 ka milya gikan sa Dagat sa Mediteraneo, ang Colosas nahimutang kini sa importante nga agianan sa mga negosyante taliwala sa siyudad sa Efeso ug suba sa Eufrates.
* Samtang didto sa prisohan sa Roma, gisulat ni Pablo ang libro nga gitawag nga "Taga-Colosas," sulat kini alang sa mga tumutuo sa Colosas aron tarungon ang  mga sayop nga katudluan.
* Niadtong gisulat niya kini, wala pa siya makabisita sa iglesia sa Colosas apan nakadungog na siya mahitungod sa mga tumutuo didto gikan sa iyang kauban sa buluhaton nga si Epapras.
* Si Epapras mao tingali ang nagsugod sa iglesia sa Colosas.
* Ang libro nga Filemon gisulat ni Pablo sa usa ka taga Colosas nga tag-iya ug mga ulipon.


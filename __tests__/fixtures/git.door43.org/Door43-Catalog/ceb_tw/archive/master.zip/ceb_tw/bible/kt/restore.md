# pagpasig-uli

Ang pagpasig-uli nagpasabot sa pagdala sa usa ka tawo o butang pabalik sa iyang orihinal ug maayo nga kahimtang.

* Sa dihang mapasig-uli ang bahin sa lawas nga may sakit, nagpasabot kini nga naayo na siya."
* Ang nadaut nga relasyon nga napasig-uli, "nahibalik na ang pakigdait." Gipasig-uli sa Dios ang makasasala nga mga tawo ug "gidala sila pabalik" ngadto kaniya.

* Sa dihang ang kabtangan mapasig-uli, nagpasabot kini nga "naayo na," o "napulihan," o "gibalik sa" tag-iya.

* Kung ang mga tawo mapasig-uli sa ilang kaugalingong nasod nagpasabot kini nga "gidala pabalik" didto.

Mga Sugyot sa Paghubad:

* Ang pamaagi sa paghubad sa "pagpasig-uli" pwede sad: "pagbag-o, o "pagbayad" o "pagbalik" o "pag-ayo" o "pagpabalik."
* Ang sumbingay niini nga pulong pwede sad "himuon nga bag-o na usab."
* Depende sa konteksto ang "pagpasig-uli," pwede hubaron nga "bag-ohon" o "ayuhon" o "pagpakigdait."


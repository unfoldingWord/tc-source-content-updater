# anti-Cristo

Ang pulong nga "anti-Cristo" nagtumong sa tawo o pagtudlo nga batok kang Jesu Cristo ug sa iyang mga binuhatan. Daghang mga anti-Cristo sa kalibutan.

* Ang apostol nga si Juan nagsulat nga ang usa ka tawo mao ang anti-Cristo kung iyang linlangon ang mga tawo sa pagsulti nga dili si Jesus ang Mesiyas o kung iyang ilimod nga si Jesus parehas Dios ug tawo.
* Ang Biblia nagtudlo sad nga adunay espiritu sa anti-Cristo sa kalibutan nga nagsupak sa mga binuhatan ni Jesus.
* Ang libro sa Bag-ong Kasabotan nga Pinadayag nagpatin-aw nga adunay tawo nga gitawag nga "ang anti-Cristo" nga ipadayag sa kataposang panahon. Kini nga tawo mosulay ug laglag sa katawhan sa Dios apan pildehon siya ni Jesus.

Mga Sugyot sa Paghubad:

* Ang ubang pamaagi sa paghubad niini nga pulong naglakip sa mga pulong nga nagpasabot nga "tig-supak kang Cristo" o "kaaway ni Cristo" o "tawo nga batok kang Cristo."
* Ang mga pulong nga "espiritu sa anti-Cristo" mahimong hubaron nga "espiritu nga batok kang Cristo."


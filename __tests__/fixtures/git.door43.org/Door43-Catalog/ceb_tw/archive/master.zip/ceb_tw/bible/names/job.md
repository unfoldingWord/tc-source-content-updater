# Job

Si Job usa ka tawo nga gihulagway sa Biblia nga walay sala ug matarong atubangan sa Dios. Nailhan siya sa paglahutay sa iyang pagtuo sa Dios bisan pa sa panahon sa makalilisang nga pag-antos ug kaguol.

* Gihunahuna nga si Job nabuhi sa kalibutan paghuman sa baha sa tibuok kalibutan sa panahon ni Noe sa wala pa ang panahon ni Abraham.
* Gibanabana nga duha ka gatos ka tuig ang katigulangon ni Job usa siya namatay.
* Ang libro nga Job sa Biblia nagsulti mahitungod sa iyang pag-antos pinaagi sa daghang mga malaglagong panghitabo sa iyang kinabuhi. Nagsulti sad kung giunsa niya pag-atubang sa iyang pag-antos, ug sa paglantaw sa Dios nga makagagahum sa tanan nga tiglalang ug nangulo sa kalibutan.
* Paghuman sa tanang mga katalagman,  gibalik sa Dios kang Job ang tanan ug hilabihan gyud siya gipanalanginan sa Dios ug pamilya ug bahandi.


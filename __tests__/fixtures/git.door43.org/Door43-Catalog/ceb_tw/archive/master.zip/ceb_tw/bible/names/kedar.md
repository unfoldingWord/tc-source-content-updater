# Kedar

Si Kedar ngalan sa ika-duhang anak ni Ismael ug daghang panon nga mga tawo ang nagagikan kaniya. Aduna say ilado nga siyudad nga ginganlan ug Kedar.

* Ang siyudad sa Kedar naa sa amihanang bahin sa Arabia duol sa habagatang bahin nga utlanan sa Philistia. Sa panahon sa Biblia, nailhan kini sa iyang pagkagamhanan ug kaanyag.
* Ang mga pulong nga "ang itum nga mga balongbalong sa Kedar" nagtumong sa mga balongbalong nga hinimo sa itum nga balahibo sa mga kanding nga gipoy-an sa mga taga Kedar.
* Sa Biblia, ang mga pulong nga "ang himaya sa Kedar" nagtumong sa pagkagamhanan sa siyudad ug sa iyang mga tawo.


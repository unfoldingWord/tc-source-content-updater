# Natan

Si Natan usa ka matinud-anon nga propeta sa Dios nga nabuhi niadtong si David ang hari sa Israel.

* Gipadala sa Dios si Natan aron sultihan si David sa iyang hilabihang sala batok kang Urias.
* Gibadlong ni Natan si David, bisan pa nga si David mao ang hari.
* Naghinulsol si David sa iyang sala pagkahuman sa pagsulti ni Natan kaniya.


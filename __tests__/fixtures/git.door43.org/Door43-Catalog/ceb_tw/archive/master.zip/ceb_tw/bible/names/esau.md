# Esau

Si Esau usa sa kaluha nga anak ni Isaac ug Rebeka. Siya ang unang gipanganak. Ang iyang kaluha mao si Jacob.

* Gibaligya ni Esau ang iyang katungod sa pagkamaguwang sa iyang igsoon nga si Jacob baylo sa usa ka yahong nga pagkaon.
* Tungod kay si Esau ang unang gipanganak, sa iya unta ihatag ang pinasahi nga panalangin nga gikan sa iyang amahan, apan gikawat kini ni Jacob. Hilabihan ang kasuko ni Esau nga nagtinguha unta siya sa pagpatay kang Jacob, apan sa kadugayan iya gihapon kining gipasaylo.
* Si Esau daghan ug mga anak ug mga apo, kining iyang mga kaliwatan nahimong usa ka dakong pundok sa katawhan nga nagpuyo sa Canaan.


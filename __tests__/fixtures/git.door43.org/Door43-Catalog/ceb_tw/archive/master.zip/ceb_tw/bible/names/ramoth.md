# Ramot

Importante nga siyudad ang Ramot nga nahimutang sa mga bukid sa Gilead. Gitawag sad kini ug Ramot Gilead.

* Naapil ang Ramot sa Israelitang tribu sa Gad ug gigahin nga siyudad nga dalangpanan.
* Si Haring Ahab sa Israel ug Haring Josafat sa Juda naglunsad ug giyera batok sa hari sa Aram sa Ramot. Napatay si Ahab niadto nga gubat.
* Sa kadugayan si Haring Ahasias ug Haring Joram misulay sa pag-ilog sa siyudad sa Ramot gikan sa hari sa Aram apan nasamaran si Joram. Napatay silang duha ni Jehu nga sa kadugayan napili nga hari sa Israel didto sa Ramot.


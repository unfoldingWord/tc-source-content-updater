# Jehoram

Ang Jehoram mao ang ngalan sa mga duha ka mga hari sa Daang Kasabotan.

* Ang usa mao ang anak nga lalaki ni Josaphat ug nahimong hari sa Juda.
* Ang usa sad nga Jehoram mao ang anak nga lalaki ni Ahab ug hari sa Israel. Kini nga hari ilado sad sa ngalan nga "Joram."


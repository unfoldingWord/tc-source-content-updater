# Ahasias/Ochozias

Ahasias ang ngalan sa duha ka mga hari: ang usa naghari sa gingharian sa Israel, ang usa naghari sa gingharian sa Juda.

* Si Haring Ahasias sa Juda anak ni Haring Jehoram. Naghari siya sulod sa usa ka tuig (sa ika 841 nga tuig sa wala pa gipanganak si Cristo) unya gipatay siya ni Jehu. Sa wala magdugay, ang kinamanghurang anak ni Ahasias nga si Joash maoy nipuli kaniya ingon nga hari.
* Si Haring Ahasias sa Israel anak ni Haring Ahab. Nangulo siya sulod sa duha ka tuig (sa ika 850-49 nga tuig una pa gipanganak si Cristo). Namatay siya tungod kay nahagbong siya sa iyang palasyo ug ang iyang igsoon nga si Joram nahimong hari.


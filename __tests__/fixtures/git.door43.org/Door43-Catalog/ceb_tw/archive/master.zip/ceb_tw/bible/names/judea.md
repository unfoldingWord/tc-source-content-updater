# Judea

Ang pulong nga "Judea" gikan sa ngalan nga Juda nga usa sa dose ka mga tribu sa Israel. 

* Usahay gigamit ang "Judea" sa pagtumong lang sa probinsya nga naa sa habagatang bahin sa daan nga Israel nga nahimutang sa kasadpan sa Patay nga Dagat. Ang ubang mga hinubaran nagtawag niini nga probinsya sa "Juda."
* Sa ubang panahon, "ang Judea" nagtumong sa tanang probinsya sa karaan nga Israel, apil ang Galilea, Samaria, Perea, Idumea ug Judea (Juda).

 Kung ang maghuhubad gusto himuon nga tin-aw ang pasabot niining duha ka paggamit sa Judea, ( pananglitan. sa Lucas 1:5) pwede hubaron nga "ang nasod sa Judea" ug (pananglitan. sa Lucas 1:30) pwede hubaron nga "ang probinsya sa Judea" o "ang probinsya sa Juda" tungod kay kabahin man kini sa karaan nga Israel diin ang tribu sa Juda mao gyuy unang nagpuyo didto.


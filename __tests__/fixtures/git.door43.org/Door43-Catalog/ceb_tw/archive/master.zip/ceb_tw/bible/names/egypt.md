# Ehipto, Ehiptohanon

Ang nasod nga Ehipto makita sa amihanang-sidlakang dapit sa Africa, sa habagatan ug kasadpan nga lugar sa Canaan.

* Ang Ehiptohanon mao ang tawo nga gipanganak sa Ehipto ug ang iyang mga katigulangan gikan sa Ehipto.
* Niadtong dugay na kaayo nga panahon, ang Ehipto gamhanan ug adunahan nga nasod.
* Ang karaan nga Ehipto natunga sa duha ka bahin, nga mao ang Ubos ug ang Taas nga Ehipto. Ang "Ubos nga Ehipto" tua didto ang Suba sa Nile nga midagayday paubos didto sa Dagat sa Mediteranyo.
* Si Jose ug Maria miadto sa ubos nga dapit sa Ehipto uban ang bata nga si Jesus, aron mokalagiw kang Herod.
* Adunay pipila ka panahon nga gamay ra ang pagkaon sa Canaan, ang mga patriyarka gikan sa Israel mibiyahe didto sa Ehipto aron mopalit ug pagkaon alang sa ilang mga pamilya.


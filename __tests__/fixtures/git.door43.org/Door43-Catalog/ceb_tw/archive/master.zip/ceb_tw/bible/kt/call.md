# tawag, pagtawag, gitawag, tinawag

Ang pulong nga "tawag" ug “gitawag" literal nga nagpasabot sa kusog nga pagsulti sa tawo nga tua sa layo. Aduna kini daghan nga buot ipasabot nga sumbingay.

* Ang “pagtawag" sa usa ka tawo buot ingnon nga nagsinggit o kusog nga nagsulti sa tawo nga tua sa layo. Pwede sad ipasabot niini nga nangayo ug tabang sa uban labi na sa Dios.
* Kadaghanan sa Biblia ang "tawag" adunay buot ipasabot nga "gipatawag" o "gimanduan nga moduol" o "gihangyo nga moduol "
* Gitawag sa Dios ang mga tawo nga moduol kaniya ug mahimong iyang katawhan. Mao kini ang ilang "pagkatawag."
* Ang pulong nga "gitawag" gigamit kini sa Biblia nga buot ipasabot nagpili ug katawhan ang Dios nga mahimong mga anak niya, mahimong mga alagad niya ug magsangyaw sa iyang mensahe sa kaluwasan pinaagi kang Jesus.
* Kini nga pulong gigamit usab sa konteksto sa pagtawag sa usa ka tawo sa iyang ngalan. Pananglitan, "Gitawag siya nga Juan," buot ipasabot "Ginganlan siya ug Juan" o "Ang iyang ngalan Juan."
* Ang "tawagon sa ngalan ni" buot ipasabot nga ginganlan ang usa sa ngalan sa uban. Ang Dios nagsulti nga ang Iyang katawhan gitawag sa Iyang ngalan.
* Ang lain nga mga pulong nga "gitawag ka nako sa imong ngalan" buot pasabot, nakahibalo ang Dios sa ngalan sa usa ka tawo ug gipili gyud siya niya.

Mga Sugyot sa Paghubad:

* Ang pulong nga "tawag" pwede nga hubaron sa pulong nga "gipatawag," nga nagpasbot sa gituyo nga pagtawag o adunay katuyuan sa pagtawag.
* Ang sumbingay nga "nagtawag kanimo" pwede hubaron nga "naghangyo ug tabang kanimo" o "nag-ampo pag-ayo kanimo."
* Kung ang Biblia magsulti nga ang Dios "nagtawag" kanato nga mahimong alagad niya, pwede kini hubaron nga, "gipili kita mismo" o "gipili kita" nga mahimo niyang mga alagad.
* "Kinahanglan nga imong tawagon ang iyang ngalan" pwede sad nga hubaron nga "kinahanglan nganlan nimo siya."
* "Ang Iyang ngalan gitawag" pwede sad hubaron nga, "ang ngalan niya" o "gipangalanan siya"
* Ang "pagtawag" pwede sad hubaron nga "pagsulti ug kusog" o "singgit" o "pagsulti nga kusog ang tingog." Seguraduha nga ang paghubad niini dili murag nasuko ang tawo.
* Ang mga pulong nga “ang pagtawag kanimo" pwede hubaron nga "ang imong katuyuan" o "Katuyuan sa Dios alang kanimo” o "pinasahi nga buluhaton sa Dios alang kanimo."
* Ang "pagtawag sa ngalan sa Ginoo" pwede hubaron nga "pangitaa ang Dios ug magsalig kaniya" o "salig sa Ginoo ug magtuman kaniya."  
* Ang "pagtawag sa" usa ka butang pwede hubaron nga "panginahanglan" o "pangayo sa" o "nagsugo."
* Ang pulong nga "gitawag ka sa akong ngalan" pwede hubaron nga, "gihatag ko kanimo ang akong ngalan nga gapakita nga ikaw panag-iya nako"
* Kung ang Dios moingon nga, "gitawag ko ikaw sa akong ngalan," pwede kini hubaron nga, "kahibalo ko sa imong ngalan ug gipili ko ikaw."


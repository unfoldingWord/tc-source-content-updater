# David

Si David mao ang ikaduhang hari sa Israel ug iyang gihigugma ug gialagaran ang Dios. Siya ang nagsulat sa kadaghanan sa mga Salmo.

* Niadtong si David bata pa nga lalaki nga nag-alima sa karnero sa iyang pamilya, gipili siya sa Dios nga mahimong sunod nga hari sa Israel.
* Nahimong maayong manggugubat si David ug nangulo siya sa kasundalohan sa Israel sa ilang mga gubat batok sa ilang mga kaaway. Ilado ang iyang pagpildi kang Goliat nga Filistihanon.
* Gisulayan ni Saul nga patyon si David apan gipanalipdan siya sa Dios ug gihimo siya nga hari pagkamatay ni Saul.
* Nakasala si David batok sa Dios, apan naghinulsol siya ug gipasaylo siya sa Dios.
* Si Jesus, ang Mesiyas, gitawag nga "Anak ni David" tungod kay kaliwat siya ni Haring David.


# Nahor

Nahor ang ngalan sa duha ka lalaki sa Biblia: ang apohan ug ang igsoon ni Abraham.

* Ang asawa ni Isaac nga si Rebecca mao ang apo sa igsoon ni Abraham nga si Nahor.
* Aduna say "siyudad nga Nahor" nga tingali nagtumong sa apohan ni Abraham. Kini nga mga pulong pwede magpasabot nga "ang siyudad nga ginganlan ug Nahor" o "ang siyudad diin nagpuyo si Nahor" o "ang siyudad ni Nahor."


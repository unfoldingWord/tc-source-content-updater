# pagsimba

Ang “pagsimba" nagpasabot sa pagtahod, pagdayeg ug pagtuman sa usa ka tawo, labi na sa Dios. 

* Kini nga pulong kasagaran literal nga nagpasabot nga "pagduko" o "paghapa" mainubsanon nga nagtahod sa usa ka tawo.
* Gisimba nato ang Dios sa dihang moalagad ug motahod kita kaniya, pinaagi sa pagdayeg ug pagtuman kaniya.
* Sa dihang mosimba ang mga Israelita sa Dios, kasagaran kauban ang pagsakripisyo ug mananap sa altar.
* Ang uban nga mga tawo nagsimba ug dili tinuod nga Dios.

Mga Sugyot sa Paghubad

* Ang pulong nga "pagsimba" pwede hubaron nga "pagduko sa" o "pagtahod ug pag-alagad" o "pagtahod ug pagtuman."
* Sa uban nga mga konteksto, pwede sad kini hubaron nga "mapaubsanong pagdayeg" o "maghatag ug pagtahod ug padayeg."


# Hebreo

Ang mga "Hebreo" mga kaliwat ni Abraham ug kang Isaac ug Jacob. Si Abraham mao ang una nga tawo sa Biblia nga gitawag nga "Hebreo."

* Ang pulong nga "Hebreo" nagtumong sad sa pinulongan nga gisulti sa mga katawhang Hebreo. Ang Daang Kasabotan una nga gisulat sa Hebreo nga pinulongan.
* Ang mga Hebreo gitawag sad nga mga "katawhang Judio" o "Israelita." Labing maayo nga ipabilin kining tulo ka pulong sa ilang orihinal nga konteksto basta klaro lang nga nagtumong kini nga mga pulong sa parehas nga grupo sa tawo.


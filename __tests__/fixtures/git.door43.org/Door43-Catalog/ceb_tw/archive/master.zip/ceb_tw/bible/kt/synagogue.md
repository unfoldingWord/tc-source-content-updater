# sinagoga

Ang sinagoga usa ka tinukod diin nagtigom ang mga Judio aron simbahon ang Dios. Sukad adtong dugay na kaayo nga panahon, ang mga panagtigom sa sinagoga mao ang mga panahon sa pag-ampo, pagbasa sa kasulatan, ug pagtudlo mahitungod sa kasulatan. 

* Gitukod sa mga Judio ang sinagoga tungod kay ang kadaghanan kanila nagpuyo layo sa templo sa Jerusalem ug dili makaadto kanunay.
* Si Jesus kanunay nga nagtudlo sa mga sinagoga.
* Ang pulong nga "sinagoga" pwede sad magtumong sa grupo sa mga tawo nga nagtigom didto.


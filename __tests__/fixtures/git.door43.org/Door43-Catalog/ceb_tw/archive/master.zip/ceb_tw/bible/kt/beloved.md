# hinigugma

Ang pulong nga "hinigugma" usa ka pulong sa pagbati nga naghulagway sa usa ka hinigugma ug minahal sa usa.

* Ang pulong nga "hinigugma" literal nga gapasabot nga "gihigugma.
* Ang Dios nagtumong kang Jesus nga iyang "hinigugmang Anak."
* Sa ilang mga sulat sa kristohanong mga Iglesia, ang mga apostoles kanunay nila gitawag ang kaubanang tumutuo nga "minahal."

Mga Sugyot sa Paghubad

* Kini nga pulong pwede sad hubaron nga "gihigugma" o "hinigugma" o 

  "gihigugma gyud" o "minahal gyud."
* Sa konteksto nga hisgutan ang mahitungod sa suod nga higala, pwede 

  sad kini hubaron nga "ang minahal kung higala." o "akong suod nga higala"
  Sa Ingles natural lang nga moingon, "akong minahal nga higala nga si Pablo" 
  o "Si Pablo nga akong minahal nga higala." Sa lain nga pinulongan naa siguroy mas natural pa nga paagi sa paghan-ay sa ingon ani nga pulong.
* Timan-i nga ang pulong nga hinigugma gikan sa pulong nga gugma 

 sa Dios, nga walay kondisyon, dili makakaugalingon, ug mainantuson.


# Awhag, pag-awhag

Ang pulong nga "awhag" nagpasabot nga magdasig gyud pag-ayo sa usa ka tawo sa pagbuhat ug sakto. Kini nga pagdasig gitawag nga "awhag."

* Ang katuyuan sa pag-awhag mao ang pagkombensi sa ubang mga tawo sa paglikay sa sala ug pagsunod sa kabubut-on sa Dios.
* Ang Bag-ong Kasabotan nagtudlo sa mga kristohanon sa pagdasig sa usag-usa pinaagi sa gugma, ug dili sa mapintason ug kalit nga pamaagi.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "awhag" pwede sad hubaron nga "gi-awhag pag-ayo" o "pagdani" o "pagtambag."
* Siguraduha nga ang paghubad niini nga pulong wala nagpasabot nga nasuko ang ga-awhag. Ang pulong kinahanglan magpahayag sa kaisog ug kaseryoso, apan wala magtumong sa nasuko nga pamulong.
* Sa kasagarang konteksto, ang pulong nga "awhag" kinahanglang hubaron nga lahi sa "pagdasig," nga nagpasabot sa paghatag ug kadasig, o paghupay sa usa ka tawo.
* Kasagaran kini nga pulong pwede sad hubaron nga lahi sa "pagtinambagay," nga nagpasabot sa pagpasidaan o pagtul-id sa tawo sa iyang sayop nga kinaiya.


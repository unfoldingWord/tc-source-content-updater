# halangdon

Ang pulong nga "halangdon" nagtumong sa pagkagamhanan ug katahom sa Dios, kasagaran nagtumong kini sa kinaiya sa usa ka hari.

* Sa Biblia, ang "halangdon" kasagaran nagtumong sa pagkagamhanan sa Dios, nga mao ang labaw nga Hari sa tibuok nga kalibutan.
* Gigamit ang pulong nga "Halangdon" sa pagtawag o pakig-estorya sa hari isip pagtahod kaniya.

Mga Sugyot sa Paghubad:

* Kini nga pulong pwede hubaron sama sa "harianong pagkagamhanan" o "harianong katahom."
* "Halangdon" pwede hubaron sama sa "sa imong kahitas-an" o "sa imong pagkahalangdon" o gamiton ang natural nga paagi sa pagtahod sa magmamando sa pinulongan nga hubaron.


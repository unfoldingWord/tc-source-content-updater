# Bet-semes

Ang Bet-semes kay ngalan sa usa ka siyudad sa tiretoryo sa tribu sa Juda, nga gibanabana nga 30 kilometros kasagpan sa Jerusalem.

* Nailog ang Bet-semes gikan sa mga taga Canaan sa dihang gisakop sila nila ni Josue.
* Ang Bet-semes siyudad nga gilain nga puy-anan alang sa mga Levita nga saserdote.
* Sa dihang gikuha sa mga Filistihanon ang  arka sa saad pabalik sa Jerusalem, ang ang unang siyudad nga gihunongan nila mao ang Bet-semes.


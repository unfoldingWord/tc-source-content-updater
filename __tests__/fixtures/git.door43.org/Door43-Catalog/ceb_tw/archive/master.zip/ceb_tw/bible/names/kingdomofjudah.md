# Juda, Gingharian sa Juda

Ang Juda ang labing dako sa dose ka mga tribu sa Israel. Paghuman namatay ni Haring Solomon, ang Israelita natunga sa duha ka gingharian. Ang gingharian sa Juda sa habagatang bahin, nga gilangkuban sa tribu sa Juda ug Benjamin.

* Ang kapital nga siyudad sa gingharian sa Juda mao ang Jerusalem.
* Ang ubang mga hari sa gingharian sa Juda mituman sa Dios ug nagdala sa mga tawo sa pagsimba kaniya. Apan kadaghanan sa hari sa Juda mga dautan.
* Mga 120 ka tuig ang milabay human gipilde sa Assirya ang Israel ang amihanang gingharian, ang Juda nasakop sa nasod sa Babilon. Ang mga taga Babilonia ang nagguba sa siyudad ug sa templo, ug nagkuha sa daghang mga tawo gikan sa gingharian sa Juda ug gidala nila paingon sa Babilonia isip mga dinakpan.


# Iconium

Ang Iconium usa ka siyudad sa habagatang sentral sa Asya Minor (nga mao karon ang nasod nga Turkey).

* Ang Iconium mao na karon ang siyudad nga Konya.
* Miadto sila Pablo ug Barnabas sa Iconium kaniadtong gipahawa sila sa mga Judio sa rehiyon sa Antioqia pagkahuman sa ilang malamposon nga ministeryo sa mga Gentil sa Antioqia sa una nila nga pagbiyahe didto ingon nga misyonero.
* Ang dili tumutuo nga mga Judio ug mga Gentil sa Iconium nagplano nga batuhon si Pablo ug ang iyang mga kauban sa trabaho, apan miikyas sila ngadto sa duol nga siyudad sa Lystra. Ug dayon ang mga tawo gikan sa Iconium ug Antioqia niadto sa Lystra ug giaghat ang mga tawo didto nga batuhon si Pablo.


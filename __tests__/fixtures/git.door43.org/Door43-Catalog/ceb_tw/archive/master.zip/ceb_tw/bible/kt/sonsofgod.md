# Mga anak (nga lalaki) sa Dios

Ang pulong nga "mga anak (nga lalaki) sa Dios" usa ka sumbingay nga adunay pipila ka mga posible nga mga pasabot. Ang mga pulong nga "anak (nga lalaki) ni" kasagaran nagtumong sa pagkaadunay kinaiya sama sa usa ka butang o usa ka tawo.

* Kini nga pulong nagtumong sa usa ka relasyon sa Dios susama sa relasyon taliwala sa anak ug sa iyang amahan, kauban ang tanang mga prebilihiyo nga anaa sa mga anak.
* Sa Daang Kasabotan, ang pulong nga "mga anak (nga lalaki) sa Dios" kasagaran nagtumong sa mga anghel.
* Sa Genesis 6, ang pagsabot sa ubang mga tawo sa "mga anak (nga lalaki) sa Dios" mao ang mga nakasala nga mga anghel nga mao ang daotan nga mga espiritu o mga demonyo. Ang uban naghunahuna nga pwede kini magtumong sa gamhanan nga mga pangulo sa mga nasod o sa mga kaliwat ni Set.
* Sa Bag-ong Kasabotan, ang mga pulong nga "mga anak (nga lalaki) sa Dios " nagtumong sa mga tumutuo kang Jesus ug kasagaran kini gihubad nga "mga anak sa Dios."
* Ang titulo nga "Anak sa Dios" lahi gyud nga pulong nga nagtumong kang Jesus nga mao lang ang Anak sa Dios.

Mga Sugyot sa Paghubad:

* Kung ang pulong nga "mga anak nga lalaki sa Dios" nagtumong sa mga tumutuo kang Jesus, pwede kini hubaron nga "mga anak sa Dios."  
* Ang ubang mga pamaagi sa paghubad sa "mga anak (nga lalaki) sa Dios" pwede nga "mga anghel" o "langitnong mga linalang" o "mga demonyo," depende sa konteksto.


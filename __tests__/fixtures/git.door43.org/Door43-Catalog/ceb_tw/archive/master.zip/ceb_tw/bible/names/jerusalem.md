# Jerusalem

Ang Jerusalem sa una usa ka karaan nga Canaanhon nga siyudad nga sa kadugayan nahimong importante kaayo sa politiko ug relihiyosong bahin sa Israel. Mao kini gihapon ang kapital nga siyudad sa Israel karon.

* Sa Daang Kasabotan ang siyudad nga Salem tingali mao ra sa siyudad sa Jerusalem. Kining duha ka ngalan adunay parehas nga pasabot nga "kalinaw."
* Gihalad ni Abraham ang iyang anak nga lalaki nga si Isaac sa Bukid sa Moriah nga parte sa siyudad sa Jerusalem.
* Gibontog ni Haring David ang Jerusalem gikan sa mga Jebusihanon ug iya kining gihimo nga kapital nga siyudad.
* Si Solomon nga anak nga lalaki ni David nagtukod sa una nga templo sa Bungtod sa Moriah sa Jerusalem.
* Gilaglag sa mga taga-Babilonia ang Jerusalem apan sa kadugayan pagkahuman sa 70 ka tuig ang milabay gitugutan sila sa Dios nga mobalik ug itukod pag-usab ang siyudad.
* Tungod kay tua didto ang templo, ang Jerusalem mao ang sentro sa pagsaulog sa mga dagkong kapistahan sa Judio.
* Sa Bag-ong Kasabotan, gihalad si Jesus niadtong bata pa siya sa templo sa Jerusalem ug didto sad sa Jerusalem diin siya gilutos ug gisentensiyahan nga mamatay sa krus.
* Pagkahuman nabanhaw si Jesus, ang Jerusalem mao ang usa sa importante nga mga lugar diin si Jesus nakig-uban sa iyang mga disipulo usa pa siya mibalik sa langit.
* Tungod kay ang Jerusalem naa sa mga kabukiran sa Israel, ang mga tawo kasagaran moingon kung moadto didto sa Jerusalem nga "mosaka sa Jerusalem."


# Rahab

Si Rahab usa ka babaye nga nagpuyo sa Jerico sa dihang ang Israel misulong sa siyudad. Usa siya ka babaye nga nagbaligya ug dungog.

* Gitago ni Rahab ang duha ka Israelita nga miadto aron maniid sa Jerico sa wala pa misulong ang mga Israelita. Gitabangan niya ang mga espiya sa pag-ikyas pabalik sa kampo sa mga Israelita.
* Nahimo nga tumutuo si Rahab kang Yahweh, siya ug ang iyang pamilya naluwas niadtong giguba ang Jerico. Namuyo sila kauban ang mga Israelita.


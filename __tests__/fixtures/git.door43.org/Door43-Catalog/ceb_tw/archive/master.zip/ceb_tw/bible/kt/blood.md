# Dugo

Ang pulong nga "dugo" nagtumong sa pula nga likido nga mogawas sa panit sa tawo kung adunay samad. Ang dugo naghatag ug sustansiya sa lawas sa usa ka tawo.

* Ang dugo nagsimbolo sa kinabuhi ug kung kini maula, nagsimbolo kini sa pagkawala sa kinabuhi o pagkamatay.
* Kung maghalad ang mga tawo sa Dios, magpatay sila ug mananap ug ibubu ang iyang dugo sa altar. Nagsimbolo kini sa sakripisyo sa kinabuhi sa mananap isip bayad sa mga sala sa mga tawo.
* Pinaagi sa iyang pagkamatay sa krus, ang dugo ni Jesus nagsimbolo sa paghugas sa sala sa mga tawo ug pagbayad sa silot nga angayan nila madawat tungod sa ilang mga sala.
* Ang mga pulong nga "unod ug dugo" usa ka sumbingay nga nagtumong sa tawo.
* Ang sumbingay nga "kaugalingong unod ug dugo" nagtumong sa mga tawo nga magkadugo.

Mga Sugyot sa Paghubad

* Kini nga pulong kinahanglan hubaron gyud sa pulong nga gigamit gyud sa pinulongan nga ihubad.
* Ang sumbingay nga "unod ug dugo" pwede sad hubaron nga, "mga tawo" o "tawo."
* Depende sa konteksto, ang sumbingay nga akong kaugalingong unod ug dugo" pwede sad hubaron nga, "akong kaugalingong pamilya" o "akong kaugalingong paryente" o "akong kaugalingong mga tawo."


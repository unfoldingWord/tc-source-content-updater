# Hibihanon

Ang mga Hibihanon usa sa mga pito ka dagkong grupo sa katawhan nga nagpuyo sa Canaan niadtong gipangulohan ni Josue ang mga Israelita sa pag-ilog sa yuta.

* Ang mga Hibihanon mga kaliwat sa anak ni Noe nga si Ham.
* Gilimbongan ang mga Israelita nga maghimo ug kasabotan sa mga Hibihanon aron dili nila buntogon sila.
* Si Secem nga Hibihanon ang naglugos sa anak nga babaye ni Jacob nga si Dina, ug ang iyang mga igsoong lalaki nanimalos pinaagi sa pagpatay ug daghang mga Hibihanon.


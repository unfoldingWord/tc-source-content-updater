# sambingay

Ang sambingay usa ka mubo nga estroya nga gigamit aron maghulagway sa moral o relihiyoso nga pagtulun-an.

* Si Jesus migamit ug mga sambingay sa pagtudlo sa iyang mga disipulo.


# Dios

Sa Biblia, ang pulong nga "Dios" nagtumong sa usa nga walay katapusan nga mao ang naglalang sa kalibutan gikan sa wala. Ang Dios ang Amahan, Anak, ug Balaan nga Espiritu. Ang ngalan sa Dios mao ang "Yahweh."

* Ang Dios anaa kanunay; naa na siya wala pa malalang ang tanang butang, ug magpadayon siya nga anaa hangtod sa kahangturan.
* Siya lang ang tinuod nga Dios ug adunay gahum sa tanang butang niini nga kalibutan.
* Hingpit ang pagkamatarong sa Dios, ug ang iyang kaalam walay katapusan, balaan siya, walay sala, matarung, maluluy-on ug mahigugmaon.
* Siya ang Dios nga gatuman sa iyang kasabotan ug gatuman sa iyang mga saad.
* Ang mga tawo gibuhat sa Dios aron magsimba kaniya ug siya lang gyud ang ilang simbahon.
* Gipadayag sa Dios ang iyang ngalan nga "Yahweh" nga buot ipasabot, "siya mao ang" o "Ako mao ang" o " ang kanunay nga naa."
* Ang Biblia sad nagtudlo mahitungod sa mga "diosdiosan" nga diin dili kini mga buhi ug sayop nga gisimba sa katawhan.

Mga Sugyot sa Paghubad

* Mga paagi sa paghubad sa "Dios" pwede sad ilakip ang "Manlalalang" o "Kinatas-an sa tanan."
* Uban pa nga paagi sa paghubad sa "Dios" pwede ang "Kinatas-an nga Manlalalang" o "walay katapusan nga Makagagahum nga Ginoo." o "Kinatas-an nga walay katapusan."
* Hunahunaa kung giunsa pagtumong ang Dios sa lokal o nasudnon nga pinulongan. Pwede nga adunanay pulong para sa "Dios" sa pinulungan nga gihubad. Kung tinuod kini, importante nga masiguro nga kini nga pulong tugma sa kinaiya sa usa ka tinuod nga Dios nga gihisgutan sa taas.
* Daghang pinulongan nga gihimo nilang dako ang unang litra sa pulong sa nag-inusara nga tinuod nga Dios, aron mailhan kini nga lahi sa pulong nga diosdiosan.
* Uban nga paagi aron mailahi kini mao ang paggamit sa duha ka lahi nga mga pulong sa "Dios" ug "diosdiosan."
* Ang mga pulong nga "mahimo nila akong Dios ug sila mahimo nakong katawhan" pwede sad hubaron nga, "Ako, nga Dios, magmando niini nga katawhan ug nga sila magsimba kanako."


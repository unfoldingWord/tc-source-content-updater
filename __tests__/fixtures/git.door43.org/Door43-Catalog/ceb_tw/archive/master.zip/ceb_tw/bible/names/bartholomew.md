# Bartolomeo

Si Bartolomeo usa sa dose nga apostoles ni Jesus.

* Kauban sa ubang mga apostoles, si Bartolomeo gisugo aron magwali sa maayong balita ug magbuhat sa mga milagro sa ngalan ni Jesus.
* Usa sad siya sa mga nakakita niadtong mibalik si Jesus sa langit.
* Paghuman sa pipila ka semana, kauban niya ang uban nga mga apostol sa Jerusalem sa Pentecostes sa dihang ang Balaang Espiritu mianha kanila.


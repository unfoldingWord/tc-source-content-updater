# Ginoong Yahweh, Yahweh nga Dios

Sa Daang Kasabotan, kini nga mga pulong gigamit sa daghang higayon nga nagtumong sa nag-inusara nga tinuod nga Dios.

* Ang pulong nga "Ginoo" usa ka titulo sa Dios ug ang "Yahweh" personal nga ngalan sa Dios.
* Ang personal nga ngalan sa Dios nga "Yahweh" kasagaran langkob sa pulong nga "Dios" sama sa “Yahweh nga Dios."

Mga Sugyot sa Paghubad:

* Kung mogamit ka ug uban nga pulong sa "Yahweh" alang sa iyang personal nga ngalan, pwede mong hubaron kini nga literal nga mga pulong nga "Ginoong Yahweh" ug "Yahweh nga Dios."
* Ang uban nga mga pinulongan ibutang nila ang mga titulo ulahi sa ngalan ug hubaron nga "Yahweh nga Ginoo." Hunahunaa kung unsay natural sa pinulongan: ang titulo ba nga "Ginoo" unang ibutang o pagkahuman sa "Yahweh"?
* Kung ang gihatag nga hubad "Yahweh" nga "Ginoo" o "GINOO," mas maayo ang "Ginoong Yahweh." sama sa mga pulong nga "Ginoong Dios" o "Dios nga mao ang Ginoo."
* Apan ang pulong nga "Ginoong Yahweh" kinahanglan dili sama sa "Ginoo nga GINOO" tungod kay pwede nga dili nila makita ang dagko nga litra nga naandan nga gigamit aron makit-an ang kalainan niini nga mga pulong.
* "Yahweh nga Dios" pwede isulat nga "Dios nga gitawag nga Yahweh" o "Dios nga Buhi" o "Ako kini ang Dios."


# Levita, Levi

A Levita usa ka tawo nga miyembro sa tribo sa Israel nga ang iyang kagikanan mao si Levi.

* Ang Levita mao ang tigdumala sa templo ug sa mga relihiyosong seremonya.
* Ang tanan nga mga pari nga Judio mga kalalakihan nga mga Levita. Apan dili tanan nga mga Levita pari.
* Ang mga pari nga Levita gigahin ug gipahinungod alang sa pinasahi nga trabaho sa pag-alagad sa Dios sa templo.


# pamag-ang nga bato

Ang pulong nga "pamag-ang nga bato" nagtumong sa dakong bato nga pinasahi nga gihimo aron ibutang sa pamag-ang sa pundasyon sa usa ka tinukod.

* Ang uban pang mga bato sa tinukod gisukod ug gibutang sumala sa pamag-ang nga bato.
* Importante kini kaayo alang sa kalig-on sa tibuok nga tinukod.
* Sa Bag-ong Kasabotan, ang Panagtigom sa mga tumutuo gisumbingay sa tinukod diin si Jesu Cristo ang "pamag-ang nga bato."
* Sa sama nga pamaagi nga ang pamag-ang nga bato sa tinukod nagsuporta ug nagdeterminar sa posisyon sa tibuok tinukod, mao nga si Jesu Cristo, ang pamag-ang nga bato, nga maoy gitukoran ug maoy nagsuporta sa Panagtigom sa mga tumutuo.

Mga Sugyot sa Paghubad:

* Ang pulong nga "pamag-ang nga bato" pwede sad hubaron nga "nag-unang bato sa tinukod" o "bato nga pundasyon."
* Hunahunaa kung ang pinulongan nga hubaron adunay pulong sa usa ka bahin sa pundasyon sa tinukod nga mao ang nag-unang suporta. Kung naa, pwede gamiton kini nga pulong.
* Ang laing pamaagi sa paghubad niini mao "ang bato nga pundasyon nga gigamit sa pamag-angan sa tinukod."
* Importante nga ipabilin ang kamatuoran nga dako kini nga bato nga gigamit isip tibuok ug lig-on nga materyales sa pagtukod. Kung dili bato ang gigamit sa pagtukod sa mga tinukod, basin adunay laing pulong nga pwede gamiton nga nagpasabot nga "dakong bato."


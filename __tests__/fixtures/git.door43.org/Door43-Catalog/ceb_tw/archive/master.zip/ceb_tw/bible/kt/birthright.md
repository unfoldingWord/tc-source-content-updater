# Katungod sa pagkamagulang

Ang pulong nga "katungod sa pagkamagulang" sa Biblia nagtumong sa pasidungog, ngalan sa pamilya, ug kalibutanong bahandi nga ihatag lang sa kamagwangang anak nga lalaki sa pamilya.

* Ang katungod sa kinamagulangang anak nga lalaki naglakip sa doble nga bahin gikan sa amahan.
* Ang unang anak nga lalaki sa hari maoy mahatagan ug katungod sa kinamagulangan nga mangulo pagkamatay sa iyang amahan.
* Gibaligya ni Esau ang iyang katungod sa pagkamagulang sa iyang manghod nga lalaki nga si Jacob. Tungod niini, si Jacob ang nagmana sa panalangin sa unang anak nga lalaki imbis nga si Esau.
* Ang katungod sa kinamagulangan nag-apil sad sa pasidungog sa pagsubay sa kaliwat pinaagi sa linya sa kamagwangang anak nga lalaki.

Mga Sugyot sa Paghubad

* Ang posible nga pamaagi sa paghubad sa "katungod sa kinamagulangan" pwede sad, "katungod ug bahandi sa unang anak nga lalaki" o "pasidungog sa pamilya" o "pribilihiyo ug pamana sa unang anak nga lalaki."


# Baruk

Ang Baruk ngalan sa pipila nga mga lalaki sa Daang Kasabotan.

* Ang usa nga Baruk (nga anak ni Zabbal) usa sa mga tawo nga nagtrabaho uban kang Nehemias aron ayohon ang mga paril sa Jerusalem.
* Sa panahon sad ni Nehemias, ang lain sad nga Baruk (nga anak ni Kol-Hozeh) usa sa mga pangulo nga mipuyo sa Jerusalem pagkahuman natukod ug usab ang mga paril.
* Ang lain pa nga Baruk (nga anak ni Neriah) katabang ni propeta Jeremias nga mitabang kaniya sa daghang praktikal nga tahas sama sa pagsulat sa mensahe nga gihatag sa Dios kang Jeremias ug pagbasa niini sa mga tawo.


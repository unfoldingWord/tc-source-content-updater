# Lebanon

Ang Lebanon matahum nga bungturanon nga rehiyon nga makita sa baybayon sa Dagat sa Meditereneo, amihanan sa Israel. Sa panahon sa Biblia kini nga rehiyon daghan kaayo ug mga kahoy

* Si Haring Solomon nagpadala ug mga trabahante ngadto sa Lebenon aron mamutol ug mga kahoy nga sedar nga gamiton sa pagtukod sa templo sa Dios.
* Ang daang Lebanon gipoy-an sa mga Feniciahanon nga mga hanas mohimo ug mga barko nga gigamit sa malampuson nga mga negosyo.
* Ang mga siyudad sa Tiro ug Sidon makita sa Lebanon. Dinhi niini nga mga syudad nga ang bililhon nga tapul nga pangtina unang  gigamit.


# Cirene

Ang Cirene usa ka siyudad nga Griego sa amihanan nga baybayon sa Afrika dapit sa Dagat sa Mediteraneo nga naa sa habagatang dapit sa isla sa Creta.

* Sa panahon sa Bag-ong Kasabotan, ang Cirene adunay mga komyunidad sa mga Judio ug mga Kristohanon.
* Mas ilado siguro ang Cirene sa Biblia nga maoy siyudad diin gikan kadtong tawo nga nagkarga sa krus ni Jesus.


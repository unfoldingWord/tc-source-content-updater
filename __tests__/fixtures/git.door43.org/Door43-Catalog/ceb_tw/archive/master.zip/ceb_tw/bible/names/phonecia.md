# Fenicia

Adtong una nga panahon, ang Fenicia mao ang adunahan nga nasod dapit sa kabaybayonan sa Dagat sa Mediteranean. Makita kini sa kasadpang rehiyon nga mao ang nasod nga Lebanon karon.

* Sa panahon sa Bag-ong Kasabotan, ang kapital sa Fenicia mao ang Tiro. Ang lain nga importante nga Fenicia mao ang siyudad nga Sidon.
* Ang Fenicia ilado sa mga kahoy nga cedar, purpura nga tina, ug sa ilang abilidad nga mobiyahe ug nagnegosyo nga giagi sa dagat. Hanas sila kaayo sa paghimo ug barko.


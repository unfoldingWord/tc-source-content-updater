# Roboam

Si Roboam usa sa mga anak ni Solomon, ug nahimong hari sa nasod sa Israel pagkamatay si Solomon.

* Sa dihang si Roboam nagsulti ug ngil-ad kaayo sa mga tawo sa Israel, napulo sa dose ka mga tribo nagrebelde batok kaniya. Tungod niini, ang nasod sa Israel nabahin sa duha ka gingharian: ang gingharian sa Israel sa amihanang bahin ug ang gingharian sa Juda sa habagatang bahin.

* Si Roboam nagpadayon nga hari sa gingharian sa Juda, nga sakop ang duha ka mga tribo nga nagpadayon nga maunongon kaniya.

* Si Roboam dautan nga hari ug wala motuman kang Yahweh, hinuon nag-alagad siya sa dili tinuod nga mga dios.


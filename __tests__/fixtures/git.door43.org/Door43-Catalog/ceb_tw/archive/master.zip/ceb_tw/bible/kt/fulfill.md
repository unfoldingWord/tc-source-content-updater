# Tuman

Ang pulong nga "pagtuman" buot ipasabot paghuman o pagtapos sa butang nga gilaoman.

* Sa dihang ang propisiya matuman, buot ipasabot nga ang Dios ang hinungdan nga nahitabo ang gitagna sa propisiya.
* Kung ang tawo makatuman sa saad o panaad, buot ipasabot gihimo niya ang iyang gisaad nga buhaton. 
* Ang pagtuman sa responsibilidad buot ipasabot buhaton ang gihatag nga tahas o gikinahanglan.

Mga Sugyot sa paghubad

* Depende sa konteksto, ang "pagtuman" pwede hubaron nga "pagtapos" o "paghuman" o "himuon" o "sundon o "pagbuhat."
* Ang mga pulong nga "natuman na" pwede sad hubaron nga "nahitabo na" o "miagi na."
* Mga paagi sa paghubad sa "pagtuman" sama sa "tumana ang imong buluhaton" ilakip sad ang, "paghuman" o "pagbuhat" o "himuon" o "pag-alagad sa ubang tawo nga diin ang Dios nagtawag kanimo nga himuon kini."


# Griego, taga-Grecia

Sa panahon sa Bag-ong Kasabotan, ang Griego mao ang pinulongan nga gigamit sa Grecia ug sa tibuok Imperyong Romano. Ang orihinal nga mga teksto sa Bag-ong Kasabotan gisulat sa Griego.

* Ang pulong nga "Griego" nga gigamit sa Biblia usahay nagtumong sa tawo nga dili Judio. Ingon niini kini kay niadtong panahona, Griego ang sinultihan sa kasagarang mga dili Judio nga anaa sa Imperyong Romano bisan pa ug taga laing nasod sila. Ang usa ka ehemplo niini mao ang babaye nga taga-Siria-Fenicia sa Marcos 7.
* Kung gigamit kini nga magtumong sa dili Judio, ang ubang pamaagi sa paghubad sa "Griego" mao ang "Gentil" o "dili Judio."
* Ang Judio nga "taga-Grecia" mao ang Judio nga nagsulti ug Griego ug nagdako sa kulturang Griego. Ang ubang mga bersyon sa Ingles migamit ug "Hellenistic," nga gikan sa pulong nga Griego. [TA: transliteration]  Lahi kini sa mga "Hebreo" nga mga Judio, nga Hinebreo lang ang sinultihan.


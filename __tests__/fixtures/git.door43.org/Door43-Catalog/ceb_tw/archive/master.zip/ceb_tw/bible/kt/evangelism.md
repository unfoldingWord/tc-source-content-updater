# ebanghelista

Ang "ebanghelista" usa ka tawo nga nagsulti sa ubang mga tawo sa maayong balita mahitungod kang Jesu Cristo.

* Ang literal nga ipasabot sa "ebanghelista" "usa ka tawo nga nagsangyaw sa maayong balita."
* Gisugo ni Jesus ang iyang mga apostoles sa pagpakaylap sa maayong balita mahitungod kung unsaon aron maapil sa gingharian sa Dios pinaagi sa pagsalig kang Jesus ug sa iyang sakripisyo alang sa sala.
* Gi-awhag ang tanang mga Kristohanon sa pagpakaylap sa maayong balita.
* Ang ubang mga Kristohanon gihatagan ug pinasahi nga espirituhanong gasa aron mahimo silang epektibo sa pagsulti sa maayong balita sa uban. Giingon nga kini nga mga tawo adunay gasa sa pag-ebanghelyo ug gitawag nga "mga ebanghelista."

Mga Sugyot sa Paghubad

* Ang pulong nga "ebangheilista" pwede hubaron nga, "usa ka tawo nga nagwali sa maayong balita" o "magtutudlo sa maayong balita" o "ang tawo nga nagsangyaw sa maayong balita."


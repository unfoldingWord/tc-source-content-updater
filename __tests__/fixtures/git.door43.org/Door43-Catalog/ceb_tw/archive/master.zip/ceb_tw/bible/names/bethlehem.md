# Betlehem, Eprata

Ang Betlehem gamay nga siyudad sa Israel, nga duol sa siyudad sa Jerusalem. Nailhan sad siya nga "Eprata" nga mao tingali ang iyang unang ngalan.

* Ang Betlehem gitawag sad nga "siyudad ni David," kay si haring David didto man gipanganak.
* Si propeta Micah nag-ingon nga ang Mesias magagikan sa "Betlehem Eprata."
* Natuman kini nga propesiya ug si Jesus gipanganak sa Betlehem, paglabay sa daghang mga katuigan.
* Ang gipasabot sa ngalan nga "Betlehem" kay "balay sa pan" o "balay sa pagkaon."


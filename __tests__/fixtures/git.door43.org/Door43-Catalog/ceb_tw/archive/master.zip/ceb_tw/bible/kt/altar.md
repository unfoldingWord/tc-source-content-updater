# halaran

Ang halaran usa ka gipataas nga tinukod diin didto gasunog ang mga Israelita ug mga mananap ug trigo isip halad sa Dios.

* Sa panahon sa Biblia, gihimo ang mga simple nga altar pinaagi sa pagdasok sa tapok nga yuta o plastar nga pagpatongpatong sa mga dagkong bato aron mahimong lig-on nga pundok.
* Ang uban nga mga espesyal nga altar nga kwadrado ang porma gihimo gikan sa kahoy ug gihal-opan ug mga metal sama sa bulawan, tumbaga, o bronse.
* Ang ubang mga grupo sa tawo nga nagpuyo duol sa mga Israelita nagtukod sad ug mga altar aron maghalad sa ilang mga dios.


# Dapit nga Balaan, Dapit nga Labing Balaan

Sa Biblia, ang mga pulong nga "Dapit nga Balaan" ug "Dapit nga Labing Balaan" nagtumong sa duha ka kwarto sa tabernaculo o templo.

* Kini nga mga kwarto anaa sa tinukod nga gilibotan sa mga hawanan sa tabernaculo o templo. Gibulag kining duha ka kwarto sa usa ka baga ug bug-at nga kurtina. Kini nga kurtina maoy nagbabag sa agianan pasulod sa Dapit nga Labing Balaan.
* Gitagbo sa Dios ang kinatas-ang pari nga nagrepresentar sa mga Israelita sa Dapit nga Labing Balaan.
* Ang kinatas-ang pari lang ang gitugutan nga mosulod sa Dapit nga Labing Balaan.
* Ang "Dapit nga Balaan" mao ang una nga kwarto ug adunay duha ka butang nga makit-an: ang halaran sa insenso ug ang lamesa nga adunay gigahin nga pan.
* Ang "Dapit nga Labing Balaan" mao ang ikaduha nga kwarto nga tua gyud sa sulod. Didto gibutang ang arka sa kasabotan. 
* Usahay, ang mga pulong nga "dapit nga balaan" nagtumong sa kinatibuk-an nga templo o tabernaculo.

Mga Sugyot sa Paghubad:

* Ang pulong nga "Dapit nga Balaan" pwede sad hubaron nga "kwarto nga gigahin alang sa Dios" o "pinasahi nga kwarto alang sa pagtagbo sa Dios" o "lugar nga giandam alang sa Dios."
* Ang pulong nga "Dapit nga Labing Balaan" pwede hubaron nga "kwarto nga gigahin gyud alang sa Dios" o "labing pinasahi nga lugar alang sa pakigkita sa Dios."
* Kung  gigamit lang kini nga  gatumong sa "dapit nga balaan", sama sa "usa ka balaang lugar," pwede sad kini hubaron nga "usa ka gigahin nga lugar" o "usa ka lugar nga gigahin sa Dios" o "didto sa kinatibuk-ang templo nga balaan" o "hawanan sa templo" o "hawanan sa tabernaculo," depende sa konteksto o pagamit niini.


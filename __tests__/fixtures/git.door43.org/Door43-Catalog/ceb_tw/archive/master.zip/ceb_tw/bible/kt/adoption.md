# pagsagop

Ang pulong nga "pagsagop" nagtumong sa legal nga proseso nga ang usa ka tawo mahimo nang anak sa mga tawo nga dili niya tinuod nga ginikanan.

* Gigamit sa Biblia ang "pagsagop" ug "sagop" aron ihulagway kung giunsa sa Dios nga ang mga tawo mahimo nga membro sa iyang pamilya, nga nahimo silang espirituhanong mga anak niya.
* Isip mga sinagop nga mga anak, ang mga tumutuo parehas nga manununod ni Jesu Cristo, nga adunay katungod sa tanang mga pribilehiyo ingon nga mga anak sa Dios.

Mga Sugyot sa Paghubad:

* Kini nga pulong mahimong hubaron gamit ang pulong nga naghulagway sa pinasahi nga relasyon sa ginikanan ug anak. Siguraduha nga nasabtan nga aduna kiniy pagsumbingay o espirituhanong pagpasabot. 
* Ang mga pulong nga "makasinati sa pagsagop ingon nga mga anak" mahimong hubaron nga "sagupon sa Dios ingon nga mga anak niya" o "mahimong anak sa Dios."


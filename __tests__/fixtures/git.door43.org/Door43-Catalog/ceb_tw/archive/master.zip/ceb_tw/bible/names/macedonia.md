# Macedonia

Sa mga panahon sa Bag-ong Kasabotan, ang Macedonia probinsiya kini sa Roma nga makit-an sa amihanan sa karaan nga Grecia.

* Pipila sa mga importanting siyudad sa Macedonia nga gihisgutan sa Biblia mao ang Berea, Filipos ug Tesalonica.
* Ang mga apostoles miadto niini nga mga siyudad aron magsangyaw sa maayong balita ug tabangan ang mga bag-ong tumutuo aron maghimo ug mga Kristohanong kumunidad nga mosimba sa Dios ug magtudlo sa katudlu-an sa Dios.
* Sa Biblia adunay mga sulat nga gisulat si Pablo ngadto sa mga tumutuo sa Filipos ug sa Tesalonica.


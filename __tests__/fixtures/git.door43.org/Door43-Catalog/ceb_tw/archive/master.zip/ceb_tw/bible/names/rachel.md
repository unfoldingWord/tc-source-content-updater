# Raquel

Usa sa mga asawa ni Jacob si Raquel. Siya ug ang iyang igsoon nga si Lea mga anak nga babaye ni Laban nga uyoan ni Jacob.

* Si Raquel ang inahan ni Jose ug Benjamin nga ang mga kaliwat nahimong duha sa mga dose ka tribu sa Israel.
* Sa sinugdanan, dili makaanak si Raquel. Apan ang Dios mao ang hinungdan nga nanganak siya kang Jose.
* Sa paglabay sa mga katuigan, niadtong nanganak siya kang Benjamin, namatay si Raquel ug gilubong ni Jacob duol sa Betlehem.


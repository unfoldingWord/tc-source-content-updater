# Kadasig, Madasig

Ang pulong nga "kadasig" nagtumaong sa kaabtik ug kasibot sa pagtuo ug paghimo sa usa ka butang. Ang pagkamadasigon pagkamaabtikon sad ug hingpit nga mahinalaron sa usa ka hinungdan o ideya.

* Ang kadasig apil ang kusganon nga tinguha ug mga lihok sa pagpalambo ug suporta sa maayo nga hinungdan. Kasagaran kining gigamit mahitungod sa usa ka tawo nga matinumanon nga mituman sa dios ug nagtudlo sa uban sa pagbuhat sad niini.
* Ang madasig nagpasabot sad sa pagbutang sa hilabihan nga paningkamot sa paghimo sa usa ka butang ug sa pagpadayon sa paglahutay niadto nga paningkamot.
* Ang "kadasig sa Ginoo" o ang "kadasig ni Yahweh" nagtumong sa makusganong paglihok sa Dios sa pagpanalangin sa iyang mga tawo o aron sa pagpakita sa iyang hustisya.

Mga sugyot sa Paghubad

* Ang "madasig" pwede sad hubaron nga "hilabihan nga kakugihan" o hilabihan nga paningkamot."
* Ang pulong nga "kadasig" pwede hubaron nga "abtik nga mahinalaron" o "maikagon ug determinado" o "matarong nga kasibot."


# Hebron

Ang Hebron usa ka siyudad nga tua sa taas ug batohon nga kabungturan mga 20 ka milya sa habagatan sa Jerusalem.

* Gitukod ang siyudad sa panahon ni Abram mga 2,000 ka tuig sa wala pa gipanganak si Cristo. Kining maong siyudad pirmi kini gihisgotan sa mga kasaysayan nga gihatag sa Daang Kasabotan.
* Importante kaayo ang Hebron sa kinabuhi ni David. Didto natawo ang pipila sa iyang mga anak, apil si Absalom.
* Giguba sa mga Romano ang siyudad niadtong mga 70 ka tuig sukad gipanganak si Cristo.


# Gesur

Sa panahon ni Haring David, ang Gesur gamay nga gingharian nga makita sa sidlakang dapit sa Dagat sa Galilea, taliwala sa nasod sa Israel ug Aram.

* Si David nakig-alyansa sa mga taga Gesur pinaagi sa pakigminyo kang Maaca nga anak sa hari sa Gesur.
* Si Maaca nanganak ug lalaki kang David, si Absalom.
* Pagkahuman sa pagpatay ni Absalom sa iyang igsoon sa amahan nga si Amnon, milayas siya ngadto sa amihanang kasadpan gikan sa Jerusalem paingon sa Gesur, nga naa sa mga 88 ka milya ang gilay-on.


# Misael

Ang Misael ngalan sa tulo ka lalaki sa Daang Kasabotan. 

* Si Misael usa sa mga ig-agaw ni Aaron. Uban sa lain pa nga lalaki, gisugo siya nga maglubong sa mga lawas niadtong duha ka lalaki nga nagtamastamas sa halaran.
* Adunay lain nga lalaki nga ginganlan ug Misael nga nagtindog tapad kang Esdras, niadtong gibasa ni Esdras ang Balaod nga nakaplagan pag-usab, ngadto sa tanang katawhan.
* Ang usa pa ka Misael usa sa mga amigo ni Daniel nga nabihag didto sa Babilonia uban kaniya. Giilisdan ang iyang ngalan ug Mesac sa mga taga-Babilonia. Mibalibad siya, uban ang iyang mga kauban nga sila Sadrac ug Abednego, nga mosimba sa estatwa sa hari busa gilabay sila ngadto sa nagdilaab nga hurno.


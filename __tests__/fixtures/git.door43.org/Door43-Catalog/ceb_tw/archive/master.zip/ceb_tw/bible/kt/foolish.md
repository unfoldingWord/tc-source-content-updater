# Buang, buang-buang, binuang

Ang pulong nga "buang" kasagarang nagtumong sa usa ka tawo nga maghimo ug sayop nga mga disisyon, labi na sa pagpili sa pagsupak. Ang pulong nga "buang-buang" naghulagway sa tawo o sa batasan nga dili maalamon.

* Sa Biblia ang pulong nga "buang" kasagarang nagtumong sa tawo nga wala motuo o motuman sa Dios. Kasagaran kini sokwahi sa tawo nga maalamon nga nagsalig sa Dios ug mituman kaniya.
* Sa Salmo, gihulagway ni David ang buang nga tawo nga wala motuo sa Dios, gisalikway niya ang tanang ebidinsya nga adunay Dios nga makita sa iyang gilalang.
* Sa libro sa Panultihon sa Daang Kasabotan naghatag ug daghang mga paghulagway kung unsa ang buang o buang-buang nga tawo.
* Ang pulong nga "binuang" nagtumong sa buluhaton nga dili maalamon tungod kay supak kini sa kabubut-on sa Dios. Kasagaran ang "binuang" nag-apil sad sa usa ka butang nga kataw-anan o peligro.

Mga Sugyot sa Paghubad

* Ang pulong nga "buang" pwede hubaron nga, "buang-buang nga tawo" o "dili maalamon nga tawo" o "walay pulos nga tawo" o "dili diosnon nga tawo."
* Ang pamaagi sa paghubad sa "binuang" pwede sad, “kulang sa pagsabut" o "dili maalam" o "walay pulos."


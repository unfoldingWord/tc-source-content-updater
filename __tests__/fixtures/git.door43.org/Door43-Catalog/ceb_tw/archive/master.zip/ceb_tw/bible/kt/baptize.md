# pagbautismo, bautismo

Sa Bag-ong Kasabotan, ang mga pulong nga "pagbautismo" o "bautistmo" kasagaran nagtumong sa pagbubo ug tubig sa usa ka Kristiyano aron magpakita nga siya nahinluan gikan sa sala ug nahiusa kang Cristo.

* Gawas sa bautismo sa tubig, ang Biblia naghisgot sad mahitungod sa "pagbautismo sa Balaang Espiritu" ug "pagbautismo sa kalayo."
* Ang pulong nga bautismo gigamit sad sa Biblia sa pagtumong sa grabe nga pag-antos.

Mga Sugyot sa Paghubad

* Ang mga Kristiyano adunay lainlaing mga panan-aw mahitungod kung unsaon pagbautismo sa tawo ug tubig. Mas maayo nga mahubad kini nga pulong sa kasagaran nga pamaagi nga nagtugot sa lainlaing pamaagi nga pagbubo sa tubig.
* Depende sa konteksto, ang pulong nga "pagbautismo" pwede mahubad sama nga "Ibubo sa" o "ilubog gyud" o "espirituwal nga paghinlo." Pananglitan, "pagbautismo kanimo sa tubig" pwede sad mahubad nga gibubo ang tubig kanimo."
* Ang pulong nga "bautismo" mahubad sad nga, "pagbubo ug tubig kanimo" o "pagtabon" o "espirituhanong paghugas."
* Kung magtumong kini sa pag-antos, ang "bautismo" mahubad sad nga "puno kaayo sa pag-antos" o "pagbubo sa makalilisang nga pag-antos."
* Hunahunaa sad kung giunsa paghubad niini nga pulong sa Biblia sa lokal o nasudnon nga pinulongan.


# maghinulsol, paghinulsol

Ang pulong nga kasagaran gihubad nga "maghinulsol" literal nga buot ipasabot pagtalikod gikan sa pagkamakasal-anon, tawhanon nga pamaagi sa panghunahuna ug pagbuhat, ug mobalik sa pamaagi sa Dios sa panghunahuna ug pagbuhat. Ang paghinulsol mao kini ang pagbasol.

* Sa diha nga ang mga tawo tinuod nga maghinulsol sa ilang mga sala, pasaylu-on sila sa Dios.
* Ang resulta sa pagbasol mao ang pagsugod sa pagsunod sa Dios.
* Kini nga pulong naglakip sa pagbag-o sa kasingkasing, pagbalik kini sa Dios ug pagpalayo gikan sa sala.

Mga Sugyot sa Paghubad:

* Ang pulong nga "maghinulsol" pwede hubaron uban sa pulong o mga pulong nga buot ipasabot, "mibalik."


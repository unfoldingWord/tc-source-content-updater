# Batseba

Batseba
Si Batseba asawa ni Uriah nga usa ka sundalo ni haring David. Nahimo siya nga asawa ni David, ug inahan ni Solomon. 

* Nakabuhat ug pagpanapaw si David kang Batseba sa dihang minyo pa siya kang Uriah.
* Sa dihang namabdos si Batseba sa anak ni David, gusto ni David nga mamatay si Uriah, mao nga gipabalik niya kini sa giyera ug didto namatay si Uriah. Unya giminyoan dayon ni David si Batseba.
* Gisilutan sa Dios si David sa iyang sala pinaagi sa pagkamatay sa anak niya kang Batseba pila ka adlaw lang sa iyang pagkaanak.
* Sa wala magdugay nanganak si Batseba ug usa ka lalaki, si Solomon nga nahimong hari sunod kang David.


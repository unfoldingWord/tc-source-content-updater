# Carmel, bukid nga Carmel

Ang "Bukid nga Carmel" nagtumong sa kabukiran nga makit-an sa gingharian sa Juda sa kabaybayon sa Dagat sa Mediteranea. Ang lungsod nga Carmel makit-an niini nga kabungturan.

* Ang ngalan nga "Carmel" buot ipasabot, "ubasan sa Dios."
* Tabunok ang yuta niining dose ka milya nga kabukiran ug ang iyang mga kapatagan.
* Sa Bukid nga Carmel, gihagit ni Elias ang mga propeta ni Baal aron mapatinud-an niya nga si Yahweh ang nag-inusarang tinuod nga Dios.


# Pula nga Dagat, Dagat sa mga Tambo

Ang Pula nga Dagat mao ang dagat nga nagbulag sa amihanan nga Africa gikan sa peninsula sa Arabia.

* Ang Pula nga Dagat mao ang sidlakan nga utlanan sa Ehipto ug anaa kini sa habagatang-kasadpan sa Gisaad nga Yuta.
* Ang Pula nga Dagat taas ug kipot. Mas dako kini kaysa lanaw o suba, apan mas gamay kini kaysa kadagatan.
* Sa dihang milayas ang mga Israelita sa Ehipto, kinahanglan nga tabukon nila ang Pula nga Dagat.


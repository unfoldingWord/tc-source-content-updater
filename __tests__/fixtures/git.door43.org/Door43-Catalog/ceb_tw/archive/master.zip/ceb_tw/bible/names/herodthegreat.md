# Herodes nga Pangulo

Adunay pipila ka mga pangulo nga ginganlag Herodes sa Biblia. Si Herodes nga Pangulo usa ka dili Judio nga hari sa Judea niadtong panahon nga natawo si Jesus.

* Ilado siya sa iyang pagsugo nga ipaayo ang templo sa mga Judio sa Jerusalem.
* Bangis siya kaayo ug gipapatay niya ang daghang tawo. Niadtong nakadungog siya nga adunay laing hari sa mga Judio nga natawo sa Betlehem, gipapatay niya ang tanang mga batang lalaki didto.
* Ang iyang mga anak nga sila Herodes Antipas ug Herodes Filipo ug ang iyang apo nga si Herodes Agripa kadugayan nahimo sad nga mga pangulo sa Judea. Ang iyang apo sa tuhod nga si Herodes Agripa II (gitawag nga Haring Agripa) nangulo sad sa tibuok lugar sa Judea.


# Mispa

Mispa ang ngalan sa pipila ka mga lungsod sa Daang Kasabotan. Nagpasabot kini nga "dapit nga tan-awanan" o "torre nga bantayanan."

* Niadtong si David gigukod ni Saul, iyang gibilin iyang mga ginikanan sa Mispa, nga gipanalipdan sa hari sa Moab.
* Usa ka siyudad nga gitawag nga Mispa ang nahimutang sa utlanan sa mga gingharian sa Juda ug Israel. Dako kini nga sentro sa kasundalohan.


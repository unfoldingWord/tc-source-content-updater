# Nabucodonosor

Si Nabucodonosor usa ka hari sa Imperyo sa Babilonia. Usa kini ka gamhanan nga imperyo sa panahon sa gingharian sa Israel ug gingharian sa Juda.

* Si Nabucodonosor adunay gamhanan nga kasundalohan nga nibuntog sa daghan  mga grupo sa katawhan.
* Sa pagpangulo ni Nabucodonosor, gisulong ug gibuntog sa kasundalohan sa Babilonia ang gingharian sa Juda ug gidala ang kadaghanan sa mga katawhan sa Juda ngadto sa Babilonia ingon nga mga binihag. Ang "Pagkabinihag sa Babilonia" nilungtad ug 70 ka tuig.


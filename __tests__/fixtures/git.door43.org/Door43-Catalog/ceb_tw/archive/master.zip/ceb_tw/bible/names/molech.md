# Molec, Moloc

Molec ang ngalan sa usa sa mga diosdiosan nga gisimba sa mga Canaanhon. Ang laing mga ispeling niini mao ang "Moloc" ug "Molek."

* Ang mga tawo nga nagsimba kang Molec nagsakripisyo sa ilang mga anak kaniya pinaagi sa pagsunog.
* Ang ubang mga Israelita nagsimba sad kang Molec imbes sa tinuod nga Dios nga si Yahweh.


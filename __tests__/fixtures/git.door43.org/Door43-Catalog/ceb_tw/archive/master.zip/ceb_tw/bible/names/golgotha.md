# Golgota

Ang pulong nga "Golgota" ngalan kini sa lugar nga diin si Jesus gilansang sa krus. Gikan kini sa Aramaic nga pulong nga buot ipasabot "Bagulbagol" o "Lugar sa Bagulbagol."

* Ang Golgota makita dapit sa gawas sa mga paril sa syudad sa Jerusalem, basig dapit sa Bungtod sa Olivo.
* Sa uban nga daan nga mga Englis nga bersyon sa Biblia, ang Golgota gihubad nga "Calvary" o "Kalbaryo," sa binisaya nga gikan sa Latin nga pulong nga gipasabot nga bagulbagol.
* Daghan sa mga bersyon sa Biblia ang migamit sa pulong nga sama sa "Golgota" tungod kay ang buot ipasabot niini gipatin-aw sa konteksto sa Biblia. Tan-awa sad sa [[rc://ceb/ta/man/translate/translate-names]] kung unsa-on sa paghuban ang mga ngalan sa Biblia. [[rc://ceb/ta/man/translate/translate-names]]


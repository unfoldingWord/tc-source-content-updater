# Aram, Taga-Aram

Ang "Aram" usa ka rehiyon diin nagpuyo ang mga paryente ni Abraham. Mao kini karon ang moderno nga nasod sa Syria.

* Ang mga tawo nga nagpuyo diha sa Aram gitawag nga "Taga-Aram" ug nagsulti sa Aramaic nga pinulungan.
* Ang usa ka anak ni Shem ginganlan ug Aram. Ang usa pa ka lalaki nga ginganlan ug Aram mao ang ig-agaw ni Rebeca. Posible nga ang rehiyon nga Aram gipangalan gikan niining duha ka tawo.
* Kini sad nga rehiyon ginganlan ug "Paddan Aram" ug sa kadugayan ginganlan sa Griyego nga "Syria."


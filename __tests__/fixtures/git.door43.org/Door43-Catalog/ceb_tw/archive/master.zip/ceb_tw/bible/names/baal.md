# Baal

Baal ang ngalan sa dili tinuod nga dios nga gisimba sa pipila nga grupo sa mga tawo diha sa yuta sa Canaan.

* Ang ngalan nga "Baal" gapasabot nga "ginoo." Ang pagsimba kang Baal usa ka dakong hagit sa awtoridad ni Yaweh nga mao lang ang tinuod nga Ginoo.
* Apil sa pagsimba kang Baal ang prostitusyon ug usahay apil ang pagsunog sa mga bata nga ilang ihalad.
* Sa lainlaing mga panahon, nakasala ang mga Israelita sa pagsimba sad kang Baal.
* Sa panahon sa paghari ni Ahab, adunay 450 nga mga propeta ni Baal sa amihanang gingharian sa Israel. Gihagit ni propeta Elias sila sa pagsulay nga nagpamatuod nga si Baal dili tinuod ug si Yahweh mao lang ang tinuod nga Dios.
* Tungod ani nga panghitabo, gipatay sa mga tawo ang mga propeta ni Baal ug mibalik sila sa pagsimba kang Yahweh.


# gasa

Ang pulong nga "gasa" nagtumong sa bisan unsang butang nga gihatag o gitanyag sa usa ka tawo. Ang gasa gihatag nga wala maglaom ang naghatag nga makakuha siya ug bisan unsa nga baylo niini.

* Ang kwarta, pagkaon, sinina, ug uban pa nga mga butang nga gihatag ngadto sa mga pobre o kabos nga mga tawo gitawag kini nga "mga gasa."
* Sa Biblia, ang halad o sakripisyo nga gihatag ngadto sa Dios gitawag sad kini nga gasa.
* Ang gasa sa kaluwasan usa ka butang nga gihatag sa Dios pinaagi sa pagtuo kang Jesus.
* Sa Bag-ong Kasabotan, ang pulong nga "mga gasa" gigamit sad nga nagtumong sa pinasahi nga mga espirituhanong katakos nga gihatag sa Dios sa tanan nga mga Kristohanon sa pag-alagad sa uban nga mga tawo.

Mga Sugyot sa Paghubad

* Ang kasagaran sa pulong nga "gasa" pwede hubaron sa pulong o mga pulong nga nagpasabot sa "usa ka butang nga gihatag."
* Sa konteksto sa usa ka tawo nga adunay gasa o pinasahi nga katakos nga gikan sa Dios, ang pulong nga "gasa gikan sa Espiritu" pwede hubaron nga, "espirituhanon nga katakos" o "pinasahi nga abilidad gikan sa Balaan nga Espiritu" o pinasahi nga espirituhanong kahanas nga gihatag sa Dios."


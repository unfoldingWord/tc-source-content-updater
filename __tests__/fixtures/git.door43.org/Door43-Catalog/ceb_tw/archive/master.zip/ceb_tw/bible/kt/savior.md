# Manluluwas

Ang manluluwas mao ang tawo nga moluwas sa uban gikan sa kakuyaw. Pwede sad kini magtumong sa usa ka tawo nga maghatag ug kakusog sa uban o maghatag kanila sa ilang gikinahanglan.

* Sa Daang Kasabotan, gitumong ang Dios nga Manluluwas sa Israel tungod kay kanunay sila nga giluwas niya sa ilang mga kaaway, naghatag kanila ug kusog ug naghatag sa ilang gikinahanglan aron mabuhi.
* Sa Bag-ong Kasabotan, ang "Manluluwas" gigamit nga paghulagway o titulo kang Jesu Cristo tungod kay naghatag siya ug kaluwasan sa gahum ug silot sa sala.

Mga Sugyot sa Paghubad:

* Kung mahimo, kinahanglan ang "Manluluwas" hubaron gamit ang pulong nga adunay kalabotan sa "luwas" ug "kaluwasan."
* Ang mga pamaagi sa paghubad niini nga pulong apil ang "Ang nagluwas" o "Dios nga nagluwas" o "Jesus nga nagluwas."


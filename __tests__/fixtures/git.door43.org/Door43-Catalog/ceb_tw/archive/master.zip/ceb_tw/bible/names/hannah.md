# Hana

Hana mao ang inahan ni propetang Samuel sa Daang Kasabotan. Usa siya sa duha ka mga asawa ni Elcana.

* Dili makapanamkon si Hana mao nga dako kini nga kasubo alang kaniya.
* Didto sa templo, tinud-anay nga nag-ampo si Hana sa Dios nga hatagan siya ug anak ug nisaad siya nga ihalad niya siya sa pag-alagad sa Dios.
* Gibuhat sa Dios ang gihangyo ni Hana ug niadtong sakto na ang edad sa batang si Samuel, gidala siya ni Hana sa templo aron mag-alagad ilawom sa pagpangulo sa pari nga si Eli.
* Gihatagan sad sa Dios si Hana ug uban pang mga anak pagkahuman niini.


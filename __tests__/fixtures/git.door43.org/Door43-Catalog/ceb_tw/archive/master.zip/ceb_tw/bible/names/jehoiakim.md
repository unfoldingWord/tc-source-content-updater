# Joakim

Si Joakim usa ka daotan nga hari nga naghari sa gingharian sa Juda, sugod mga 608 sa wala pa gipanganak si Cristo. Anak siya nga lalaki ni Haring Josias. Eliakim ang orihinal niyang ngalan.

* Ang Ehiptuhanon nga paraon nga si Neco giusab niya ang ngalan ni Eliakim ngadto sa Joakim ug gihimo niya siya nga hari sa Juda.
* Gipugos ni Neco si Joakim nga magbayad ug dako nga buhis sa Ehipto.
* Kaniadtong ang Juda gibuntog ni haring Nabucodonosor, si Joakim usa sa mga gidakop ug gidala sa Babilonia.
* Si Joakim ang hari nga walay dios ug gipalayo niya ang Juda kang Yahweh. Nagsulti si propetang Jeremias ug  propesiya batok kaniya.


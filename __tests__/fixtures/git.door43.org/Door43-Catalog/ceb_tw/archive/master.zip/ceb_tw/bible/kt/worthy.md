# Takos, Bili, Dili takos, Walay bili

Ang pulong nga "takos" naghulagway sa usa ka tawo o usa ka butang nga angayan nga respetohan ug tahoron. Ang "adunay bili" nagpasabot nga bililhon o importante. Ang pulong nga "walay bili" buot ipasabot walay balor.

* Ang takos susama sa pulong nga bililhon o nga adunay kahinungdanon o importansiya.
* Ang "dili takos" buot ipasabot dili angayan sa pinasahi nga pagtagad.
* Sa pagbati nga "dili takos" buot ipasabot pagbati nga dili importante kumpara sa uban o pagbati nga dili angay sa pagtagad nga adunay pagtahod o pagkamaayo.
* Ang pulong nga "dili takos" ug ang pulong nga "walay bili" parehas ug gipasabot, apan aduna say kalainan. Ang pagka "dili takos" buot ipasabot dili angay sa bisan unsa nga pagtahod o pag-ila. Ang pagka "walay bili" buot ipasabot walay gyuy tumong o balor.

Mga Sugyot sa Paghubad

* Ang "takos" pwede hubaron nga "angayan" o "importante" o "bililhon."
* Ang pulong nga "takos" pwede hubaron nga "bili" o "importansiya."
* Ang mga pulong nga "adunay bili" pwede hubaron nga “bililhon" o "mahimong importante."
* Ang mga pulong nga "mas labaw pa ug bili" pwede hubaron nga "mas dako ang balor.”
* Depende sa kontexto ang pulong nga “dili takos” pwede hubaron nga” dili importante”, “walay dunggog” o “dili angayan.”
* Ang pulong nga “walay bili” pwede hubaron nga “walay balor”, “walay katuyuan.”


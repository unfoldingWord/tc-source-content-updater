# apostol, pagkaapostol

Ang "mga apostol" mga tawo nga gisugo ni Jesus nga mowali mahitungod sa Dios ug sa iyang gingharian. Ang pulong nga "pagkaapostol" nagtumong sa katungdanan ug awtoridad adtong gipili nga mga apostoles.

* Ang gipasabot sa pulong nga "apostol", mao ang usa ka tawo nga gisugo alang sa pinasahi nga katuyuan. Ang apostol adunay parehas nga awtoridad adtong nagsugo kaniya. 
* Ang dose nga suod nga disipulo ni Jesus nahimong una nga mga apostoles. Ang ubang mga tawo, sama kang Pablo ug Santiago, nahimo sad nga mga apostoles.
* Pinaagi sa gahum sa Dios, ang mga apostoles misangyaw sa maayong balita nga adunay kaisug ug gahum sa pag-ayo sa mga masakiton, lakip na ang pagpahawa sa mga demonyo diha sa mga tawo.

Mga Sugyot sa Paghubad

* Ang pulong nga "apostol" pwede sad hubaron sa pulong o mga pulong nga nagpasabot sa, "usa nga gisugo" o "usa ka tawo nga gitawag nga magwali sa mensahe sa Dios sa mga tawo."
* Importante nga dili parehas ang paghubad sa mga pulong nga "apostol" ug "disipulo".
* Tan-awa sad kung giunsa kini nga pulong nahubad sa Biblia sa lokal o nasudnong pinulongan.


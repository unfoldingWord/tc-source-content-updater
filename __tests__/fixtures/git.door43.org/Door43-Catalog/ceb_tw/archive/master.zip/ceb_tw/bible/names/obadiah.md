# Abdias

Si Abdias usa ka propeta sa Israel sa panahon ni haring Zedekiah.

* Ang uban pang mga propeta niadto nga panahon mao si Ezekiel ug Daniel.
* Nanagna si Abdias batok sa mga tao sa Edom nga mga kaliwat ni Esau.


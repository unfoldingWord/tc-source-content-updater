# hinlo, paghinlo

Ang pulong nga "hinlo" buot ipasabot wala gyuy buling o mansa. Sa Biblia, kasagaran gigamit kini nga sumbingay nga buot ipasabot, "putli," "balaan," o "luwas gikan sa sala."

* Ang "paghinlo" pamaagi sa paghimo sa usa ka butang nga "hinlo," pwede sad hubaron nga "hugas" o "putlion."
* Sa Daang Kasabotan, gisultihan sa Dios ang mga Israelita kung unsa nga mga mananap ang "hinlo" ug unsa sad ang "dili hinlo." Ang mga hinlo lang gyud nga mga mananap ang gitugot nga pwede nilang kaonon ug ihalad. Sa niini nga konteksto, ang pulong nga "hinlo" buot ipasabot nga ang mananap gidawat na sa Dios aron ihalad.
* Ang tawo nga dunay mga sakit sa panit hugaw siya hangtod maayo ang iyang panit hangtod nga dili na kini makatakod. Ang mga pahimatngon sa paghinlo sa panit kinahanglan gyud nga tumanon aron kadto nga tawo mapahayag nga "hinlo" na usab.
* Usahay ang "hinlo” gigamit nga sumbingay nga nagtumong sa moral nga pagkaputli.

Mga Sugyot sa Paghubad:

* Kini nga pulong pwede sad nga hubaron sa kasagaran nga pulong nga "hinlo" o "putli."


# Gingharian sa Dios, Gingharian sa langit

Kini nga mga pulong nagtumong sa pagpangulo sa Dios ug awtoridad niya sa iyang mga tawo ug sa iyang mga nilalang. Ang Gingharian sa Dios adunay espiritwal ug pisikal nga aspeto.

* Ang pulong nga "langit" sumbingay nga nagtumong sa "Dios."
* Sa Bag-ong Kasabotan, ang libro ni Mateo migamit ug mga pulong nga "gingharian sa langit" sa pagtumong sa "gingharian sa Dios." Kining duha ka pulong adunay parehas nga gipasabot.
* Ang mga propeta sa Daang Kasabotan nag-ingon nga ang Dios nagtukod sa iyang gingharian pinaagi sa pagpadala sa Mesias sa pagpangulo nga adunay pagkamatarong ug pagpilde sa iyang mga kaaway. Si Jesus nga anak sa Dios, mao ang Mesias nga mangulo sa gingharian sa Dios.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "gingharian sa Dios" pwede hubaron nga "ang pagmando sa Dios."


# bato, pagbato

Ang pagbato nagpasabot sa paglabay ug mga bato sa usa ka tawo aron patyon siya.

* Sa adtong una kaayong pananhon, ang pagbato mao ang pamaagi sa pagpatay sa mga kriminal; usahay kini sad gibuhat sa panahon karon.
* Sa mga Israelita sa Daang Kasabotan, ang Dios nagmando sa mga pangulo sa pagbato sa usa ka tawo ingon nga silot sa pipila ka mga sala sama sa pagpanapaw.


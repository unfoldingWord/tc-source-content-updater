# grasya, pagkamaayuhon

Ang pulong nga "grasya" nagtumong sa pagtabang o panalangin nga gihatag sa usa ka tawo nga dili angayan nga makadawat niini. Ang pulong nga "pagkamaayuhon" naghulagway sa usa ka tawo nga nagpakita ug grasya sa uban. 

* Ang grasya sa Dios sa mga makasasala nga mga tawo gasa kini nga gihatag nga libre.
* Ang konsepto sa grasya nagtumong sa pagpakita ug pagkamaayo ug pagpasaylo sa usa ka tawo nga nakahimo ug sayop o mga buhat nga makapasakit sa uban.
* Ang mga pulong nga "aron makadawat ug grasya" sumbingay kini nga buot ipasabot pagdawat ug tabang o kaluoy gikan sa Dios. Kasagaran gilakip niini ang buot ipasabot nga ang Dios nalipay sa usa ka tawo ug gitabangan niya kini.

Mga Sugyot sa Paghubad

* Uban nga mga paagi nga ang "grasya" pwede hubaron mao sad ang "balaan nga pagkamaayo" o "pabor gikan sa Dios" o "pagkamaayo sa Dios ug pagpasaylo sa mga makasasala" o "maluluy-on nga pagkamaayo."
* Ang pulong nga "pagkamaayuhon" pwede sad hubaron nga "puno sa grasya" o "maayo" o "maluluy-on" o " pagkamaayuhon nga adunay kaluoy."
* Ang sumbingay nga "nakadawat siya ug grasya sa mata sa Dios" pwede sad hubaron nga, "nakadawat siya ug kaluoy gikan sa Dios" o "ang Dios maluy-anon nga mitabang kaniya" o "ang Dios nagpakita sa iyang pabor kaniya" o "ang Dios nahimuot kaniya mao nga gitabangan niya siya."


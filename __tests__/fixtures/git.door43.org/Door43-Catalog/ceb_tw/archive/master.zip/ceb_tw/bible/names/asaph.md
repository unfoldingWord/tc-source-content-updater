# Asap

Si Asap usa ka Levita nga pari nga maayo gyud nga musikero ug maoy gahimo sa tono sa mga salmo ni haring David. Misulat sad siya sa iyang kaugalingong mga salmo.

* Si Asap gipili ni haring David nga usa sa tulo nga musikero nga maoy responsable sa giingon nga "kanta sa pag-alagad" diha sa templo.
* Pipila niining mga kanta mga propesiya sad.
* Gibansay ni Asap ang iyang mga anak nga lalaki ug sila kuyog sa ubang mga kaliwat, nagpadayon niini nga resposibilidad sa pagtukar sa mga instrumento ug sa pagpropesiya sa templo.
* Ang mga Salmo 50 ug 73-83 giingon nga gikan kang Asap. Siguro naay gisulat sad nga mga salmo ang iyang pamilya.


# Achab

Si Achab usa ka dautan kaayong hari nga nangulo sa amihanan nga gingharian sa Israel.

* Dautan si Haring Achab ug gidasig niya ang katawhan sa gingharian sa Israel nga mosimba sa mga diosdiosan.
* Giatubang ni propetang Elias si Achab ug giingnan siya nga adunay moabot nga grabeng hulaw sa tulo ug tunga ka tuig ingon nga silot sa mga sala nga nahimo sa Israel tungod ni Achab.
* Adunay 450 ka propeta si Achab alang sa diosdiosan nga si Baal. Gihagit ni Elias kadto nga mga propeta ug gipakita nga si Yahweh lang ang tinuod nga Dios.


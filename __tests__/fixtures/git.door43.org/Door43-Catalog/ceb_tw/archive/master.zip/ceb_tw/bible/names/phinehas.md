# Finehas

Finehas mao ang ngalan sa duha ka mga tawo sa Daang Kasabotan.

* Usa sa mga apo nga lalaki ni Aaron ang pari nga Finehas ang ngalan, nga lig-on nga nagsupak sa pagsimba sa mga diosdiosan sa Israel.
* Giluwas ni Finehas ang mga Israelita gikan sa katalagman nga gipadala ni Yahweh aron silotan sila sa pagminyo sa Midianhon nga mga babaye ug sa pagsimba sa mga diosdiosan.
* Sa pipila ka mga higayon si Finehas mikuyog sa mga kasundaluhan sa Israelita aron laglagon ang mga Midianhon.
* Ang lain nga Finehas nga nahisgutan sa Daang Kasabotan mao ang usa sa daotan ka mga anak nga lalaki ni Eli, ang pari sa panahon ni propeta Samuel.
* Si Finehas ug ang iyang igsoon nga lalaki nga si Hopni, namatay sa dihang ang mga Filistihanon miatake sa Israel ug gikawat ang Arka sa Pakigsaad.


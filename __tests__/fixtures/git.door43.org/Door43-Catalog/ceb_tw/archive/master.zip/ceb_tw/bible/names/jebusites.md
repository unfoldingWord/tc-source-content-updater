# Jebusehanon

Ang Jebusehanon mga tribu sa lugar sa Canaan nga nagagikan sa tawo nga ginganlang Jebus.

* Gisakop ni Jebus ang karaan nga siyudad sa Jerusalem ug ginganlan kini sumala sa iyang kaugalingon, mao nga sa mubo nga panahon gitawag kini nga "Jebus". Kadugayan ang ngalan gibalik sa Jerusalem pag-usab. 
* Si Melquizedek usa ka haring pari sa Daan ug Bag-ong Kasabotan nga kaliwat sa mga Jebusehanon.


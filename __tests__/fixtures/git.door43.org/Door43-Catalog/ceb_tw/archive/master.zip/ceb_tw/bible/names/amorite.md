# Amorihanon

Ang mga Amorihanon usa ka grupo sa katawhan nga nagpuyo sa Canaan sa panahon ni Josue.

* Ang mga Amorihanon nagpuyo sa mga siyudad sa isig ka kilid sa Suba sa Jordan. Ang matag siyudad giharian ug usa ka hari.
* Gisaad sa Dios nga ihatag sa mga Israelita ang yuta sa Canaan, apil ang yuta sa mga Amorihanon.


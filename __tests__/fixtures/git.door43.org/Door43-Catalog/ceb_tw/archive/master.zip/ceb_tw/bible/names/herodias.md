# Herodias

Si Herodias mao ang asawa ni Haring Herodes (Antipas) sa Judea niadtong panahon ni Juan Bautista.

* Sa Herodias mao gyud ang asawa sa igsoon ni Herodes nga si Filipo apan iligal nga giminyo siya ni Herodes.
* Gibadlong ni Juan Bautista sila Herodes ug Herodias sa ilang iligal nga kaminyoon. Tungod niini, gipriso ni Herodes si Juan ug kadugayan, gipapunggotan niya.


# Adonias

Si Adonias mao ang ika-upat nga anak ni Haring David.

* Gisulayan ni Adonias nga mahimong hari sa Israel kadtong namatay na ang iyang mga igsoong lalaki nga sila Absalom ug Amnon.
* Apan gisaad sa Dios ang trono ngadto sa anak ni David nga si Solomon, mao nga wala magmalamposon ang plano ni Adonias ug gihatag kang Solomon ang trono.
* Sa ikaduhang pagsulay ni Adonias nga himoon ang iyang kaugalingon nga hari, gipapatay siya ni Solomon.


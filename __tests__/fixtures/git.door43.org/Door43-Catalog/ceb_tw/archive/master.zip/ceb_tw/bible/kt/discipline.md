# disiplina, disiplina sa kaugalingon

Ang pulong nga "disiplina" nagtumong sa pagbansay sa mga tawo sa pagsunod sa mga giya alang sa moral nga kinaiya.
  

* Ang mga ginikanan nagdisiplina sa ilang mga anak pinaagi sa paghatag ug moral nga giya ug direksyon kanila ug tudluan sila nga magtuman.
* Sama sad sa Dios nagdisiplina siya sa iyang mga anak aron matabangan sila nga makapamunga ug himsog nga espirituhanong bunga sa ilang mga kinabuhi, sama sa kalipay, gugma, ug pasensiya.
* Ang disiplina apil na niini ang pagtudlo mahitungod sa pagkinabuhi nga makapahimuot sa Dios, ug pagsilot sad kaniya kung magbuhat siya ug mga butang nga batok sa kabubut-on sa Dios.
* Ang disiplina sa kaugalingon usa ka proseso sa paggamit sa moral o espirituhanong mga prinsipyo sa kaugalingong kinabuhi.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "disiplina" pwede hubaron nga, "pagbansay ug pagtudlo" o "paggiya sa moral nga kinabuhi" o "pagsilot sa nagbuhat ug sayop."
* Ang "disiplina" pwede hubaron nga "moral nga pagbansay" o "silot" o "moral nga pagtul-id" o "moral nga giya ug pahimatngon


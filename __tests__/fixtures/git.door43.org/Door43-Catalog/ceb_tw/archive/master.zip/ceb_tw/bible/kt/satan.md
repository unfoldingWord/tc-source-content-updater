# Satanas, Yawa, Ang dautan

Ang yawa espirituhanong linalang sa Dios, apan nagrebelde siya batok sa Dios ug nahimong kaaway sa Dios. Ang yawa gitawag sad nga "Satanas" ug "ang dautan."

* Ang yawa nga si Satanas nagdumot sa Dios ug sa tanan nga iyang linalang, tungod kay gusto niyang ilugon ang lugar sa Dios ug simbahon siya ingon nga Dios.
* Gitintal ni Satanas ang mga tawo aron magrebelde batok sa Dios.
* Gipadala sa Dios ang iyang anak nga si Jesus aron luwason ang mga tawo gikan sa pagmando ni Satanas.
* Ang ngalan nga "Satanas" buot pasabot "kaaway" o "kontra."
* Ang pulong nga "yawa" buot pasabot "magsusumbong."

Mag Sugyot sa Paghubad:

* Ang pulong nga "yawa" pwede sad hubaron nga "tigpasangil" o "ang dautan" o "ang hari sa mga dautang espiritu" o " ang pangulo nga dautang espiritu."
* Ang "Satanas" pwede hubaron nga "kasangka" o "kaaway" o uban pa nga ngalan nga magpakita nga siya dautan.
* Kini nga mga pulong kinahanglan hubaron nga lahi sa demonyo ug sa dautan nga espiritu.
* Hunahunaa kung giunsa paghuabad kini nga mga pulong sa lokal o nasudnon nga pinulongan.


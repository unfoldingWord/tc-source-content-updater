# Amasias

Nahimong hari si Amasias sa gingharian sa Juda kadtong gipatay ang iyang amahan nga si Haring Joas.

* Naghari si Haring Amasias sa Juda sulod sa 29 ka tuig.
* Maayo siya nga hari apan wala niya giguba ang mga taas nga lugar diin gisimba ang mga diosdiosan.
* Kadugayan, gipapatay ni Amasias ang tanang lalaki nga maoy nagpapatay sa iyang amahan.
* Gipildi niya ang mga masinupakon nga mga taga-Edom ug gibalik sila sa ilalom sa pagmando sa gingharian sa Juda.
* Gihagit niya sa gubat si Haring Jehoas sa Israel apan napildi siya. Adunay bahin sa paril sa Jerusalem nga naguba ug ang mga plata ug bulawan nga mga galamiton sa templo gikawat.
* Human ang pipila kamga tuig, mitalikod si Haring Amasias kang Yahweh ug adunay mga lalaki sa Jerusalem nga nagsabot ug gipatay siya.


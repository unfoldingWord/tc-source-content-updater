# Elam

Si Elam anak nga lalaki ni Shem nga anak nga lalaki ni Noe.

* Ang mga kaliwat ni Elam ginganlan nga "Elamihanon" ug nagpuyo sa rehiyon nga ginganlang Elam.
* Ang rehiyon nga Elam makita sa habagatang silangan sa Suba sa Tigris nga karon mao ang kasadpang Iran.


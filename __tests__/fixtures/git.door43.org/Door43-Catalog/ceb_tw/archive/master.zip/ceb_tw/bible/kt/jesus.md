# Jesus, Jesu Cristo, Cristo Jesus

Si Jesus mao ang anak sa Dios. Ang ngalan nga "Jesus" nagpasabaot nga "si Yahweh ang magluwas." Ang pulong nga "Cristo" usa ka titulo nga nagpasabot nga "usa nga dinihogan" ug lain sad ni nga pulong sa Mesias.

* Ang duha ka mga ngalan kasagarang gidungan sama sa "Jesu Cristo" o Cristo Jesus." Kini nga ngalan nagpakita nga ang anak sa Dios mao ang Mesias nga mianhi aron luwason ang mga tawo gikan sa walay katapusan nga silot tungod sa ilang mga sala.
* Sa milagroso nga pamaagi, ang Balaan nga Espiritu gipakatawo niya ang walay katapusan nga anak sa Dios sama sa usa ka tawo. Ang iyang mga ginikanan giingnan sa anghel nga panganlan siya nga "Jesus" tungod kay gitagna siya aron luwason ang mga tawo gikan sa ilang mga sala.
* Si Jesus nagbuhat ug daghang mga milagro nga nagpakita nga siya mao ang Dios, ug siya mao ang Cristo o Mesias.

 Mga Sugyot sa Paghubad:

* Daghang mga pinulungan nga gi-ispeling ang "Jesus" ug "Cristo" sa pamaagi nga pareho nga ispeling sama sa orihinal. Pananglitan, ang "Jesu Cristo," "Jezuz Cristus," "Yesus Kristus", ug "Hesukristo" ang pipila sa mga pamaagi nga kini nga mga ngalan gihubad sa lainlaing mga pinulungan.
* Sa pulong nga "Cristo," ang pipila ka mga pinulungan mas gusto nila gamiton ang pulong nga "Mesias" sa tanang paghisgot niini. 
* Hunahunaa sad kung giunsa kini nga mga ngalan gi-ispeling sa duol nga lokal o nasudnong pinulungan.


# Joas

Si Joas ngalan sa pipila ka mga lalaki sa Daang Kasabotan.

* Ang usa ka Joas amahan ni Gedion nga manluluwas sa Israelita.
* Ang lain nga gingalan ug Joas kaliwat ni Benjamin nga kamanghurang anak ni Jacob.
* Ang labing ilado nga Joas nahimong hari sa Juda sa edad nga pito.  Anak siya ni Ahazia, hari sa Juda nga gipatay.
* Niadtong bata pa siya kaayo, giluwas siya sa iyang ayaan aron dili siya mapatay, pinaagi sa pagtago kaniya hangtod nga siya hamtong na nga mahimong hari.
* Sa sinugdanan sa iyang paghari, si Haring Joas mituman sa Dios. Apan sa kadugayan wala na siya mituman sa Dios ug ang mga Israelita nagsugod na sad pagsimba sa mga diosdiosan.
* Paghuman niya nasamad sa gubat, si Haring Joas gibudhian ug gipatay sa duha ka opisyal nga nagtrabaho kaniya.
* Timan-i  nga kini nga hari lahi kang haring Jehoas sa Israel nga nangulo sa parehas nga panahon.


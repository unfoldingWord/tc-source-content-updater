# ihigot, bugkos, gibugkos

Ang pulong nga "ihigot" nagpasabot sa paghigot sa butang o paghigot ug maayo. Ang butang nga gihigot o gihiusa gitawag nga "bugkos."

* Ang "gibugkos" nagpasabot nga ang usa ka butang higtan o puston sa usa ka butang.
* Ang pulong nga "bugkos" nagtumong sa bisan unsa nga gihigot, gibilanggo o gipriso. Kasagaran nagtumong kini sa kadina o pisi nga nagpugong sa tawo aron dili makalihok.
* Sa panahon sa Biblia, ang bugkos, sama sa pisi o kadina gigamit sa paghigot sa usa ka piniriso sa bongbong o salog sa batong prisohan.
* Ang pulong nga "ihigot" pwede sad gamiton sa pagputos sa samad gamit ang panapton aron dali ra kini maayo.
* Ang patay nga tawo bugkuson ug panapton sa pag-andam sa paglubong.
* Ang pulong nga "bugkos" gigamit sa sumbingay nga nagtumong sa usa ka butang, sama sa sala, nga nagkontrolar o nag-ulipon sa usa ka tawo.
* Ang bugkos pwede sad magtumong sa suod nga relasyon sa mga tawo diin nagtinabangay bahin sa ilang emosyon, espirituhanon ug pisikal nga kinahanglanon. Kini magamit sa bugkos sa kaminyuon.
* Pananglitan, ang bana ug asawa "nabugkos" o "nahigot" sa usa'g usa. Bugkos kini nga dili buot sa Dios nga maputol.
* Ang tawo pwede sad "mabugkos" sa usa ka panaad nga nagpasabot nga siya "kinahanglan nga motuman" sa iyang gisaad.

Mga Sugyot sa Paghubad

* Ang pulong nga "ihigot" pwede sad mahubad nga "nahigot" o "higtan" o  "puston".


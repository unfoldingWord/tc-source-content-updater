# balaan, pagkabalaan

Ang mga pulong nga "balaan" ug "pagkabalaan" nagtumong sa kinaiya sa Dios nga lahi ra gyud sa uban ug naglahi kaniya sa tanan nga makasasala ug adunay kasaypanan.

* Ang Dios lang gyud ang hingpit nga balaan. Himoon niya nga balaan ang mga tawo ug mga butang.
* Ang tawo nga balaan iya sa Dios ug gigahin siya alang sa tumong sa pag-alagad sa Dios ug paghatag kaniya ug himaya.
* Ang butang nga gipahayag sa Dios nga balaan mao ang iyang gigahin alang sa iyang himaya ug paggamit, sama sa halaran nga ang tumong mao ra ang paghalad ug mga sakripisyo alang kaniya.
* Tungod kay balaan ang Dios, dili makaduol ang mga tawo kaniya gawas kung tugutan niya sila, tungod kay tawo lang sila nga makasasala ug adunay kasaypanan.
* Sa Daang Kasabotan, gigahin sa Dios ang mga pari ingon nga balaan alang sa pinasahi nga pag-alagad kaniya. Kinahanglan hinlo sila sa sala sumala sa ilang mga seremonyas aron makaduol sila sa Dios.
* Gigahin sad sa Dios ingon nga balaan ang pipila ka mga lugar ug butang nga iyaha o diin niya gipadayag ang iyang kaugalingon, sama sa "balaan nga yuta" (Exodo 3:5) o ang iyang templo.

Mga Sugyot sa Paghubad:

* Ang mga pamaagi sa paghubad sa "balaan" pwede nga "gigahin alang sa Dios" o "iya sa Dios" o "hingpit nga putli" o "hingpit nga walay sala" o "nabulag gikan sa sala."
* Ang "paghimo nga balaan" kasagaran gihubad nga "sanctify" sa Ingles. Pwede sad kini hubaron nga "gigahin."


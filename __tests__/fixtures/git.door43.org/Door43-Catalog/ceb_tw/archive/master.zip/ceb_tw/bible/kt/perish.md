# laglag, malaglag, madunot

Ang pulong nga "laglag" nagpasabot nga mamatay o laglagon nga kasagaran tungod kini sa kagubot o ubang katalagman. Sa Biblia aduna kini pinasahi nga pasabot nga silotan sa walay katapusan sa impiyerno.

* Ang mga tawo nga "malaglag" mao kini ang mga gitakda nga maimpiyerno tungod kay wala nila gituohan si Jesus alang sa ilang kaluwasan.
* Ang Juan 3:16 nagtudlo nga ang "laglag" nagpasabot sa walay kinabuhing dayon sa langit.

Mga Sugyot sa Paghubad:

* Depende sa konteksto, ang mga pamaagi sa paghubad niini nga pulong pwede nga "walay katapusan nga pagkamatay" o "aron silotan sa impiyerno" o "laglagon."
* Siguraduha nga ang paghubad sa "laglag" nagpasabot nga buhi nga walay katapusan sa impiyerno ug dili lamang nagpasabot nga "patay na siya."


# Hukom, Paghukom

Ang pulong nga "hukom" o "paghukom" kasagarang nagtumong sa pagbuhat ug disisyon kung ang usa ka binuhatan sakto o sayop. 

* Ang "paghukom sa Dios " kasagarang nagtumong sa iyang pagdisisyon sa usa ka binuhatan kung sala ba kini o sa pagsilot sa usa ka tawo kung nakasala.
* Ang paghukom sa Dios naglakip sa pagsilot sa mga tawo sa ilang sala.
* Ang "Hukom" nagpasabot sad nga "pagsilot." Gitudloan sa Dios ang iyang mga tawo nga dili maghukom sa usa'g usa sa niini nga pamaagi.
* Ang laing gipasabot niini mao ang tigpataliwala" o "paghukom sa taliwala," sama sa pagdisisyon kung kinsa nga tawo ang sakto sa ilang panaglalis.
* Sa pipila ka mga konteksto, "paghukom" sa Dios mao ang disisyon sa Dios kung unsa ang sakto ug matarong. Susama lang kini sila sa iyang mga sugo, balaod, o mga kalagdaan.
* Ang "paghukom" nagtumong sad sa maalamon nga pagbuhat ug disisyon. Ang tawo nga kulang sa "paghukom" walay kaalam sa paghimo ug maalaamon nga mga disisyon.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pamaagi sa paghubad sa "sa paghukom" pwede sad, "sa pagdisisyon" o "sa pagsilot" o "sa paglagda."
* Ang pulong nga "paghukom" pwede hubaron nga "pagsilot" o "pagdisisyon" o "paghukom" o "paglagda" o "pagsilot."


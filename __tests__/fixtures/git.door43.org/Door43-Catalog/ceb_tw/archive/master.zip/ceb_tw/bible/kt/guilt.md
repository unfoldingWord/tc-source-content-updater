# nakasala, sad-an

Ang mga pulong nga "nakasala" nagpasabot nga ang usa ka tawo gidawat niya ang kamatuoran nga siya nakahimo ug dili maayo o nakabuhat sa usa ka krimen.

* Ang "sad-an" nagpasabot sa pagbuhat ug moral nga sayop, nga mao ang dili pagtuman sa Dios.
* Ang pulong nga "inosente" nagpasabot nga dili "sad-an."

Mga Sugyot sa Paghubad:

* Ang ubang mga pinulongan basin hubaron ang "nakasala" nga "gibug-aton sa sala" o "pag-ihap sa mga sala."
* Ang mga pamaagi sa paghubad sa "sad-an" basin pwede adunay pulong nga nagpasabot nga "nasayop" o "nakabuhat ug moral nga sayop" o "nakabuhat ug sala."

Mga ehemplo sa ULB: tangtangon ang gibug-aton sa imong sala, tangtangon ang imong sala, silotan ang imong sala, dili siya masilotan sa pagpatay, magdala sa iyang kaugalingong sala, hugasan ang iyang sala, makonsensiya pag-ayo sa iyang sala, ang atong sala moabot sa kalangitan


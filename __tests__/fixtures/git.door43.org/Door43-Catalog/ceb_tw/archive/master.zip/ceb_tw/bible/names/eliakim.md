# Eliacim

Eliacim ang ngalan sa duha ka lalaki sa Daang Kasabotan.

* Ang usa nga tawo nga Eliacim mao ang nagdumala sa palasyo sa panahon ni haring Hezekiah gikan sa 715 hangtod 686 nga tuig sa wala pa gipanganak sa Cristo.
* Ang usa pa nga tawo nga Eliacim mao ang anak nga lalaki ni haring Josias. Nahimo siya nga hari sa Juda pinaagi kang Necho ang paraon sa Ehipto sa panahon nga mga 600 nga tuig sa wala pa gipanganak si Cristo.
* Giusab ni Necho ang ngalan ni Eliciam ug Jehoiakim.


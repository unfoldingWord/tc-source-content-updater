# inosente

Ang pulong nga "inosente" nagpasabot nga dili sad-an sa usa ka krimen o sayop nga binuhatan. Kini kasagaran nga nagtumong sad sa mga tawo nga wala maapil sa daotan nga mga butang.

* Gitawag nga inosente ang tawo nga giakusahan nga nagbuhat sa usa ka butang kung wala niya kini buhata.
* Usahay ang pulong nga "inosente" gigamit nga nagtumong sa mga tawo nga wala nakabuhat ug sayop ug dili sila angayan nga makadawat sa dili maayo nga pagtrato, sama sa kasundaluhan nga moatake sa "walay sala nga mga tawo."

Mga Sugyot sa Paghubad:

* Sa kasagaran nga mga konteksto, ang pulong nga "inosente" pwede hubaron nga "dili sad-an" o "dili responsable" o "dili mabasol" sa usa ka butang.
* Kung magtumong sa tanan nga inosente nga mga tawo, kini nga pulong pwede hubaron nga "kadtong wala nagbuhat ug sayop" o "kadtong wala moapil sa daotan."
* Ang kanunay nga nahisgutan nga sumbingay nga "dugo sa inosente" pwede hubaron nga "mga tawo nga wala nakabuhat ug sayop ug dili angayan nga patyon."
* Ang pulong nga "pag-ula sa dugo sa inosente" pwede hubaron nga, "pagpatay sa mga inosente nga mga tawo" o "pagpatay sa mga tawo nga wala nakabuhat ug sayop nga dili angayan patyon."
* Sa konteksto sa usa ka tawo nga gipatay, "inosente sa dugo" pwede hubaron nga "dili sad-an sa pagpatay sa."
* Kung magtumong sa mga tawo nga wala modawat sa maayong mga balita mahitungod kang Jesus, ang "inosente sa dugo" pwede hubaron nga "dilli responsable kung sila magpadayon nga patay sa ilang espirituhanong bahin o wala" o "dili responsable kung dawaton nila kini nga mensahe."
* Kaniadtong giingon ni Judas "nagbudhi ako sa inosente nga dugo" nag-ingon siya nga "nagbudhi ako sa tawo nga walay gibuhat nga sayop" o "ako ang hinungdan sa kamatayon sa usa ka tawo nga inosente."
* Kaniadtong si Pilato nag-ingon mahitungod kang Jesus nga, "inosente ako sa dugo niining tawo nga walay sala" kini pwede hubaron nga "dili ako resposable sa pagpatay niini nga tawo nga walay gibuhat nga sayop ug dili siya angayan patyon."


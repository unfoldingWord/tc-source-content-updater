# Aquila

Si Aquila usa ka Kristuhanon nga Judio sa una nga siglo. Siya ug ang iyang asawa nga si Priscilla, mga misyonaryo sad nga kauban ni Pablo.

* Si Aquila natawo sa probinsiya nga Pontus, duol sa habagatan nga kabaybayonan sa Itum nga Dagat.
* Nagkita si Pablo ug sila Aquila ug Priscilla sa Corinto.
* Si Aquila ug Priscilla nagpuyo sa Roma sa panahon sa wala pa gipahawa ang ubang mga Judio ni Emperador Claudius.
* Ang trabaho sa mag-asawa tighimo ug tolda nga panapton uban ni Pablo, ug gitabangan nila siya sa iyang misyonaryo nga buluhaton.  
* Silang duha ni Aquila ug Priscilla nahisgutan sa Bag-ong Kasabotan sa pipila ka higayon, ingon nga mga katabang ni Pablo. Gitudlo nila sa mga tumutuo ang kamatuoran mahitungod kang Jesus; usa sa ilang gitudluan si Apolos nga maayo gyud motudlo.


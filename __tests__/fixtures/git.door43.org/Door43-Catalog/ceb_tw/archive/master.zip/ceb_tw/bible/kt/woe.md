# kasubo

Ang pulong nga "kasubo" nagtumong sa gibati nga hilabihan nga kasubo o nagsinyal ug mahimatngon sa usa ka tawo nga makasinati ug hilabihan nga kasamok.

* Ang mga pulong nga "alaut ang" gisundan kini ug pasidaan sa usa ka tawo o grupo sa mga tawo (sama sa siyudad) nga sila makasinati ug pag-antos isip silot sa ilang mga sala. 
* Sa pipila ka mga higayon sa Biblia, ang pulong nga "alaut" pabalik balik nga gisulti aron ipahibalo ang panasahi ug grabe nga paghukom.
* Ang mga pulong nga "alaut ako" nagpahayag ug kasubo tungod sa hilabihan nga pag-antos nga nasinatian sa usa ka tawo.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang pulong nga "alaut" pwede sad hubaron nga "hilabihan nga kaguol" o "kasubo" o "kalamidad" o "katalagman


# Adan

Gibuhat si Adan sama sa imahe sa Dios. Gihimo sa Dios si Adan nga adunay daghang mga kinaiya nga anaa mismo sa Dios, sama sa personalidad, ang abilidad sa paghigugma, ang kapasidad sa pagpili, ang pagkahibalo bahin sa kaugalingon, pwede makig-higala sa uban, pakig-istorya, ug daghan pang uban.

* Si Adan ang una nga lalaking tawo.
* Gihulma siya sa Dios gikan sa yuta ug gihuypan siya ug kinabuhi.
* Ang ngalan ni Adan kung paminawon sama sa Hebreohanon nga pulong nga "pula nga yuta" o "yuta."
* Ang ngalan nga "Adan" sama sa pulong sa Daang Kasabotan nga "katawhan" o "tawo."
* Ang tanan nga mga tawo mga kaliwat ni Adan ug Eva.

Gisupak ni Adan ug Eva ang Dios. Gibuhat nila ang gisulti sa Dios nga dili nila buhaton. Mao kini ang nakapabulag kanila sa Dios ug nagdala ug kamatayon nga espirituhanon ug lawasnon sa ilang kinabuhi ug sa kalibutan nga gihimo sa Dios.


# Juan Marcos

Si Juan Marcos, nailhan sad nga, Marcos, ang usa sa mga tawo nga nagbiyahe kauban ni Pablo sa iyang pagbiyahe isip misyonero. Siya tingali ang nagsulat sa libro nga Ebanghelyo ni Marcos.

* Giubanan ni Juan Marcos ang iyang ig-agaw nga si Barnabas ug si Pablo sa ilang unang pagbiyahe isip misyonero.
* Adtong si Pedro napriso sa Jerusalem, ang mga tumutuo nag-ampo kaniya sa balay sa inahan ni Juan Marcos.
* Si Marcos dili usa sa mga orihinal nga apostol, apan tinudluan siya ni Pablo ug Pedro ug nagtrabaho sa ministeryo uban kanila.


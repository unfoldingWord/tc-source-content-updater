# Caifas

Si Caifas pangulo nga saserdote sa Israel niadtong panahon ni Juan nga Bautista ug ni Jesus.

* Si Caifas dako ang iyang parte sa paghukom ug sa pagsilot kang Jesus.
* Si Caifas ang pangulo nga saserdote sa paghukom kang Pedro ug Juan.


# Labing Taas

Ang pulong nga "Labing Taas" usa ka titulo alang sa Dios. Nagtumong kini sa iyang pagkamakagagahum o awtoridad.

* Ang pasabot niini nga pulong sama sa pasabot sa "Ginoo" o "Labing Gamhanan sa Tanan."
* Ang pulong nga "taas" niini nga titulo wala nagtumong sa pisikal nga kahabog o kalayo. Nagtumong kini sa pagkamakagagahum.

Mga Sugyot sa Paghubad:

* Kini nga pulong pwede sad hubaron nga "Kinatas-ang Dios" o "Labaw sa Tanan" o "Dios nga Kinatas-an" o "Ang Labing Gamhanan" o "Ang Labaw sa Tanan" o "Dios nga Labaw sa Tanan."
* Kung ang pulong sama sa "taas" ang gigamit, siguradoha nga wala kini nagtumong sa pisikal nga gitas-on o kahabog.


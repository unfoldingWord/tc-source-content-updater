# Gabriel

Ang Gabriel ngalan sa usa ka anghel sa Dios.

* Gipadala sa Dios si Gabriel aron magsulti ug importante nga mga mensahe sa propeta nga si Daniel, ug sa pari nga si Zacarias, ug sa birhen nga si Maria.
* Sa Daang Kasabotan gihulagway si Gabriel sama sa usa tawo ug maka lupad sad siya.


# Joaquin

Si Joaquin usa sa mga hari nga nangulo sa gingharian sa Juda.

* Si Joaquin nahimong usa ka hari adtong 18 ka tuig pa siya. Naghari lang siya sulod sa tulo ka bulan ug pagkahuman niini gidakop siya sa kasundaluan sa mga taga-Babilonia ug gidala siya sa Babilonia.
* Sa mubo nga panahon sa iyang paghari, si Joaquin nagbuhat ug daotan nga mga butang sama sa gibuhat sa iyang apohan nga hari nga si Manases ug ang iyang amahan nga si haring Joakim.


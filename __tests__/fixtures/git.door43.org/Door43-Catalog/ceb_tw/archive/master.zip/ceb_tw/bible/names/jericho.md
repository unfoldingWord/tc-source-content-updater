# Jerico

Ang Jerico usa ka gamhanan nga siyudad sa Gisaad nga Yuta sa Canaan.

* Kini ang una nga siyudad sa Canaan nga giingon sa Dios sa mga Israelita nga ilang buntogon.
* Sama sa tanang mga Canaanhon, ang mga tawo sa Jerico nagsimba sa mga diosdiosan.
* Kaniadtong gipanguluhan ni Josue ang mga Israelita batok sa Jerico, nagbuhat ang Dios ug dako nga milagro aron tabangan sila nga pildihon ang siyudad.


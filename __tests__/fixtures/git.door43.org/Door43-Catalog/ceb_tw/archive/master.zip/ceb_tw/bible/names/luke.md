# Lucas

Si Lucas mao ang nagsulat sa duha ka libro sa Bag-ong Kasabotan: Ang Ebenghelyo ni Lucas ug Ang Mga Buhat.

* Sa iyang sulat ngadto sa mga taga Colosa, si Pablo naghisgot kang Lucas nga usa ka doktor. Gihisgutan sad ni Pablo si Lucas sa duha pa ka nga mga sulat niya.
* Giubanan ni Lucas si Pablo sa iyang duha ka biyahe isip misyonaryo ug mitabang kaniya sa iyang buluhaton.
* Pipila sa gisulat sa mga tawo sa unang Iglesia, giingon nga si Lucas  gipanganak sa siyudad sa Antoquia sa Syria.


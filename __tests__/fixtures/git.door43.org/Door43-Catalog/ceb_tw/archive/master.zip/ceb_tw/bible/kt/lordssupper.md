# Panihapon sa Ginoo

Ang pulong nga "Panihapon sa Ginoo" gigamit ni apostol Pablo nga nagtumong sa pagpangaon sa panahon sa Kasaulogan sa Pagsaylo nga diin si Jesus mikaon kauban ang iyang mga disipulo sa gabii nga gidakop siya sa mga pangulo sa mga Judio.

* Niini nga pagpangaon, gipikaspikas ni Jesus ang pan sa Kasaulogan sa Pagsaylo ug gitawag kini niya nga iyang lawas nga dili magdugay latiguhon ug patyon.
* Gitawag niya ang bino sa kopa nga iyang dugo, nga dili magdugay moagas sa dihang mamatay siya nga isakripisyo alang sa sala.
* Si Jesus nagsugo sa iyang mga sumusunod nga kanunay nila kini nga buhaton sa paghinumdom sa iyang kamatayon ug pagkabanhaw.
* Sa iyang sulat sa Mga Taga Corinto, si apostol Pablo gipalig-on niya pag-ayo ang Panihapon sa Ginoo nga kanunay nga himuon sa mga tumutuo kang Jesus.
* Ang mga iglesia karon kanunay nga migamit sa pulong nga "kumunyon" nga nagtumong sa Panihapon sa Ginoo. Ang pulong nga "Ulahing Panihapon" usahay gigamit sad.

Mga Sugyot sa Paghubad:

* Kini nga mga pulong pwede sad hubaron nga "ang pagkaon sa Ginoo" o "pagkaon sa atong Ginoong  Jesus" o "ang pagkaon sa paghinumdom sa Ginoong Jesus."


# Ezequias

Si Ezequias mao ang ika-13 nga hari sa gingharian sa Juda. Usa siya ka hari nga nisalig ug nituman sa Dios.

* Dili sama sa iyang amahan nga si Ahaz nga dautang hari, si Haring Ezequias naghimo ug diosnong mga pagbag-o pinaagi sa paghunong sa pagsimba sa mga diosdiosan sa Juda.
* Niadtong tinud-anay nga nag-ampo si Ezequias, gi-ayo siya sa Dios sa iyang grabe nga sakit ug gitugutan siya nga mabuhi pa ug 15 ka tuig.
* Ingon nga timaan kang Ezequias nga mahitabo kini, gipaatras sa Dios ang adlaw nga makita sa instrumento nga gitawag sa Ingles nga "sundial."


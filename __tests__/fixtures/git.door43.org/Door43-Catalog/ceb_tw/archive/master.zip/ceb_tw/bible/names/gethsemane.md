# Getsemane

Ang Getsemane tanaman kini sa mga olivo nga kahoy sa sidlakang dapit kini sa Jerusalem layo pa sa kapatagan sa Kidron duol sa Bukid sa Olivo.

* Ang tanaman sa Getsemane mao ang lugar nga diin si Jesus ug ang iyang mga tagasunod moadto aron mag-inusara ug mopahulay, layo sa kadaghanan.
* Dinhi si Jesus hilabihan nga nag-antos sa pag-ampo usa siya gibudhian ni Hudas, ug didto siya gidakop.


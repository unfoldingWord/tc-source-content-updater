# Moab, Moabitanhon, Moabitanhong babaye

Si Moab mao ang anak nga lalaki sa mas magulang nga babayeng anak ni Lot. Gitawag nga mga Moabitanhon ang iyang mga kaliwat ug ang yuta nga ilang gipuy-an kadugayan gitawag nga "Moab."

* Ang nasod sa Moab nahimutang sa sidlakan sa Judea, sa pikas nga kilid sa Patay nga Dagat. Anaa kini dapit sa habagatan-sidlakan sa Betlehem nga siyudad sa Judea, diin gikan ang pamilya ni Naomi.
* Ang pulong nga "Moabitanhong babaye" pwede hubaron nga "babaye nga taga-Moab" o "babaye gikan sa Moab."


# Gilgal

Ang Gilgal usa ka lungsod sa amihanan sa Jerico ug ang unang lugar nga gikampohan sa mga Israelita pagkalabang nila sa suba sa Jordan sa pagsulod sa Canaan.

* Sa Gilgal, si Josue nagbutang ug dose ka bato nga gikuha gikan sa uga nga suba sa Jordan nga ilang gitabokan.
* Ang Gilgal mao ang siyudad nga diin si Elias ug si Eliseo mibiya sa ilang pagtabok sa Jordan sa dihang si Elias gikuha paingon sa langit.
* May pipila sad ka mga lugar nga gitawag nga "Gilgal" sa Daang Kasabotan.
* Ang pulong nga "gilgal" buot ipasabot "mga bato nga gihan-ay palingin," basin nagtumong kini sa lugar nga diin gitukod ang halaran nga mga bato nga gihan-ay palingin. Sama kini sa pulong nga nagtumong sa mga butang nga moligid.
* Ang pulong nga Gilgal kasagaran giingon nga "ang Gilgal," nga nagpaila nga kini usa ka klase nga lugar, ug dili ngalan sa usa ka lugar.


# abughoan, pagpangabugho

Ang pulong nga "abughoan" ug "pagpangabugho" nagtumong sa grabe nga tinguha aron panalipdan ang kaputli sa usa ka relasyon. Pwede sad kini nga magtumong sa grabe nga tinguha sa pagkuha sa pagpanag-iya sa usa ka butang o usa ka tawo.

* Kini nga mga pulong kasagaran naghulagway sa kasuko sa usa ka tawo ngadto sa iyang bana o asawa nga dili matinud-anon sa ilang kaminyoon.
* Kung kini gamiton sa Biblia, kini nga mga pulong kasagaran nagtumong sa kabubut-on sa Dios alang sa iyang katawhan nga magpabilin nga putli ug walay mantsa sa sala.
* Ang Dios sad "abughoan" mahitungod sa iyang ngalan nga kinahanglan nga mahatagan ug dungog ug pagtahod.
* Ang lain pa nga pasabot sa abughoan mao ang pagkasuko sa usa ka tawo tungod kay siya malampuson o mas ilado. Duol kini sa pasabot sa pulong nga "kasina."

Mga Sugyot sa Paghubad

* Ang mga pamaagi sa paghubad sa "abughoan" pwede sad nga "grabe nga tinguha sa pagpanalipod" o "tinguha sa pagpanag-iya."
* Ang pulong nga "pagpangabugho" pwede hubaron nga "grabe nga pagpanalipod" o "pagbati nga iya ra gyud." 
* Kung magtumong mahitungod sa Dios, siguraduha nga ang paghubad niini nga mga pulong dili maghatag ug negatibo nga pasabot sa pagkasuko sa lain nga tawo.
* Sa konteksto kung gamiton sa mga sayop nga mga pagbati sa kasuko ngadto sa ubang mga tawo nga mas malampuson kaysa uban, ang mga pulong nga "masina" ug "kasina" mahimong gamiton. Apan kini nga mga pulong kinahanglan dili gamiton alang sa Dios.


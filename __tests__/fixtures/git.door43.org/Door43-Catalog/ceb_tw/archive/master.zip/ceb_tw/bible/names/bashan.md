# Basan

Ang Basan usa ka lugar sa katimugan sa Dagat sa Galilea. Mao kini ang yuta karon nga parte na sa Syria ug "Golan Heights".

* Ang siyudad sa Daang Kasabotan adunay siyudad nga dalangpanan nga ginganlang "Golan" nga anaa sa rehiyon sa Basan.
* Ang Basan usa ka tabunok nga rehiyon nga nailhan kay aduna kini mga kahoy nga Enica ug mga mananap nga gasabsab.
* Sa Genesis 14 naitala nga ang Basan usa ka lugar diin nahitabo ang gubat batok sa pipila nga mga hari ug ang ilang mga nasod.
* Sa panahon nga ang mga Israelita naglibot-libot sa disyerto pagkahuman nga miikyas sila gikan sa Ehipto, gipanag-iya nila ang parte sa rehiyon sa Basan.
* Human milabay ang pipila ka tuig, nagkuha si Haring Solomon ug mga kinahanglanon nila gikan sa rehiyon.


# Oseas

Si Oseas usa ka hari sa Israel sulod sa siyam ka tuig sa mga panahon nga naghari si Ahaz ug si Ezequias nga mga hari sa Juda.

* Si Oseas anak nga sad ni Nun nga gikan sa tribu ni Efraim.
* Guisab ni Moises ang ngalan ni Oseas sa ngalan nga Josue usa pa niya siya gipadala uban ang onse ka mga tawo aron maniid didto sa lugar sa mga Canaanhon.
* Pagkamatay ni Moises, nangulo si Josue sa mga tawo sa Israel aron angkunon ang mga lupa ug sa mga taga-Canaan.


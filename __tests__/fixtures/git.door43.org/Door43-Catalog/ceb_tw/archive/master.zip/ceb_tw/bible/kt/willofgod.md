# kabubut-on sa Dios

Ang "kabubut-on sa Dios" nagtumong sa tinguha ug plano sa Dios.

* Ang kabubut-on sa Dios nagtumong sa pakigsulti sa Dios sa iyang mga tawo ug kung unsa ang buot niya nga pagtubag sa mga tawo kaniya.
* Nagtumong sad kini sa iyang plano ug tinguha sa tanan niyang mga linalang.

Mga Sugyot sa Paghubad:

* Sa mga Roma 12:2, nag-ingon si Pablo mahitungod sa " maayo, hingpit ug mahimayaong kabubut-on sa Dios."  Siguraduha nga ang paghubad niini dili maingon nga adunay labaw pa sa usa ka klase sa kabubut-on sa Dios. Ang ubang pamaagi sa paghubad niini mao ang, " Ang kabubut-on sa Dios maayo, hingpit ug mahimayaong kabubut-on." 
* Ang "kabubut-on sa Dios" pwede hubaron nga, "ang tinguha sa dios" o "ang plano sa Dios" o " katuyoan sa Dios"


# Santiago (anak ni Zebedeo)

Si Santiago nga anak ni Zebedeo, usa sa mga dose ka mga apostoles ni Jesus. Adunay iyang manghod nga Juan ang ngalan ug usa sad sa mga apostoles ni Jesus.

* Si Santiago ug ang iyang igsoon nga si Juan mangingisda uban ang iyang amahan nga si Zebedeo.
* Si Santiago ug si Juan gianggaan ug "Mga anak sa dalugdog," tingali kay dali ra sila masuko.
* Lahi kini sa usa ka Santiago nga misulat sa libro sa Biblia. Sa pipila ka mga pinulungan pwede nga isulat ang ilang mga ngalan sa lahi nga paagi aron mahimong klaro nga dili sila ang pareho nga tawo.


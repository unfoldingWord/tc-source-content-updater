# Arka sa Pakigsaad, Arka sa mga sugo sa pakigsaad, Arko sa saksi, Arka ni Yahweh

Kini nga mga pulong nagtumong sa pinasahi nga kaban nga kahoy nga gihal-upan ug bulawan nga gihimo aron kabutangan sa duha ka papan nga bato nga diin giukit ang Napulo nga Kasuguan.

* Nakabutang sad sa arka sa pakigsaad ang sungkod ni Aaron ug usa ka banga nga adunay manna.
* Kini nga mga butang gapahinumdom sa gisaad sa Dios sa iyang katawhan, ang mga Israelita.
* Ang arka sa pakigsaad makita sa dapit nga labing balaan sa tabernaculo, ug sa kadugayan didto na sa templo.
* Kung buot sa Dios nga mosulti sa Israel pinaagi kang Moises diha sa tabernaculo, ang presensiya sa Dios magpakita sa ibabaw sa arka sa pakigsaad.
* Ang kinatas-ang pari mao ra ang makaduol sa arka sa pakigsaad nga tua sa dapit nga labing balaan sa templo, buhaton niya kini kada usa sa usa ka tuig sa Adlaw sa Pagpapas sa mga Sala.
* Ang pulong nga "arka sa mga sugo sa pakigsaad" sa literal nga pagkasulti mao ang "arko sa saksi." Ang "saksi" nagtumong sa Napulo ka Kasuguan nga nagpamatuod sa pakigsaad sa Dios sa iyang katawhan.


# Saduseo

Ang Saduseo usa ka politikal nga grupo sa mga paring Judio sa panahon ni Cristo Jesus nga nagsuporta sa pagpangulo sa mga Romano ug dili sila motuo sa pagkabanhaw sa tawo.

* Ang mga Saduseo adunahan ug taas ang estado nga mga Judio nga adunay posisyon sa pagmando nga makagagahum sama sa pangulong pari ug kinatas-ang pari.
* Ang mga katungdanan sa mga Saduseo naglakip sa pag-atiman sa kinatibuk-an sa templo ug mga katungdanan sa pari sama sa paghalad sa mga sakripisyo.
* Ang mga Saduseo ug mga Pariseo dako ang ilang kalabutan sa paglansang sa krus kang Cristo Jesus.
* Si Jesus nagsulti batok niining duha ka grupo sa relihiyon tungod sa ilang pagkamakaugalingon ug pagpakaaron-ingnon.


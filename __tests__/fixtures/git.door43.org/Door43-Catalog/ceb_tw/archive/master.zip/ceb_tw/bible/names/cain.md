# Cain

Si Cain ug ang iyang manghod nga lalaki nga si Abel mao ang mga unang anak ni Adan ug ni Eba nga gihisgutan sa Biblia.

* Si Cain mag-uuma ug si Abel nagbuhi ug mga karnero.
* Gipatay ni Cain ang iyang igsoon nga si Abel sa sobra niya nga pangabugho, tungod kay gidawat sa Dios ang sakripisyo ni Abel, apan wala Niya dawata ang sakripisyo ni Cain.
* Ingon nga silot, gipahawa siya sa Dios sa Eden ug giingnan nga ang yuta dili na maghatag ug abot kaniya.


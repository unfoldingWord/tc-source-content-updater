# Nati nga karnero, Nati nga Karnero sa Dios

Ang pulong nga "nati nga karnero" nagtumong sa bata sa mga karnero. Ang karnero adunay upat ka mga tiil nga mananap, nga adunay baga ug kupkop nga balahibo, nga ]gigamit sa pagsakripisyo sa Dios. Gitawag si Jesus nga "Nati nga Karnero sa Dios" tungod kay gisakripisyo siya sa pagbayad sa mga sala sa mga tawo.

* Kini nga mga mananap dali ra nga masalaag ug kinahanglan mapanalipdan. Gitandi sa Dios ang mga tawo sa mga karnero.
* Gitudluan sa Dios ang iyang mga tawo sa pagsakripisyo sa walay depekto nga mga karnero ug nati nga mga karnero ngadto kaniya.
* Gitawag sad si Jesus nga "Nati nga Karnero sa Dios" nga gisakripisyo sa pagbayad sa atong mga sala. Hingpit siya, walay tatsa nga sakripisyo tungod kay wala gyud siyay sala.

Mga Sugyot sa Paghubad

* Kung ang karnero nailhan sa pinulongan nga hubaron, ang pulong nga nagtumong sa batang karnero ang gamiton gyud sa paghubad sa pulong nga "nati nga karnero" ug "Nati nga Karnero sa Dios."
* Ang "Nati nga Karnero sa Dios" pwede hubaron nga literal gamit ang pulong sa pinulongan sa nating karnero.


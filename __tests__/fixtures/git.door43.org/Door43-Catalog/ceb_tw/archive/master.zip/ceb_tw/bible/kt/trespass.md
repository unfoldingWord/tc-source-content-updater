# makalapas

Ang "makalapas" nagpasabot sa pagsupak sa balaod o sa pagpa-walay bili sa mga katungod sa ubang tawo.

* Ang makalapas pwede paglapas sa moral o sibil nga balaod o sala nga nahimo batok sa uban nga tawo.
* Kini nga pulong may kalabutan sa pulong nga "sala" ug " milapas," labi na kung ang gihisgutan ang dili pagsunod sa Dios.
* Ang tanang mga sala mga kalapasan batok sa Dios.

Mga Sugyot sa Paghubad

* Depende sa konteksto, "ang pagkalapas sa" pwede hubaron nga "pagkasala batok" o "dili pagtuman sa kamandoan."
* Ang pipila ka mga pinulongan aduna siguroy sumbingay sama sa "paglapas sa linya" nga pwede gamiton sa paghubad sa "makalapas."
* Hunahunaa kung unsaon paghaom niini nga pulong nga adunay pasabot sa teksto sa Biblia ug itandi kini sa ubang mga pulong nga adunay parehas nga gipasabot sama sa "milapas " ug "sala."


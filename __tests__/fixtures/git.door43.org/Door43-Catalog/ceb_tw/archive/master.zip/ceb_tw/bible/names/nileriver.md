# Suba sa Nilo, Suba sa Ehipto

Ang Nilo usa ka taas ug lapad nga suba sa amihanan-sidlakang Africa. Ilado gyud kini siya ingon nga kinadak-ang suba sa Ehipto.

* Ang Suba sa Nilo midagayday sa Ehipto ug miawas ngadto sa Dagat sa Mediteraneo.
* Maayo ang pagtubo sa mga pananom nga makaon sa tabunok nga walog niini.
* Kadaghanan sa mga Ehiptohanon nagpuyo duol sa Suba sa Nilo tungod kay importante kini nga kakuhaan ug tubig ug tanamang pagkaon.
* Adtong batang gamay pa si Moises, gibutang siya sa usa ka basket didto sa katamboan sa Nilo.


# pagpasipala

Sa Biblia, ang pulong nga "pagpasipala" nagtumong sa pagsulti nga walay respeto sa Dios o sa tawo. Ang "pagpasipala" sa usa ka tawo mao ang pagsulti batok sa usa aron ang uban maghunahuna ug bakak o dili maayo mahitungod kaniya.

* Kasagaran, ang pagpasipala sa Dios nagpasabot nga pagbutangbutang o pag -insulto kaniya pinaagi sa pagsulti ug mga butang nga dili tinuod mahitungod kaniya o sa paggawi sa imoral nga binuhatan nga wala nagpasidungog kaniya.
* Pagpasipala sa usa ka tawo kung ga-angkon siya nga siya Dios o kung ga-angkon nga adunay pay lain nga Dios gawas sa tinuod nga Dios.
* Ang uban nga mga bersyon sa Ingles naghubad niini nga pulong nga " pagbutangbutang" kung magtumong sa pagpasipala sa usa ka tawo.

Mga Sugyot sa Paghubad

* Ang "pagpasipala" pwede sad hubaron nga, "pagsulti ug dautan batok sa " o wala nagpasidungog sa Dios" o "pagbutangbutang"
* Ang pamaagi sa paghubad sa "pagpasipala" pwede sad "pagsulti ug sayop sa uban" o "pagbutangbutang" o "pagpakaylap ug bakak."


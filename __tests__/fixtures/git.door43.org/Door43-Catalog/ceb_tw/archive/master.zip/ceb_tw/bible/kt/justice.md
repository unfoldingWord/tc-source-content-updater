# Matarong, matarungangon

Kini nga pulong nagtumong sa pagtrato sa mga tawo sa patas nga pamaagi sumala sa mga balaod sa Dios. Matarong sad ang mga balaod sa tawo nga nagpakita kung unsa ang sumbanan sa Dios sa sakto nga pamatasan.

* Ang "pagkamatarong" mao ang pagbuhat sa sakto ug patas sa ubang mga tawo. Nagpakita sad kini ug pagkamatinuoron ug adunay integridad sa pagbuhat kung unsa ang sakto sa panan-aw sa Dios.
* Ang "matarungangon" nga pagbuhat nagpasabot sa pagtratar sa mga tawo sa sakto, maayo ug tukma nga pamaagi sumala sa mga balaod sa Dios.
* Ang pag-angkon ug "hustisya" nagpasabot nga ang usa ka tawo gitratar nga patas sumala sa balaod,  gipanalipdan pinaagi sa balaod man o gisilotan tungod sa pagsupak sa balaod.
* Usahay ang pulong nga "matarong" adunay lalom nga gipasabot sa "pagkamatarong" o "pagsunod sa balaod sa Dios."

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang ubang pamaagi sa paghubad sa "matarong" nag-apil sa, "batasan nga sakto" o "patas."
* Ang pulong nga "hustisya" pwede hubaron nga, "patas nga pagtratar" o "angayan nga sangputanan."
* Ang "matarungangon" pwede hubaron nga, "pagtratar ug patas" o "paggawi sa sakto nga pamaagi."
* Sa ubang mga konteksto, "ang matarong" pwede hubaron nga, "pagkamatarong" o "matul-id."


# Pasaylo, Pagpasaylo

Ang pagpasaylo sa usa ka tawo nagpasabot sa dili pagdumot ngadto sa tawo nga naghatag ug kasakitan. Ang pagpasaylo mao ang paghatag ug pasaylo sa usa ka tawo.

* Ang pagpasaylo sa usa ka tawo kasagarang nagpasabot sa dili pagsilot sa usa ka tawo nga nakabuhat ug sayop.
* Kini nga pulong pwede sad gamiton nga sumbingay nga nagpasabot sa, "pagtangtang" sama sa mga pulong nga "pagpasaylo sa utang."
* Kung ang mga tawo magsugid sa ilang mga sala, ang Dios magpasaylo sad kanila tungod sa sakripisyo sa pagkamatay ni Jesus sa krus.
* Gitudluan ni Jesus ang iyang mga disipolo sa "pagpasaylo" sa uban sama sa pagpasaylo niya kanila.

Mga Sugyot sa Paghubad

* Depende sa konteksto, ang "pasaylo" pwede hubaron nga "pagtangtang" o "buhian" o "dili paghunahuna nga nakasala ang usa ka tawo."


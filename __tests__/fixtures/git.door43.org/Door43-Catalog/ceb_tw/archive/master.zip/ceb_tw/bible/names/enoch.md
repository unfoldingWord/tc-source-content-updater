# Enoch

Si Enoch nga amahan ni Methusalam ug kaapoapohan sad nga amahan ni Noe gihisgutan sa pipila ka higayon sa Daan ug Bag-ong Kasabotan.

* Si Enoch adunay suod nga relasyon sa Dios.
* Sa dihang 365 anyos si Enoch, gikuha siya sa Dios sa langit nga buhi nga wala mamatay.
* Kini nga Enoch kaliwat ni Set. Lahi siya sa usa ka Enoch nga ang amahan mao si Cain. Sa pipila ka mga pinulungan mas ganahan sila nga gamiton ang lainlaing nga ispeling niining duha ka ngalan aron maklaro nga silang duha dili pareho.


# Lawas

Ang pulong nga "lawas" nagtumong sa pisikal nga lawas sa tawo o mananap. Kini nga pulong gigamit sad sa sumbingay nga nagtumong sa usa ka butang o tibuok nga grupo nga adunay tagsa-tagsa nga membro.

* Kasagaran ang pulong nga "lawas" nagtumong sa patay nga tawo o mananap. Usahay nagtumong kini sa "patay nga lawas."
* Adtong si Jesus miingon sa iyang mga disipolo sa iyang katapusang kaon sa Kasaulugan sa Pagsaylo, "Kini nga (pan) ang akong lawas," nagtumong siya sa iyang kaugalingong lawas nga "balion" (patayon) nga bayad sa ilang mga sala.
* Sa Biblia, ang grupo sa mga tumutuo giisip nga "lawas ni Cristo."
* Sama sa pisikal nga lawas nga adunay daghan nga mga parti, ang "lawas ni Cristo" adunay daghang tagsa-tagsa nga mga membro.
* Ang matag usa ka tumutuo adunay pinasahi nga gamit sa lawas ni Cristo aron makatabang sa katibuk-an nga tingub nga gatrabaho sa pag-alagad sa Dios ug maghatag ug himaya kaniya.
* Giingon sad nga si Jesus ang "ulo" sa "lawas" sa iyang mga tumutuo. Sama nga ang ulo sa tawo magsulti sa lawas kung unsa ang buhaton, si Jesus sad ang naggiya kanato ug nagdirekta sa mga kristohanon ingon nga membro sa iyang "lawas."  

Mga Sugyot sa Paghubad

* Ang labing maayo nga pamaagi sa paghubad niini nga pulong mao ang pulong sa "lawas" nga gigamit sa pinulongan nga ihubad. Siguraduha nga ang pulong nga gamiton dili makapasuko sa mga namati.
* Kung tiningub nga magtumong sa mga tumutuo, sa ubang nga pinulongan mas natural ug tukma nga ingnon, "ang epirituhanong lawas ni Cristo."
* Kung miingon si Jesus, "Kini ang akong lawas" maayo nga hubaron kini nga literal, nga adunay mubo nga isulti sa pagpatin-aw kung kinahanglanon kini.
* Ang ubang pinulongan tingalig adunay lahi nga pulong sa pagtumong sa patay nga lawas sa tawo o sa mananap. Sigurudoha gyud nga ang pulong nga gigamit sa paghubad niini mouyon sa konteksto ug mouyon ang mga tawo niini.


# ceb_NT_text_ULB_L3

Level 3 Cebuano text converted to USFM.

# Source version information

The list below shows which version of the *English ULB* each book was translated from.  The latest English ULB is version 10.

* 1co: "6"
* 1jn: "5"
* 1pe: "6"
* 1th: "8"
* 1ti: "8"
* 2co: "6"
* 2jn: "5"
* 2pe: "6"
* 2th: "8"
* 2ti: "8"
* 3jn: "5"
* act: "4"
* col: "5"
* eph: "4"
* gal: "5"
* heb: "5"
* jas: "5"
* jhn: "6"
* jud: "5"
* luk: "4"
* mat: "5"
* mrk: "4"
* phm: "5"
* php: "5"
* rev: "4"
* rom: "4"
* tit: "5"

# hi_ULB

Hindi ULB text

NT from  https://git.door43.org/BCS-BIBLE/Hindi-ULB-NT.BCS/src/master/Stage3 and https://git.door43.org/BCS-BIBLE/Hindi-ULB-NT.BCS/src/master/Revised%20Stage%203

OT from https://git.door43.org/BCS-BIBLE/HINDI-ULB-OT.BCS/src/branch/master/Revised%20stage%203

STR https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/184
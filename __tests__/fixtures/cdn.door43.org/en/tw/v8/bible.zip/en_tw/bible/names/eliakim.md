# Eliakim #

## Facts: ##

Eliakim was the name of two men in the Old Testament.

* One man named Eliakim was the manager of the palace under King Hezekiah.
* Another man named Eliakim was a son of King Josiah. He was made king of Judah by the Egyptian pharaoh Necho.
* Necho changed Eliakim's name to Jehoiakim.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Hezekiah](../names/hezekiah.md), [Jehoiakim](../names/jehoiakim.md), [Josiah](../names/josiah.md), [Pharaoh](../names/pharaoh.md))

## Bible References: ##

* [2 Kings 18:16-18](rc://en/tn/help/2ki/18/16)
* [2 Kings 18:26-27](rc://en/tn/help/2ki/18/26)
* [2 Kings 18:36-37](rc://en/tn/help/2ki/18/36)
* [2 Kings 23:34-35](rc://en/tn/help/2ki/23/34)

## Word Data: ##

* Strong's: H471, G1662

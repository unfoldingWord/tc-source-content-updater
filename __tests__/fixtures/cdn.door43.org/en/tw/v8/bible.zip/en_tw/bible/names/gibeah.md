# Gibeah #

## Facts: ##

Gibeah was a city located north of Jerusalem and south of Bethel.

* Gibeah was in the territory of the tribe of Benjamin.
* It was the site of a huge battle between the Benjamites and Israel.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Benjamin](../names/benjamin.md), [Bethel](../names/bethel.md), [Jerusalem](../names/jerusalem.md))

## Bible References: ##

* [1 Samuel 10:26-27](rc://en/tn/help/1sa/10/26)
* [2 Samuel 21:5-6](rc://en/tn/help/2sa/21/05)
* [Hosea 09:8-9](rc://en/tn/help/hos/09/08)
* [Judges 19:12-13](rc://en/tn/help/jdg/19/12)

## Word Data: ##

* Strong's: H1387, H1389, H1390, H1394

# Rabbah #

## Definition: ##

Rabbah was the most important city of the Ammonite people.

* In battles against the Ammonites, the Israelites often attacked Rabbah.
* Israel's King David captured Rabbah as one of his last conquests.
* The modern-day city Amman Jordan is now where Rabbah used to be located.

(See also: [Ammon](../names/ammon.md), [David](../names/david.md))

## Bible References: ##

* [1 Chronicles 20:1](rc://en/tn/help/1ch/20/01)
* [2 Samuel 12:26-28](rc://en/tn/help/2sa/12/26)
* [Deuteronomy 03:11](rc://en/tn/help/deu/03/11)
* [Ezekiel 25:3-5](rc://en/tn/help/ezk/25/03)
* [Jeremiah 49:1-2](rc://en/tn/help/jer/49/01)

## Word Data: ##

* Strong's: H7237

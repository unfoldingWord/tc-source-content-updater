# Ephrath, Ephrathah, Ephrathite, Ephrathites #

## Facts: ##

Ephrathah was the name of a city and region in the northern part of Israel. The city of Ephrathah was later called "Bethlehem" or "Ephrathah-Bethlehem."

* Ephrathah was the name of one of Caleb's sons. The city of Ephrathah was probably named after him.
* A person who was from the city of Ephrathah was called an "Ephrathite."
* Boaz, the great-grandfather of David, was an Ephrathite.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Bethlehem](../names/bethlehem.md), [Boaz](../names/boaz.md), [Caleb](../names/caleb.md), [David](../names/david.md), [Israel](../kt/israel.md))

## Bible References: ##

## Word Data: ##

* Strong's: H672, H673

# Potiphar #

## Facts: ##

Potiphar was an important official for the pharaoh of Egypt during the time that Joseph was sold as a slave to some Ishmaelites.

* Potiphar bought Joseph from the Ishmaelites and appointed him to be in charge of his household.
* When Joseph was falsely accused of doing wrong, Potiphar had Joseph put in prison.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Egypt](../names/egypt.md), [Joseph (OT)](../names/josephot.md), [Pharaoh](../names/pharaoh.md))

## Bible References: ##

* [Genesis 37:34-36](rc://en/tn/help/gen/37/34)
* [Genesis 39:1-2](rc://en/tn/help/gen/39/01)
* [Genesis 39:13-15](rc://en/tn/help/gen/39/13)

## Word Data: ##

* Strong's: H6318

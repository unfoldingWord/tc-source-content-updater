# Amoz #

## Facts: ##

Amoz was the father of the prophet Isaiah.

* The only times he is mentioned in the Bible are when Isaiah is identified as the "son of Amoz."
* This name is different from the name of the prophet Amos and should be spelled differently.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Amos](../names/amos.md), [Isaiah](../names/isaiah.md))

## Bible References: ##

* [2 Kings 19:1-2](rc://en/tn/help/2ki/19/01)
* [Isaiah 37:1-2](rc://en/tn/help/isa/37/01)
* [Isaiah 37:21-23](rc://en/tn/help/isa/37/21)

## Word Data: ##

* Strong's: H531

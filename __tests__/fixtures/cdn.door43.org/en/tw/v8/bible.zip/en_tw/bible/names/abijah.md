# Abijah #

## Facts: ##

Abijah was a king of Judah who reigned from 915 to 913 B.C. He was a son of King Rehoboam. There were also several other men named Abijah in the Old Testament:

* Samuel's sons Abijah and Joel were leaders over the people of Israel at Beersheba. Because Abijah and his brother were dishonest and greedy, the people asked Samuel to appoint a king to rule them instead.
* Abijah was one of the temple priests during the time of King David.
* Abijah was one of King Jeroboam's sons.
* Abijah was also a chief priest who returned with Zerubbabel to Jerusalem from the Babylonian captivity.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

## Bible References: ##

* [1 Kings 15:1-3](rc://en/tn/help/1ki/15/01)
* [1 Samuel 08:1-3](rc://en/tn/help/1sa/08/01)
* [2 Chronicles 13:1-3](rc://en/tn/help/2ch/13/01)
* [2 Chronicles 13:19-22](rc://en/tn/help/2ch/13/19)
* [Luke 01:5-7](rc://en/tn/help/luk/01/05)

## Word Data: ##

* Strong's: H29, G7

# Andrew #

## Facts: ##

Andrew was one of twelve men whom Jesus chose to be his closest disciples (later called apostles).

* Andrew's brother was Simon Peter. Both of them were fishermen.
* Peter and Andrew were fishing in the Sea of Galilee when Jesus called them to be his disciples.
* Before Peter and Andrew met Jesus, they had been disciples of John the Baptizer.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [apostle](../kt/apostle.md), [disciple](../kt/disciple.md), [the twelve](../kt/thetwelve.md))

## Bible References: ##

* [Acts 01:12-14](rc://en/tn/help/act/01/12)
* [John 01:40-42](rc://en/tn/help/jhn/01/40)
* [Mark 01:16-18](rc://en/tn/help/mrk/01/16)
* [Mark 01:29-31](rc://en/tn/help/mrk/01/29)
* [Mark 03:17-19](rc://en/tn/help/mrk/03/17)
* [Matthew 04:18-20](rc://en/tn/help/mat/04/18)
* [Matthew 10:2-4](rc://en/tn/help/mat/10/02)

## Word Data: ##

* Strong's: G406

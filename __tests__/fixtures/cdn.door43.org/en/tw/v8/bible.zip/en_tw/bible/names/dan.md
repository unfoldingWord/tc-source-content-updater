# Dan #

## Facts: ##

Dan was the fifth son of Jacob and was one of the twelve tribes of Israel.The region settled by the tribe of Dan in the northern part of Canaan also was given this name.

* During the time of Abram, there was a city named Dan located west of Jerusalem.
* Years later, during the time the nation of Israel entered the promised land, a different city named Dan was located about 60 miles north of Jerusalem.
* The term "Danites" refers to the descendants of Dan, who were also members of his clan.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Canaan](../names/canaan.md), [Jerusalem](../names/jerusalem.md), [twelve tribes of Israel](../other/12tribesofisrael.md))

## Bible References: ##

* [1 Chronicles 12:34-35](rc://en/tn/help/1ch/12/34)
* [1 Kings 04:24-25](rc://en/tn/help/1ki/04/24)
* [Exodus 01:1-5](rc://en/tn/help/exo/01/01)
* [Genesis 14:13-14](rc://en/tn/help/gen/14/13)
* [Genesis 30:5-6](rc://en/tn/help/gen/30/05)

## Word Data: ##

* Strong's: H1835, H1839, H2051

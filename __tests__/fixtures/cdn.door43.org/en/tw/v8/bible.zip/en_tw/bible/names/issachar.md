# Issachar #

## Facts: ##

Issachar was the fifth son of Jacob. His mother was Leah.

* The tribe of Issachar was one of the twelve tribes of Israel.
* Issachar's land was bordered by the lands of Naphtali, Zebulun, Manasseh, and Gad.
* It was located just south of the Sea of Galilee. 

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Gad](../names/gad.md), [Manasseh](../names/manasseh.md), [Naphtali](../names/naphtali.md), [twelve tribes of Israel](../other/12tribesofisrael.md), [Zebulun](../names/zebulun.md))

## Bible References: ##

* [Exodus 01:1-5](rc://en/tn/help/exo/01/01)
* [Ezekiel 48:23-26](rc://en/tn/help/ezk/48/23)
* [Genesis 30:16-18](rc://en/tn/help/gen/30/16)
* [Joshua 17:9-10](rc://en/tn/help/jos/17/09)

## Word Data: ##

* Strong's: H3485, G2466

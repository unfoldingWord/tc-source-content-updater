# Job #

## Facts: ##

Job was a man who is described in the Bible as blameless and righteous before God. He is best known for persevering in his faith in God through times of terrible suffering.

* Job lived in the land of Uz, which was located somewhere east of the land of Canaan, possibly near the region of the Edomites.
* It is thought that he lived during the time of Esau and Jacob because one of Job's friends was a "Temanite," which was a people group named after Esau's grandson.
* The Old Testament book of Job tells about how Job and others responded to his suffering. It also gives God's viewpoint as the sovereign creator and ruler of the universe.
* After all the disasters, God eventually healed Job and gave him more children and wealth.
* The book of Job says that he was very old when he died.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Abraham](../names/abraham.md), [Esau](../names/esau.md), [flood](../other/flood.md), [Jacob](../names/jacob.md)[Noah](../names/noah.md), [people group](../other/peoplegroup.md))

## Bible References: ##

* [Ezekiel 14:12-14](rc://en/tn/help/ezk/14/12)
* [James 05:9-11](rc://en/tn/help/jas/05/09)
* [Job 01:01](rc://en/tn/help/job/01/01)
* [Job 03:05](rc://en/tn/help/job/03/05)

## Word Data: ##

* Strong's: H347, G2492

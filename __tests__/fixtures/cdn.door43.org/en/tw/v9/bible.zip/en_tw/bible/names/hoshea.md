# Hoshea #

## Facts: ##

Hoshea was the name of a king of Israel and several other men in the Old Testament.

* Hoshea son of Alah was a king of Israel for nine years during part of the reigns of Ahaz and Hezekiah, kings of Judah.
* Joshua son of Nun was formerly named Hoshea. Moses changed Hoshea's name to Joshua before sending him and eleven other men to spy out the land of the Canaanites.
* After Moses died, Joshua led the people of Israel to take possession of the land of Canaan.
* A different man named Hoshea was a son of Azaziah and was one of the leaders of the Ephraimites.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahaz](../names/ahaz.md), [Canaan](../names/canaan.md), [Ephraim](../names/ephraim.md), [Hezekiah](../names/hezekiah.md), [Joshua](../names/joshua.md), [Moses](../names/moses.md))

## Bible References: ##

* [1 Chronicles 27:20](rc://en/tn/help/1ch/27/20)
* [2 Kings 15:30](rc://en/tn/help/2ki/15/30)
* [2 Kings 17:03](rc://en/tn/help/2ki/17/03)
* [2 Kings 18:01](rc://en/tn/help/2ki/18/01)
* [2 Kings 18:09](rc://en/tn/help/2ki/18/09)

## Word Data: ##

* Strong's: H1954

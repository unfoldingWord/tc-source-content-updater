# unfoldingWord translationWords

This is the repository for the [unfoldingWord translationWords (tW)](https://unfoldingword.bible/tw/) resource.

## Description

unfoldingWord tW is a basic Bible lexicon that provides translators with clear, concise definitions and translation suggestions for every important word in the Bible. It provides translators and checkers with essential lexical information to help them make the best possible translation decisions.

## Downloading

If you want to download English translationWords to use, go here: [https://unfoldingword.bible/tw/](https://unfoldingword.bible/tw/). tW is also included in [tS](http://ufw.io/ts) and [tC](http://ufw.io/tc).

## Improving the tWs

Please use the [issue queue](https://git.door43.org/unfoldingWord/en_tw/issues) to provide feedback or suggestions for improvement.

If you want to make your suggested changes then you may use the online editor to do so. See the [protected branch workflow](https://forum.ccbt.bible/t/protected-branch-workflow/76) document for step by step instructions.

## Structure

The tWs are organized into three sub directories under `bible`.

* `kt` is for "key terms" in the Bible which we consider to be of first importance.
* `other` terms, these are still important but not critical.
* `names` is where we've grouped proper names.

## GL Translators

### tW Translation Philosophy

To learn the philosophy of how to translate the tWs please see the [Translate the translationWords](http://gl-manual.readthedocs.io/en/latest/gl_translation.html#translating-translationwords) article in the [Gateway Language Manual](http://gl-manual.readthedocs.io/).

If you are translating online, please fork the [Door43-Catalog/en_tw](https://git.door43.org/Door43-Catalog/en_tw) repository, following this workflow: [Translate Content Online](https://forum.ccbt.bible/t/translate-content-online/75).

## License

See the [LICENSE](https://git.door43.org/unfoldingWord/en_tw/src/branch/master/LICENSE.md) file for licensing information.

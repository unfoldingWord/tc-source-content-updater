# Jehoiada #

## Facts: ##

Jehoiada was a priest who helped hide and protect King Ahaziah's son Joash until he was old enough to be declared king.

* Jehoiada arranged for hundreds of bodyguards to protect young Joash as he was proclaimed king by the people in the temple.
* Jehoiada led the people in getting rid of all the altars of the false god Baal.
* For the rest of his life, Jehoiada the priest advised King Joash to help him obey God and rule the people wisely.
* Another man named Jehoiada was the father of Benaiah.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahaziah](../names/ahaziah.md), [Baal](../names/baal.md), [Benaiah](../names/benaiah.md), [Joash](../names/joash.md))

## Bible References: ##

* [2 Kings 11:04](rc://en/tn/help/2ki/11/04)
* [2 Kings 12:1-3](rc://en/tn/help/2ki/12/01)

## Word Data: ##

* Strong's: H3077

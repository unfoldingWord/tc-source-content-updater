# Joram #

## Facts: ##

Joram son of Ahab was a king of Israel. He was also sometimes referred to as "Jehoram."

* King Joram of Israel reigned at the same time as King Jehoram of Judah.
* Joram was an evil king who worshiped false gods and caused Israel to sin.
* King Joram of Israel also reigned during the time of the prophets Elijah and Obadiah.
* Another man named Joram was the son of King Tou of Hamath when David was king.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Ahab](../names/ahab.md), [David](../names/david.md), [Elijah](../names/elijah.md), [Hamath](../names/hamath.md), [Jehoram](../names/jehoram.md), [kingdom of Israel](../names/kingdomofisrael.md), [Judah](../names/kingdomofjudah.md), [Obadiah](../names/obadiah.md), [prophet](../kt/prophet.md))

## Bible References: ##

* [1 Chronicles 03:10-12](rc://en/tn/help/1ch/03/10)
* [2 Chronicles 22:4-5](rc://en/tn/help/2ch/22/04)
* [2 Kings 01:17](rc://en/tn/help/2ki/01/17)
* [2 Kings 08:16](rc://en/tn/help/2ki/08/16)

## Word Data: ##

* Strong's: H3088, H3141, G2496

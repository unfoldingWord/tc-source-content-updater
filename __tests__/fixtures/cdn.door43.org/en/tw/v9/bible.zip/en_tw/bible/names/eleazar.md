# Eleazar #

## Facts: ##

Eleazar was the name of several men in the Bible.
 
* Eleazar was the third son of Moses' brother Aaron. After Aaron died, Eleazar became the high priest in Israel.
* Eleazar was also the name of one of David's "mighty men."
* Another Eleazar was one of Jesus' ancestors.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Aaron](../names/aaron.md), [high priest](../kt/highpriest.md), [David](../names/david.md), [mighty](../other/mighty.md))

## Bible References: ##

* [1 Chronicles 24:03](rc://en/tn/help/1ch/24/03)
* [Judges 20:27-28](rc://en/tn/help/jdg/20/27)
* [Numbers 26:1-2](rc://en/tn/help/num/26/01)
* [Numbers 34:16-18](rc://en/tn/help/num/34/16)

## Word Data: ##

* Strong's: H499, G1648

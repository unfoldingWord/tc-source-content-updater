# Iconium #

## Facts: ##

Iconium was a city in the south central part of what is now the country of Turkey.

* On Paul's first missionary journey, he and Barnabas went to Iconium after the Jews forced them to leave the city of Antioch.
* Then the unbelieving Jews and Gentiles in Iconium also planned to stone Paul and his coworkers, but they escaped to the nearby city of Lystra.
* After that the people from both Antioch and Iconium came to Lystra and stirred up the people there to stone Paul.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Barnabas](../names/barnabas.md), [Lystra](../names/lystra.md), [stone](../kt/stone.md))

## Bible References: ##

* [2 Timothy 03:10-13](rc://en/tn/help/2ti/03/10)
* [Acts 14:01](rc://en/tn/help/act/14/01)
* [Acts 14:19-20](rc://en/tn/help/act/14/19)
* [Acts 16:1-3](rc://en/tn/help/act/16/01)

## Word Data: ##

* Strong's: G2430

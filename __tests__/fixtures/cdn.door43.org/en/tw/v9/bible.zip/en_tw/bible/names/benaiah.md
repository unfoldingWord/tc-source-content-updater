# Benaiah #

## Definition: ##

Benaiah was the name of several men in the Old Testament.

* Benaiah son of Jehoiada was one of David's mighty men. He was a skilled warrior and was put in charge of David's bodyguards.
* When Solomon was being made king, Benaiah helped him overthrow his enemies. He eventually became commander of the Israelite army.
* Other men in the Old Testament named Benaiah include three Levites: a priest, a musician, and a descendant of Asaph.

(See also: [Asaph](../names/asaph.md), [Jehoiada](../names/jehoiada.md), [Levite](../names/levite.md), [Solomon](../names/solomon.md))

## Bible References: ##

* [1 Chronicles 04:36](rc://en/tn/help/1ch/04/36)
* [1 Kings 01:08](rc://en/tn/help/1ki/01/08)
* [2 Samuel 23:20-21](rc://en/tn/help/2sa/23/20)

## Word Data: ##

* Strong's: H1141

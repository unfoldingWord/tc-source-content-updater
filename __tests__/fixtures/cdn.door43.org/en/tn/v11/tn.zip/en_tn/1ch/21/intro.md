# 1 Chronicles 21 General Notes #

#### Special concepts in this chapter ####

##### Trust #####
To trust in one's own power instead of God's protection is a sin. David had been trusting God to protect him, but now he counted the men of military age so he could know the strength of his army. (See: [[rc://en/tw/dict/bible/kt/trust]] and [[rc://en/tw/dict/bible/kt/sin]])

## Links: ##

* __[1 Chronicles 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | [>>](../22/intro.md)__

# 1 Chronicles 22 General Notes #

#### Structure and formatting ####

This chapter begins a new section lasting for the remainder of the book. David begins preparing the things needed for building the temple. (See: [[rc://en/tw/dict/bible/kt/temple]])

#### Special concepts in this chapter ####

##### Solomon #####
In addition to preparing for the construction of the temple by gathering supplies, David also prepares his son, Solomon, to build the temple. David instructs Solomon to obey God. This is what is most necessary.

## Links: ##

* __[1 Chronicles 22:01 Notes](./01.md)__

__[<<](../21/intro.md) | [>>](../23/intro.md)__

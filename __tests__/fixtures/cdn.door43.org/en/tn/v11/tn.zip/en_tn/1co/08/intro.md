# 1 Corinthians 08 General Notes #

#### Structure and formatting ####

Chapters 8-10 form a single unit that answers the question: "Is it acceptable to eat meat that has been sacrificed to an idol?"

#### Special concepts in this chapter ####

==Meat sacrificed to idols ==
Paul answers their question by saying that idols are gods that do not really exist, and that therefore there is nothing wrong with the meat. However, someone who does not understand a Christian's freedom to eat this meat may see a Christian eating and be encouraged to eat the meat as an act of worship to the idol. 

## Links: ##

* __[1 Corinthians 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__

# 1 Chronicles 19 General Notes #

#### Structure and formatting ####

This is the beginning of the story about the war against the Ammonites. This story continues in the first part of the next chapter.

#### Special concepts in this chapter ####

##### Insults #####

The young king of Ammon insulted David when he had David's servants shaved and cut off their garments. Knowing David was going to attack him for this, he hired mercenaries from Aram to help him. Israel was able to defeat the Aramean mercenaries.

## Links: ##

* __[1 Chronicles 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__

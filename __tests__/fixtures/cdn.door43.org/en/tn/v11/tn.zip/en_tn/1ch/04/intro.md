# 1 Chronicles 04 General Notes #

#### Structure and formatting ####

This chapter records the other descendants of Judah. 

## Links: ##

* __[1 Chronicles 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__

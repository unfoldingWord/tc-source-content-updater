# 1 Chronicles 09 General Notes #

#### Structure and formatting ####

This chapter records the genealogy of the people who returned to Jerusalem after the exile and the family of Saul. 

## Links: ##

* __[1 Chronicles 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__

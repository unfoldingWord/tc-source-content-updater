# 1 Chronicles 28 General Notes #

#### Structure and formatting ####

The preparation for the temple continues in this chapter. David lectured the people and Solomon on what they should do. (See: [[rc://en/tw/dict/bible/kt/temple]])

#### Special concepts in this chapter ####

##### David's instructions #####
David gives instructions to the people because he knows that he will not be there when the temple is built. It was common in the ancient Near East for leaders to give instructions to people before they die in preparation or anticipation of their death. 

## Links: ##

* __[1 Chronicles 28:01 Notes](./01.md)__

__[<<](../27/intro.md) | [>>](../29/intro.md)__

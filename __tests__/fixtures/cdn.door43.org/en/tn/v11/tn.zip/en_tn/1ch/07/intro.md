# 1 Chronicles 07 General Notes #

#### Structure and formatting ####

This chapter records the descendants of Issachar, Benjamin, Ephraim, Asher, and Manasseh living west of the Jordan River.

## Links: ##

* __[1 Chronicles 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__

# 1 Chronicles 17 General Notes #

#### Special concepts in this chapter ####

##### Building the temple #####
David wanted to build a temple for God but God would not allow him to. Instead he promised that his son, Solomon, would build the temple and he promised David would have a descendant who would be king forever. (See: [[rc://en/tw/dict/bible/kt/temple]], [[rc://en/tw/dict/bible/kt/promise]] and [[rc://en/tw/dict/bible/kt/forever]])

## Links: ##

* __[1 Chronicles 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__

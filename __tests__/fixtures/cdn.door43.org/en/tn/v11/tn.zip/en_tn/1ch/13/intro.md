# 1 Chronicles 13 General Notes #

#### Special concepts in this chapter ####

##### Ark of the covenant #####
David tried to bring the ark to Jerusalem on an ox cart instead of being carried by priests as the law said to do. The ox stumbled and Uzzah touched the ark to keep it from falling and he immediately died because of this. (See: [[rc://en/tw/dict/bible/kt/priest]], [[rc://en/tw/dict/bible/kt/lawofmoses]] and [[rc://en/tw/dict/bible/kt/covenant]])

## Links: ##

* __[1 Chronicles 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__

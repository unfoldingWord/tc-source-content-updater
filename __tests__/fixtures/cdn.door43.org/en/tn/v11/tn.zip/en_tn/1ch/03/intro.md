# 1 Chronicles 03 General Notes #

#### Structure and formatting ####

This chapter records the descendants of King David. 

## Links: ##

* __[1 Chronicles 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__

# 1 Chronicles 15 General Notes #

#### Structure and formatting ####

Chapters 15 and 16 explain how David organized the priests and Levites. (See: [[rc://en/tw/dict/bible/kt/priest]])

## Links: ##

* __[1 Chronicles 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__

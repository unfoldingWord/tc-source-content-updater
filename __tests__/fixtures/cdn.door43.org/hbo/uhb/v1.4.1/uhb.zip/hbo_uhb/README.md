# unfoldingWord Hebrew Bible

*An open-licensed, lexically tagged, morphologically parsed Hebrew Old Testament. It enables the global Church to have access to the original texts of the Old Testament.*

## Basis

The UHB is based on the [Open Scriptures Hebrew Bible](https://github.com/openscriptures/morphhb). This project is the Westminster Leningrad Codex with Strongs lexical data and morphological data marked up in OSIS files.

## Changes from the OSHB

The UHB differs from the OSHB in one respect (though more may be coming):

* Metadata - The UHB text includes various metadata to mark the text which create links to other content that our software uses. For example, we add links to our [translationWords](https://git.door43.org/unfoldingWord/en_tw) articles where appropriate.

## Parsing Status

See the parsing status for the whole [OSHB Old Testament](http://hb.openscriptures.org/status_all.html). The OSHB project is nearly finished.

## Related projects

* [unfoldingWord Hebrew Grammar](https://uhg.readthedocs.io/en/latest/)
* [unfoldingWord Literal Text](https://git.door43.org/unfoldingWord/en_ult)
